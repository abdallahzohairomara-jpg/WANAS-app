// Supabase Edge Function: يرسل إشعارات FCM عند إدراج رسالة أو مكالمة جديدة.
// تُستدعى من Database Webhook وليس من التطبيق، ولا تقبل إلا الطلبات التي
// تحمل السر المشترك. انشرها هكذا:
//   supabase functions deploy send-push --no-verify-jwt
//
// الأسرار: PUSH_WEBHOOK_SECRET, FCM_SERVICE_ACCOUNT (محتوى ملف JSON كاملًا)
// SUPABASE_URL وSUPABASE_SERVICE_ROLE_KEY تُحقن تلقائيًا.

import { createClient } from "npm:@supabase/supabase-js@2";
import { importPKCS8, SignJWT } from "npm:jose@5";

const admin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

function sa() {
  const raw = Deno.env.get("FCM_SERVICE_ACCOUNT");
  if (!raw) throw new Error("FCM_SERVICE_ACCOUNT missing");
  return JSON.parse(raw);
}

let cached: { token: string; exp: number } | null = null;

async function accessToken(): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  if (cached && cached.exp - 60 > now) return cached.token;
  const acct = sa();
  const key = await importPKCS8(acct.private_key, "RS256");
  const jwt = await new SignJWT({ scope: "https://www.googleapis.com/auth/firebase.messaging" })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(acct.client_email)
    .setAudience("https://oauth2.googleapis.com/token")
    .setIssuedAt(now)
    .setExpirationTime(now + 3600)
    .sign(key);
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt,
    }),
  });
  const j = await res.json();
  if (!res.ok) throw new Error("token exchange failed: " + JSON.stringify(j));
  cached = { token: j.access_token, exp: now + (j.expires_in ?? 3600) };
  return cached.token;
}

type Push = {
  title: string;
  body: string;
  data: Record<string, string>;
  channel: "messages" | "calls";
};

// "ok" | "dead" (رمز منتهٍ يُحذف) | "error"
async function sendOne(deviceToken: string, p: Push): Promise<"ok" | "dead" | "error"> {
  const projectId = sa().project_id;
  const isCall = p.channel === "calls";
  const res = await fetch(
    `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${await accessToken()}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: {
          token: deviceToken,
          notification: { title: p.title, body: p.body },
          data: p.data,
          android: {
            priority: "HIGH",
            ttl: isCall ? "45s" : "86400s",
            notification: { channel_id: p.channel },
          },
        },
      }),
    },
  );
  if (res.ok) return "ok";
  const err = await res.json().catch(() => ({}));
  const code = JSON.stringify(err);
  if (res.status === 404 || code.includes("UNREGISTERED")) return "dead";
  console.error("fcm error", res.status, code);
  return "error";
}

const T = {
  ar: { newMsg: "رسالة جديدة", video: "مكالمة فيديو واردة", voice: "مكالمة صوتية واردة" },
  en: { newMsg: "New message", video: "Incoming video call", voice: "Incoming voice call" },
};

function clip(s: string, n = 120) {
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
}


// ---- إشعارات اجتماعية: تعليقات، إشارات، طلبات صداقة (تحترم إعدادات المستلم) ----
const SOC = {
  ar: { comment: "علّق على منشورك", mention: "أشار إليك", friend: "أرسل لك طلب صداقة" },
  en: { comment: "commented on your post", mention: "mentioned you", friend: "sent you a friend request" },
};

async function handleSocial(table: string, rec: any): Promise<Response> {
  let actor: string, target: string, kind: "comment" | "mention" | "friend", flag: string, text = "";
  if (table === "comments") {
    const { data: post } = await admin.from("posts").select("author_id").eq("id", rec.post_id).single();
    if (!post || post.author_id === rec.author_id) return new Response("skip");
    actor = rec.author_id; target = post.author_id; kind = "comment"; flag = "notify_comments";
    text = rec.body ?? "";
  } else if (table === "mentions") {
    actor = rec.author_id; target = rec.mentioned_id; kind = "mention"; flag = "notify_mentions";
  } else {
    if (rec.status !== "pending") return new Response("skip");
    actor = rec.requester_id; target = rec.addressee_id; kind = "friend"; flag = "notify_friend_requests";
  }
  const [{ data: st }, { data: blk }, { data: me }, { data: prof }, { data: tokens }] = await Promise.all([
    admin.from("user_settings").select("*").eq("user_id", target).maybeSingle(),
    admin.from("blocks").select("blocker_id").or(
      `and(blocker_id.eq.${actor},blocked_id.eq.${target}),and(blocker_id.eq.${target},blocked_id.eq.${actor})`),
    admin.from("profiles").select("username, display_name").eq("id", actor).single(),
    admin.from("profiles").select("lang").eq("id", target).single(),
    admin.from("device_tokens").select("token").eq("user_id", target),
  ]);
  if ((blk ?? []).length) return new Response("blocked");
  if (st) {
    if (st[flag] === false) return new Response("disabled");
    if (st.focus_until && new Date(st.focus_until) > new Date()) return new Response("focus");
    const qs = st.quiet_start, qe = st.quiet_end;
    if (qs != null && qe != null) {
      const h = new Date().getUTCHours(); // ساعات الهدوء تُقارن بتوقيت UTC (محدودية معروفة)
      const inQuiet = qs <= qe ? h >= qs && h < qe : h >= qs || h < qe;
      if (inQuiet) return new Response("quiet");
    }
  }
  const { data: mute } = await admin.from("user_mutes").select("until")
    .eq("user_id", target).eq("muted_id", actor).maybeSingle();
  if (mute && (!mute.until || new Date(mute.until) > new Date())) return new Response("muted");
  const lang = prof?.lang === "en" ? "en" : "ar";
  const name = (me?.display_name as string) || (me?.username as string) || "";
  const dead: string[] = [];
  await Promise.all((tokens ?? []).map(async (t) => {
    const r = await sendOne(t.token as string, {
      title: name,
      body: clip(`${SOC[lang][kind]}${text ? ": " + text : ""}`),
      channel: "messages",
      data: { type: "social", kind },
    });
    if (r === "dead") dead.push(t.token as string);
  }));
  if (dead.length) await admin.from("device_tokens").delete().in("token", dead);
  return new Response("ok");
}

Deno.serve(async (req) => {
  try {
    if (req.headers.get("x-webhook-secret") !== Deno.env.get("PUSH_WEBHOOK_SECRET")) {
      return new Response("unauthorized", { status: 401 });
    }
    const payload = await req.json();
    if (payload.type !== "INSERT") return new Response("ignored");
    const rec = payload.record;
    const table: string = payload.table;

    if (table === "comments" || table === "mentions" || table === "friendships") {
      return await handleSocial(table, rec);
    }

    let senderId: string;
    let conversationId: string;
    if (table === "messages") {
      senderId = rec.sender_id;
      conversationId = rec.conversation_id;
    } else if (table === "calls") {
      senderId = rec.caller_id;
      conversationId = rec.conversation_id;
    } else {
      return new Response("ignored");
    }

    const [{ data: conv }, { data: sender }, { data: members }, { data: blocks }] =
      await Promise.all([
        admin.from("conversations").select("is_group, title").eq("id", conversationId).single(),
        admin.from("profiles").select("username, display_name").eq("id", senderId).single(),
        admin.from("conversation_members").select("user_id").eq("conversation_id", conversationId)
          .neq("user_id", senderId),
        admin.from("blocks").select("blocker_id, blocked_id")
          .or(`blocker_id.eq.${senderId},blocked_id.eq.${senderId}`),
      ]);
    if (!conv || !sender) return new Response("not found", { status: 404 });

    // لا إشعار لمن بينه وبين المرسل حظر في أي اتجاه
    const blockedWith = new Set<string>();
    for (const b of blocks ?? []) {
      blockedWith.add(b.blocker_id === senderId ? b.blocked_id : b.blocker_id);
    }
    const recipients = (members ?? []).map((m) => m.user_id as string)
      .filter((id) => !blockedWith.has(id));
    if (recipients.length === 0) return new Response("no recipients");

    const [{ data: profs }, { data: tokens }] = await Promise.all([
      admin.from("profiles").select("id, lang").in("id", recipients),
      admin.from("device_tokens").select("token, user_id").in("user_id", recipients),
    ]);
    const langOf = new Map((profs ?? []).map((p) => [p.id as string, (p.lang as string) ?? "ar"]));

    const senderName = (sender.display_name as string) || (sender.username as string);
    const title = conv.is_group && table === "messages"
      ? (conv.title as string)
      : senderName;

    const dead: string[] = [];
    await Promise.all((tokens ?? []).map(async (t) => {
      const lang = langOf.get(t.user_id as string) === "en" ? "en" : "ar";
      const tr = T[lang];
      let push: Push;
      if (table === "messages") {
        const text = (rec.body as string)?.trim() || tr.newMsg;
        push = {
          title,
          body: clip(conv.is_group ? `${senderName}: ${text}` : text),
          channel: "messages",
          data: { type: "message", conversation_id: conversationId, title },
        };
      } else {
        push = {
          title: senderName,
          body: rec.is_video ? tr.video : tr.voice,
          channel: "calls",
          data: {
            type: "call",
            call_id: rec.id,
            conversation_id: conversationId,
            provider: rec.provider,
            is_video: String(rec.is_video),
            title: senderName,
          },
        };
      }
      const r = await sendOne(t.token as string, push);
      if (r === "dead") dead.push(t.token as string);
    }));

    if (dead.length) await admin.from("device_tokens").delete().in("token", dead);
    return new Response("ok");
  } catch (e) {
    console.error(e);
    return new Response("error", { status: 500 });
  }
});
