// معاينة رابط (عنوان/وصف) بحماية من SSRF. انشرها:
//   supabase functions deploy link-preview
// تتطلب مستخدمًا مسجّل الدخول (JWT يُتحقق منه افتراضيًا).
// ملاحظة: الحماية تفحص اسم المضيف وعناوين IP الحرفية، وتعيد فحص كل تحويل (redirect) يدويًا.

function isPrivateHost(h: string): boolean {
  h = h.toLowerCase();
  if (h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal")) return true;
  if (h.includes(":")) return true; // أي IPv6 حرفي مرفوض
  const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (m) {
    const [a, b] = [Number(m[1]), Number(m[2])];
    if (a === 10 || a === 127 || a === 0 || a >= 224) return true;
    if (a === 169 && b === 254) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    return false;
  }
  if (/^\d+$/.test(h) || /^0x/i.test(h)) return true; // صيغ IP مموّهة
  return false;
}

function meta(html: string, prop: string): string | null {
  const re = new RegExp(
    `<meta[^>]+(?:property|name)=["']${prop}["'][^>]*content=["']([^"']*)["']|<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${prop}["']`,
    "i",
  );
  const m = html.match(re);
  return (m?.[1] ?? m?.[2] ?? null);
}

function decode(s: string): string {
  return s.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").trim();
}

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type, apikey, x-client-info" };
const json = (o: unknown, st = 200) =>
  new Response(JSON.stringify(o), { status: st, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { url } = await req.json();
    let u = new URL(String(url));
    let res: Response | null = null;
    for (let hop = 0; hop < 4; hop++) {
      if (!["http:", "https:"].includes(u.protocol) || isPrivateHost(u.hostname) || (u.port && !["80", "443"].includes(u.port))) {
        return json({ error: "blocked" }, 400);
      }
      res = await fetch(u, {
        redirect: "manual",
        signal: AbortSignal.timeout(5000),
        headers: { "User-Agent": "WanasLinkPreview/1.0", Accept: "text/html" },
      });
      if (res.status >= 300 && res.status < 400 && res.headers.get("location")) {
        u = new URL(res.headers.get("location")!, u);
        res = null;
        continue;
      }
      break;
    }
    if (!res || !res.ok) return json({ error: "unreachable" }, 502);
    if (!(res.headers.get("content-type") ?? "").includes("text/html")) return json({ title: u.hostname, description: "" });
    // نقرأ أول 256KB فقط
    const reader = res.body!.getReader();
    let html = "", bytes = 0;
    const dec = new TextDecoder();
    while (bytes < 262144) {
      const { done, value } = await reader.read();
      if (done || !value) break;
      bytes += value.length;
      html += dec.decode(value, { stream: true });
      if (html.includes("</head>")) break;
    }
    reader.cancel().catch(() => {});
    const title = meta(html, "og:title") ?? html.match(/<title[^>]*>([^<]*)<\/title>/i)?.[1] ?? u.hostname;
    const description = meta(html, "og:description") ?? meta(html, "description") ?? "";
    return json({ title: decode(title).slice(0, 200), description: decode(description).slice(0, 400) });
  } catch (_) {
    return json({ error: "bad request" }, 400);
  }
});
