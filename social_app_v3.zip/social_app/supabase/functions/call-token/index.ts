// Supabase Edge Function: يصدر تصريح دخول للمكالمة بعد التحقق من الصلاحيات.
// المفاتيح السرية تبقى هنا على الخادم فقط ولا تدخل التطبيق أبدًا.
//
// الأسرار المطلوبة (supabase secrets set ...):
//   LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET   (للمزود livekit)
//   AGORA_APP_ID, AGORA_APP_CERTIFICATE                (للمزود agora)
// المزود الذي لا تُضبط أسراره يُرفض بخطأ واضح.

import { createClient } from "npm:@supabase/supabase-js@2";
import { AccessToken } from "npm:livekit-server-sdk@2";
import { RtcRole, RtcTokenBuilder } from "npm:agora-token";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const TTL_SECONDS = 2 * 60 * 60;

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

// يجب أن يطابق agoraUidFor في تطبيق Flutter تمامًا
function agoraUidFor(userId: string): number {
  const n = parseInt(userId.replace(/-/g, "").slice(0, 8), 16);
  return n === 0 ? 1 : n;
}

Deno.serve(async (req) => {
  try {
    if (req.method !== "POST") return json({ error: "method not allowed" }, 405);

    const sb = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } },
    );
    const { data: { user }, error: userErr } = await sb.auth.getUser();
    if (userErr || !user) return json({ error: "unauthorized" }, 401);

    const { conversation_id, provider } = await req.json();
    if (typeof conversation_id !== "string" || !UUID.test(conversation_id)) {
      return json({ error: "invalid conversation" }, 400);
    }

    // عضو في المحادثة وغير محظور (نفس دالة can_send المستخدمة للرسائل)
    const { data: allowed, error: rpcErr } = await sb.rpc("can_send", { conv: conversation_id });
    if (rpcErr || allowed !== true) return json({ error: "forbidden" }, 403);

    if (provider === "livekit") {
      const url = Deno.env.get("LIVEKIT_URL");
      const key = Deno.env.get("LIVEKIT_API_KEY");
      const secret = Deno.env.get("LIVEKIT_API_SECRET");
      if (!url || !key || !secret) return json({ error: "provider not configured" }, 400);

      const at = new AccessToken(key, secret, { identity: user.id, ttl: TTL_SECONDS });
      at.addGrant({
        roomJoin: true,
        room: conversation_id,
        canPublish: true,
        canSubscribe: true,
      });
      return json({ provider, url, token: await at.toJwt() });
    }

    if (provider === "agora") {
      const appId = Deno.env.get("AGORA_APP_ID");
      const cert = Deno.env.get("AGORA_APP_CERTIFICATE");
      if (!appId || !cert) return json({ error: "provider not configured" }, 400);

      const uid = agoraUidFor(user.id);
      const token = RtcTokenBuilder.buildTokenWithUid(
        appId,
        cert,
        conversation_id,
        uid,
        RtcRole.PUBLISHER,
        TTL_SECONDS,
        TTL_SECONDS,
      );
      return json({ provider, appId, token, uid, channel: conversation_id });
    }

    return json({ error: "unknown provider" }, 400);
  } catch (e) {
    console.error(e);
    return json({ error: "server error" }, 500);
  }
});
