import 'package:flutter/material.dart';

import '../main.dart';
import '../social_helpers.dart';
import '../strings.dart';
import 'chats_screen.dart' show displayName;

/// إدارة مشاركي منشور (للمالك فقط). المدعو لا يظهر اسمه للآخرين قبل موافقته.
class ParticipantsScreen extends StatefulWidget {
  final String postId;
  const ParticipantsScreen({super.key, required this.postId});

  @override
  State<ParticipantsScreen> createState() => _ParticipantsScreenState();
}

class _ParticipantsScreenState extends State<ParticipantsScreen> {
  List<Map<String, dynamic>> _rows = [];
  List<Map<String, dynamic>> _friends = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _load() async {
    try {
      final rows = await supabase
          .from('post_participants')
          .select('user_id, status')
          .eq('post_id', widget.postId);
      _rows = List<Map<String, dynamic>>.from(rows);
      _friends = await loadFriends();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _invite(String userId) async {
    try {
      await supabase
          .from('post_participants')
          .insert({'post_id': widget.postId, 'user_id': userId});
      await _load();
    } catch (_) {
      if (mounted) _snack(S.of(context).t('invite_failed'));
    }
  }

  Future<void> _remove(String userId) async {
    try {
      await supabase
          .from('post_participants')
          .delete()
          .eq('post_id', widget.postId)
          .eq('user_id', userId);
      await _load();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final byId = {for (final f in _friends) f['id'] as String: f};
    final invitedIds = {for (final r in _rows) r['user_id'] as String};
    return Scaffold(
      appBar: AppBar(title: Text(s.t('participants'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(s.t('participants_hint'),
                    style: Theme.of(context).textTheme.bodySmall),
              ),
              for (final r in _rows)
                ListTile(
                  title: Text(displayName(byId[r['user_id']])),
                  subtitle: Text(s.t('pstatus_${r['status']}')),
                  trailing: IconButton(
                    tooltip: s.t('remove'),
                    icon: const Icon(Icons.person_remove_outlined),
                    onPressed: () => _remove(r['user_id'] as String),
                  ),
                ),
              const Divider(),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: Text(s.t('invite_friends'),
                    style: Theme.of(context).textTheme.titleSmall),
              ),
              if (_friends.every((f) => invitedIds.contains(f['id'])))
                Padding(
                    padding: const EdgeInsets.all(16), child: Text(s.t('no_friends'))),
              for (final f in _friends)
                if (!invitedIds.contains(f['id']))
                  ListTile(
                    title: Text(displayName(f)),
                    trailing: TextButton(
                        onPressed: () => _invite(f['id'] as String),
                        child: Text(s.t('invite'))),
                  ),
            ]),
    );
  }
}
