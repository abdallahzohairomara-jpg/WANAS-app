import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../main.dart';
import '../../settings_store.dart';
import '../../strings.dart';
import '../feed_settings_screen.dart';
import 'people_lists_screen.dart';

/// مركز الإعدادات: كل قيمة تُحفظ في user_settings فور تغييرها وتتبعك بين أجهزتك.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final st = AppSettings.I;

  @override
  void initState() {
    super.initState();
    st.addListener(_r);
    if (!st.loaded) st.load();
  }

  @override
  void dispose() {
    st.removeListener(_r);
    super.dispose();
  }

  void _r() {
    if (mounted) setState(() {});
  }

  Future<void> _set(String k, dynamic v) async {
    final ok = await st.set(k, v);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(S.of(context).error)));
    }
  }

  Widget _head(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
        child: Text(t, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
      );

  Widget _sw(String key, String k, bool def, {String? hint}) {
    final s = S.of(context);
    return SwitchListTile(
      title: Text(s.t(key)),
      subtitle: hint == null ? null : Text(s.t(hint)),
      value: st.flag(k, def),
      onChanged: (v) => _set(k, v),
    );
  }

  Widget _choice(String key, String k, String def, List<String> values, {String prefix = ''}) {
    final s = S.of(context);
    return ListTile(
      title: Text(s.t(key)),
      subtitle: Text(s.t('$prefix${st.str(k, def)}')),
      trailing: const Icon(Icons.arrow_drop_down),
      onTap: () async {
        final v = await showModalBottomSheet<String>(
          context: context,
          builder: (ctx) => SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              for (final x in values)
                RadioListTile<String>(
                  title: Text(s.t('$prefix$x')),
                  value: x,
                  groupValue: st.str(k, def),
                  onChanged: (v) => Navigator.pop(ctx, v),
                ),
            ]),
          ),
        );
        if (v != null) _set(k, v);
      },
    );
  }

  Future<void> _pickHour(String k, String title) async {
    final cur = st.intOrNull(k);
    final t = await showTimePicker(
        context: context, initialTime: TimeOfDay(hour: cur ?? 22, minute: 0), helpText: title);
    if (t != null) _set(k, t.hour);
  }

  Future<void> _focus() async {
    final s = S.of(context);
    final active = st.str('focus_until', '').isNotEmpty &&
        DateTime.tryParse(st.str('focus_until', ''))?.isAfter(DateTime.now()) == true;
    if (active) {
      _set('focus_until', null);
      return;
    }
    final h = await showModalBottomSheet<int>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final x in [1, 2, 4, 8, 24])
            ListTile(title: Text('$x ${s.t('hours')}'), onTap: () => Navigator.pop(ctx, x)),
        ]),
      ),
    );
    if (h != null) {
      _set('focus_until', DateTime.now().toUtc().add(Duration(hours: h)).toIso8601String());
    }
  }

  Future<void> _limit() async {
    final s = S.of(context);
    final v = await showModalBottomSheet<int>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(title: Text(s.t('no_limit')), onTap: () => Navigator.pop(ctx, 0)),
          for (final x in [30, 60, 120, 180, 300])
            ListTile(title: Text('$x ${s.t('minutes')}'), onTap: () => Navigator.pop(ctx, x)),
        ]),
      ),
    );
    if (v != null) _set('daily_limit_minutes', v == 0 ? null : v);
  }

  Future<void> _changePassword() async {
    final s = S.of(context);
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('change_password')),
        content: TextField(controller: c, obscureText: true,
            decoration: InputDecoration(labelText: s.t('new_password'))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(s.t('save'))),
        ],
      ),
    );
    if (ok != true) return;
    if (c.text.length < 8) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('password_short'))));
      return;
    }
    try {
      await supabase.auth.updateUser(UserAttributes(password: c.text));
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('saved'))));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('error'))));
    }
  }

  Future<void> _signOutAll() async {
    try {
      await supabase.auth.signOut(scope: SignOutScope.global);
    } catch (_) {}
    st.reset();
    if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
  }

  Future<void> _export() async {
    final s = S.of(context);
    try {
      final data = await supabase.rpc('export_my_data');
      await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent('  ').convert(data)));
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('exported_all'))));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('error'))));
    }
  }

  Future<void> _deleteAccount() async {
    final s = S.of(context);
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('delete_account')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(s.t('delete_account_warn')),
          TextField(controller: c, decoration: InputDecoration(hintText: s.t('type_delete'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim() == 'DELETE'), child: Text(s.t('delete'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await supabase.rpc('delete_my_account');
      await supabase.auth.signOut();
      st.reset();
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('error'))));
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final fu = DateTime.tryParse(st.str('focus_until', ''));
    final focusOn = fu != null && fu.isAfter(DateTime.now());
    String hr(String k) => st.intOrNull(k) == null ? '—' : '${st.intOrNull(k)}:00';
    final limit = st.intOrNull('daily_limit_minutes');
    return Scaffold(
      appBar: AppBar(title: Text(s.t('settings'))),
      body: ListView(children: [
        _head(s.t('set_account')),
        ListTile(
            leading: const Icon(Icons.lock_outline),
            title: Text(s.t('change_password')),
            onTap: _changePassword),
        ListTile(
            leading: const Icon(Icons.devices),
            title: Text(s.t('signout_all')),
            subtitle: Text(s.t('signout_all_hint')),
            onTap: _signOutAll),
        _head(s.t('set_privacy')),
        _choice('who_can_mention', 'who_can_mention', 'everyone', ['everyone', 'friends', 'nobody'], prefix: 'opt_'),
        _choice('who_can_add_me', 'who_can_add_me', 'everyone', ['everyone', 'nobody'], prefix: 'opt_'),
        _choice('default_audience', 'default_audience', 'friends', ['public', 'friends', 'private'], prefix: 'aud_'),
        _sw('allow_download', 'default_allow_download', true, hint: 'allow_download_hint'),
        _sw('allow_share', 'default_allow_share', true),
        ListTile(
            leading: const Icon(Icons.block),
            title: Text(s.t('blocked_list')),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => const PeopleListsScreen(kind: PeopleListKind.blocked)))),
        ListTile(
            leading: const Icon(Icons.volume_off_outlined),
            title: Text(s.t('muted_list')),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => const PeopleListsScreen(kind: PeopleListKind.muted)))),
        ListTile(
            leading: const Icon(Icons.visibility_off_outlined),
            title: Text(s.t('story_hidden_list')),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => const PeopleListsScreen(kind: PeopleListKind.storyHidden)))),
        _head(s.t('set_notifications')),
        _sw('notif_messages', 'notify_messages', true),
        _sw('notif_calls', 'notify_calls', true),
        _sw('notif_mentions', 'notify_mentions', true),
        _sw('notif_comments', 'notify_comments', true),
        _sw('notif_reactions', 'notify_reactions', true),
        _sw('notif_friend_requests', 'notify_friend_requests', true),
        _sw('notif_groups', 'notify_groups', true),
        _sw('notif_stories', 'notify_stories', true),
        ListTile(
            title: Text(s.t('quiet_start')),
            trailing: Text(hr('quiet_start')),
            onTap: () => _pickHour('quiet_start', s.t('quiet_start'))),
        ListTile(
            title: Text(s.t('quiet_end')),
            trailing: Text(hr('quiet_end')),
            onTap: () => _pickHour('quiet_end', s.t('quiet_end'))),
        if (st.intOrNull('quiet_start') != null || st.intOrNull('quiet_end') != null)
          TextButton(
              onPressed: () async {
                await _set('quiet_start', null);
                await _set('quiet_end', null);
              },
              child: Text(s.t('clear_quiet'))),
        SwitchListTile(
          title: Text(s.t('focus_mode')),
          subtitle: Text(focusOn ? '${s.t('focus_until')} ${fu.toLocal().toString().substring(0, 16)}' : s.t('focus_hint')),
          value: focusOn,
          onChanged: (_) => _focus(),
        ),
        _head(s.t('set_feed')),
        ListTile(
            leading: const Icon(Icons.tune),
            title: Text(s.t('feed_control')),
            onTap: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const FeedSettingsScreen()))),
        _head(s.t('set_media')),
        _choice('autoplay', 'autoplay', 'wifi', ['always', 'wifi', 'never'], prefix: 'ap_'),
        _sw('data_saver', 'data_saver', false, hint: 'data_saver_hint'),
        _choice('upload_quality', 'upload_quality', 'original', ['original', 'high', 'saver'], prefix: 'uq_'),
        _head(s.t('set_appearance')),
        _choice('theme', 'theme_mode', 'system', ['system', 'light', 'dark'], prefix: 'theme_'),
        ListTile(
          title: Text(s.t('font_size')),
          subtitle: Slider(
            min: 0.8,
            max: 1.6,
            divisions: 8,
            label: st.dbl('font_scale', 1.0).toStringAsFixed(1),
            value: st.dbl('font_scale', 1.0).clamp(0.8, 1.6),
            onChanged: (v) => fontScaleNotifier.value = v,
            onChangeEnd: (v) => _set('font_scale', double.parse(v.toStringAsFixed(1))),
          ),
        ),
        _head(s.t('set_wellbeing')),
        ListTile(
          leading: const Icon(Icons.timer_outlined),
          title: Text(s.t('daily_limit')),
          subtitle: Text(limit == null ? s.t('no_limit') : '$limit ${s.t('minutes')}'),
          onTap: _limit,
        ),
        _head(s.t('set_data')),
        ListTile(
            leading: const Icon(Icons.download_outlined),
            title: Text(s.t('export_my_data')),
            subtitle: Text(s.t('export_my_data_hint')),
            onTap: _export),
        ListTile(
            leading: Icon(Icons.delete_forever, color: Theme.of(context).colorScheme.error),
            title: Text(s.t('delete_account')),
            onTap: _deleteAccount),
        _head(s.t('set_about')),
        ListTile(title: Text(s.t('app_name')), subtitle: Text(s.t('tagline'))),
        const SizedBox(height: 40),
      ]),
    );
  }
}
