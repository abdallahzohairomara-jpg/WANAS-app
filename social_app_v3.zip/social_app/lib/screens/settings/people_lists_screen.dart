import 'package:flutter/material.dart';

import '../../main.dart';
import '../../social_helpers.dart';
import '../../strings.dart';
import '../chats_screen.dart' show displayName;

enum PeopleListKind { blocked, muted, storyHidden }

/// قوائم الأشخاص: المحظورون، المكتومون، ومن أخفيت عنهم ستورياتي.
class PeopleListsScreen extends StatefulWidget {
  final PeopleListKind kind;
  const PeopleListsScreen({super.key, required this.kind});

  @override
  State<PeopleListsScreen> createState() => _PeopleListsScreenState();
}

class _PeopleListsScreenState extends State<PeopleListsScreen> {
  List<Map<String, dynamic>> _rows = [];
  bool _loading = true;

  String get _uid => supabase.auth.currentUser!.id;

  (String table, String me, String other) get _cfg => switch (widget.kind) {
        PeopleListKind.blocked => ('blocks', 'blocker_id', 'blocked_id'),
        PeopleListKind.muted => ('user_mutes', 'user_id', 'muted_id'),
        PeopleListKind.storyHidden => ('story_hidden_from', 'owner_id', 'hidden_id'),
      };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final (t, me, other) = _cfg;
    try {
      final rows = await supabase
          .from(t)
          .select('$other, profiles!${t}_${other}_fkey(username, display_name)')
          .eq(me, _uid);
      if (mounted) setState(() => _rows = List<Map<String, dynamic>>.from(rows));
    } catch (_) {
      try {
        final rows = await supabase.from(t).select(other).eq(me, _uid);
        final ids = [for (final r in rows) r[other] as String];
        final ps = ids.isEmpty
            ? []
            : await supabase.from('profiles').select('id, username, display_name').inFilter('id', ids);
        final by = {for (final p in ps) p['id'] as String: p};
        if (mounted) {
          setState(() => _rows = [
                for (final id in ids) {other: id, 'profiles': by[id]}
              ]);
        }
      } catch (_) {}
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _remove(String id) async {
    final (t, me, other) = _cfg;
    try {
      await supabase.from(t).delete().eq(me, _uid).eq(other, id);
      _load();
    } catch (_) {}
  }

  Future<void> _add() async {
    final s = S.of(context);
    final (t, me, other) = _cfg;
    final friends = await loadFriends();
    if (!mounted) return;
    final id = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          for (final f in friends)
            ListTile(title: Text(displayName(f)), onTap: () => Navigator.pop(ctx, f['id'] as String)),
          if (friends.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Text(s.t('no_friends_yet'))),
        ]),
      ),
    );
    if (id == null) return;
    try {
      await supabase.from(t).upsert({me: _uid, other: id});
      _load();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final (_, _, other) = _cfg;
    final title = switch (widget.kind) {
      PeopleListKind.blocked => s.t('blocked_list'),
      PeopleListKind.muted => s.t('muted_list'),
      PeopleListKind.storyHidden => s.t('story_hidden_list'),
    };
    return Scaffold(
      appBar: AppBar(title: Text(title), actions: [
        if (widget.kind != PeopleListKind.blocked)
          IconButton(icon: const Icon(Icons.person_add_alt), onPressed: _add),
      ]),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _rows.isEmpty
              ? Center(child: Text(s.t('nothing_here')))
              : ListView(children: [
                  for (final r in _rows)
                    ListTile(
                      title: Text(displayName(r['profiles'] as Map?)),
                      trailing: TextButton(
                          onPressed: () => _remove(r[other] as String),
                          child: Text(widget.kind == PeopleListKind.blocked ? s.t('unblock') : s.t('remove'))),
                    ),
                ]),
    );
  }
}
