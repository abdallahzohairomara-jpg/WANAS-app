import 'package:flutter/material.dart';

import '../main.dart';
import '../strings.dart';
import 'group_screen.dart';

/// الجروبات: جروباتي + اكتشاف + إنشاء جروب. الدعوات تظهر في الأعلى.
class GroupsScreen extends StatefulWidget {
  const GroupsScreen({super.key});

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  List<Map<String, dynamic>> _mine = [];
  List<Map<String, dynamic>> _found = [];
  final _search = TextEditingController();
  bool _loading = true;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _load() async {
    try {
      final mine = await supabase
          .from('group_members')
          .select('group_id, role, status, groups(id, name, description, privacy)')
          .eq('user_id', _uid)
          .neq('status', 'banned');
      final q = _search.text.trim();
      var fq = supabase.from('groups').select('id, name, description, privacy');
      if (q.isNotEmpty) {
        fq = fq.ilike('name', '%${q.replaceAll(RegExp(r'[%,()*]'), ' ')}%');
      }
      final found = await fq.order('created_at', ascending: false).limit(30);
      if (!mounted) return;
      setState(() {
        _mine = List<Map<String, dynamic>>.from(mine);
        _found = List<Map<String, dynamic>>.from(found);
      });
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _create() async {
    final s = S.of(context);
    final name = TextEditingController();
    final desc = TextEditingController();
    var privacy = 'public';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => AlertDialog(
          title: Text(s.t('new_group')),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, maxLength: 60,
                  decoration: InputDecoration(labelText: s.t('group_name'))),
              TextField(controller: desc, maxLength: 500, maxLines: 3,
                  decoration: InputDecoration(labelText: s.t('group_desc'))),
              DropdownButtonFormField<String>(
                value: privacy,
                decoration: InputDecoration(labelText: s.t('group_privacy')),
                items: [
                  DropdownMenuItem(value: 'public', child: Text(s.t('group_public'))),
                  DropdownMenuItem(value: 'private', child: Text(s.t('group_private'))),
                ],
                onChanged: (v) => setSt(() => privacy = v ?? 'public'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('cancel'))),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(s.t('create'))),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      final id = await supabase.rpc('create_group_space', params: {
        'p_name': name.text.trim(),
        'p_description': desc.text.trim(),
        'p_privacy': privacy,
      });
      await _load();
      if (mounted) {
        await Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => GroupScreen(groupId: id as String)));
        _load();
      }
    } catch (_) {
      if (mounted) _snack(s.t('group_create_failed'));
    }
  }

  Future<void> _answerInvite(String gid, bool accept) async {
    try {
      await supabase.rpc('respond_group_invite', params: {'gid': gid, 'accept': accept});
      await _load();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _open(String gid) async {
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => GroupScreen(groupId: gid)));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final myIds = {for (final m in _mine) m['group_id'] as String};
    final invites = _mine.where((m) => m['status'] == 'invited').toList();
    final active = _mine.where((m) => m['status'] == 'active' || m['status'] == 'pending').toList();
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(s.t('groups')),
          bottom: TabBar(tabs: [Tab(text: s.t('my_groups')), Tab(text: s.t('discover'))]),
        ),
        floatingActionButton: FloatingActionButton(
            onPressed: _create, tooltip: s.t('new_group'), child: const Icon(Icons.group_add)),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(children: [
                ListView(children: [
                  for (final i in invites)
                    Card(
                      margin: const EdgeInsets.all(12),
                      child: ListTile(
                        title: Text((i['groups'] as Map)['name'] as String),
                        subtitle: Text(s.t('group_invited')),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                              icon: const Icon(Icons.check_circle_outline),
                              onPressed: () => _answerInvite(i['group_id'] as String, true)),
                          IconButton(
                              icon: const Icon(Icons.cancel_outlined),
                              onPressed: () => _answerInvite(i['group_id'] as String, false)),
                        ]),
                      ),
                    ),
                  if (active.isEmpty && invites.isEmpty)
                    Padding(
                        padding: const EdgeInsets.all(32),
                        child: Center(child: Text(s.t('no_groups')))),
                  for (final m in active)
                    ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.groups)),
                      title: Text((m['groups'] as Map)['name'] as String),
                      subtitle: Text(m['status'] == 'pending'
                          ? s.t('request_pending')
                          : s.t('role_${m['role']}')),
                      onTap: () => _open(m['group_id'] as String),
                    ),
                ]),
                Column(children: [
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: TextField(
                      controller: _search,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _load(),
                      decoration: InputDecoration(
                          prefixIcon: const Icon(Icons.search), hintText: s.t('search_groups')),
                    ),
                  ),
                  Expanded(
                    child: ListView(children: [
                      for (final g in _found)
                        ListTile(
                          leading: CircleAvatar(
                              child: Icon(g['privacy'] == 'private' ? Icons.lock_outline : Icons.public)),
                          title: Text(g['name'] as String),
                          subtitle: Text(
                              '${s.t(g['privacy'] == 'private' ? 'group_private' : 'group_public')}${myIds.contains(g['id']) ? ' · ${s.t('joined')}' : ''}'),
                          onTap: () => _open(g['id'] as String),
                        ),
                    ]),
                  ),
                ]),
              ]),
      ),
    );
  }
}
