import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';
import '../push.dart';
import '../strings.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _form = GlobalKey<FormState>();
  final _username = TextEditingController();
  final _name = TextEditingController();
  final _bio = TextEditingController();
  String _lang = 'ar';
  String _whoCanMessage = 'everyone';
  String? _avatarUrl;
  bool _loading = true;
  bool _busy = false;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _username.dispose();
    _name.dispose();
    _bio.dispose();
    super.dispose();
  }

  void _snack(String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _load() async {
    try {
      final row =
          await supabase.from('profiles').select().eq('id', _uid).single();
      _username.text = row['username'] ?? '';
      _name.text = row['display_name'] ?? '';
      _bio.text = row['bio'] ?? '';
      _lang = row['lang'] ?? 'ar';
      _whoCanMessage = row['who_can_message'] ?? 'everyone';
      _avatarUrl = row['avatar_url'];
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _pickAvatar() async {
    final picked = await ImagePicker()
        .pickImage(source: ImageSource.gallery, maxWidth: 800, imageQuality: 85);
    if (picked == null) return;
    setState(() => _busy = true);
    try {
      // المسار يبدأ بمعرّف المستخدم لتسهيل سياسات التخزين لاحقًا
      final path = '$_uid/avatar_${DateTime.now().millisecondsSinceEpoch}.jpg';
      await supabase.storage.from('avatars').upload(path, File(picked.path),
          fileOptions: const FileOptions(contentType: 'image/jpeg'));
      final url = supabase.storage.from('avatars').getPublicUrl(path);
      await supabase.from('profiles').update({'avatar_url': url}).eq('id', _uid);
      setState(() => _avatarUrl = url);
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final s = S.of(context);
    setState(() => _busy = true);
    try {
      await supabase.from('profiles').update({
        'username': _username.text.trim(),
        'display_name': _name.text.trim(),
        'bio': _bio.text.trim(),
        'lang': _lang,
        'who_can_message': _whoCanMessage,
      }).eq('id', _uid);
      localeNotifier.value = Locale(_lang);
      if (mounted) _snack(s.t('saved'));
    } on PostgrestException catch (e) {
      // 23505 = unique_violation
      _snack(e.code == '23505' ? s.t('username_taken') : s.t('error'));
    } catch (_) {
      _snack(s.t('error'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _logout() async {
    await PushService.unregister();
    await supabase.auth.signOut();
    if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('profile')), actions: [
        IconButton(
            icon: const Icon(Icons.logout),
            tooltip: s.t('logout'),
            onPressed: _logout),
      ]),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Form(
                  key: _form,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(
                        child: GestureDetector(
                          onTap: _busy ? null : _pickAvatar,
                          child: CircleAvatar(
                            radius: 48,
                            backgroundImage: _avatarUrl != null
                                ? NetworkImage(_avatarUrl!)
                                : null,
                            child: _avatarUrl == null
                                ? const Icon(Icons.add_a_photo, size: 32)
                                : null,
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      TextFormField(
                        controller: _name,
                        decoration:
                            InputDecoration(labelText: s.t('display_name')),
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _username,
                        textDirection: TextDirection.ltr,
                        decoration: InputDecoration(
                            labelText: s.t('username'),
                            helperText: s.t('username_rule')),
                        validator: (v) =>
                            RegExp(r'^[a-zA-Z0-9_]{3,30}$').hasMatch(v ?? '')
                                ? null
                                : s.t('username_rule'),
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _bio,
                        maxLength: 300,
                        maxLines: 3,
                        decoration: InputDecoration(labelText: s.t('bio')),
                      ),
                      const SizedBox(height: 8),
                      DropdownButtonFormField<String>(
                        value: _lang,
                        decoration: InputDecoration(labelText: s.t('language')),
                        items: const [
                          DropdownMenuItem(value: 'ar', child: Text('العربية')),
                          DropdownMenuItem(value: 'en', child: Text('English')),
                        ],
                        onChanged: (v) => setState(() => _lang = v ?? 'ar'),
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: _whoCanMessage,
                        decoration:
                            InputDecoration(labelText: s.t('who_msg')),
                        items: [
                          DropdownMenuItem(
                              value: 'everyone', child: Text(s.t('everyone'))),
                          DropdownMenuItem(
                              value: 'friends', child: Text(s.t('friends'))),
                          DropdownMenuItem(
                              value: 'nobody', child: Text(s.t('nobody'))),
                        ],
                        onChanged: (v) =>
                            setState(() => _whoCanMessage = v ?? 'everyone'),
                      ),
                      const SizedBox(height: 24),
                      FilledButton(
                        onPressed: _busy ? null : _save,
                        child: Text(s.t('save')),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}
