import 'package:flutter/material.dart';

import '../main.dart';
import '../social_helpers.dart';
import '../strings.dart';
import 'chats_screen.dart' show displayName;

/// إدارة الجروب: التعديل، طلبات الانضمام، منشورات تنتظر الموافقة، الأعضاء والصلاحيات، الدعوات.
class GroupAdminScreen extends StatefulWidget {
  final String groupId;
  final bool isOwner;
  const GroupAdminScreen({super.key, required this.groupId, required this.isOwner});

  @override
  State<GroupAdminScreen> createState() => _GroupAdminScreenState();
}

class _GroupAdminScreenState extends State<GroupAdminScreen> {
  final _name = TextEditingController();
  final _desc = TextEditingController();
  final _rules = TextEditingController();
  String _privacy = 'public';
  bool _approval = false;
  List<Map<String, dynamic>> _requests = [];
  List<Map<String, dynamic>> _pendingPosts = [];
  List<Map<String, dynamic>> _members = [];
  List<Map<String, dynamic>> _friends = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _name.dispose();
    _desc.dispose();
    _rules.dispose();
    super.dispose();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _load() async {
    try {
      final g = await supabase.from('groups').select().eq('id', widget.groupId).single();
      _name.text = g['name'] as String;
      _desc.text = g['description'] as String;
      _rules.text = g['rules'] as String;
      _privacy = g['privacy'] as String;
      _approval = g['post_approval'] == true;
      final r = await supabase
          .from('group_members')
          .select('user_id, status, profiles(username, display_name)')
          .eq('group_id', widget.groupId)
          .eq('status', 'pending');
      final m = await supabase
          .from('group_members')
          .select('user_id, role, status, profiles(username, display_name)')
          .eq('group_id', widget.groupId)
          .eq('status', 'active');
      final pp = await supabase
          .from('posts')
          .select('id, body, author:profiles!posts_author_id_fkey(username, display_name)')
          .eq('group_id', widget.groupId)
          .eq('group_status', 'pending');
      final friends = await loadFriends();
      if (!mounted) return;
      setState(() {
        _requests = List<Map<String, dynamic>>.from(r);
        _members = List<Map<String, dynamic>>.from(m);
        _pendingPosts = List<Map<String, dynamic>>.from(pp);
        _friends = friends;
      });
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    try {
      await supabase.from('groups').update({
        'name': _name.text.trim(),
        'description': _desc.text.trim(),
        'rules': _rules.text.trim(),
        'privacy': _privacy,
        'post_approval': _approval,
      }).eq('id', widget.groupId);
      if (mounted) _snack(S.of(context).t('saved'));
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _rpc(String fn, Map<String, dynamic> params) async {
    try {
      await supabase.rpc(fn, params: params);
      await _load();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _deleteGroup() async {
    final s = S.of(context);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('delete_group')),
        content: Text(s.t('delete_group_confirm')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(s.t('delete'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await supabase.from('groups').delete().eq('id', widget.groupId);
      if (mounted) {
        Navigator.of(context).popUntil((r) => r.isFirst);
      }
    } catch (_) {
      if (mounted) _snack(s.t('error'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final memberIds = {for (final m in _members) m['user_id'] as String};
    return Scaffold(
      appBar: AppBar(title: Text(s.t('manage_group'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              TextField(controller: _name, maxLength: 60,
                  decoration: InputDecoration(labelText: s.t('group_name'))),
              TextField(controller: _desc, maxLength: 500, maxLines: 3,
                  decoration: InputDecoration(labelText: s.t('group_desc'))),
              TextField(controller: _rules, maxLength: 2000, maxLines: 4,
                  decoration: InputDecoration(labelText: s.t('group_rules'))),
              DropdownButtonFormField<String>(
                value: _privacy,
                decoration: InputDecoration(labelText: s.t('group_privacy')),
                items: [
                  DropdownMenuItem(value: 'public', child: Text(s.t('group_public'))),
                  DropdownMenuItem(value: 'private', child: Text(s.t('group_private'))),
                ],
                onChanged: (v) => setState(() => _privacy = v ?? 'public'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(s.t('post_approval')),
                subtitle: Text(s.t('post_approval_hint')),
                value: _approval,
                onChanged: (v) => setState(() => _approval = v),
              ),
              FilledButton(onPressed: _save, child: Text(s.t('save'))),
              const Divider(height: 32),
              Text('${s.t('join_requests')} (${_requests.length})',
                  style: Theme.of(context).textTheme.titleMedium),
              for (final r in _requests)
                ListTile(
                  title: Text(displayName(r['profiles'] as Map?)),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(
                        icon: const Icon(Icons.check_circle_outline),
                        onPressed: () => _rpc('respond_group_request',
                            {'gid': widget.groupId, 'uid': r['user_id'], 'approve': true})),
                    IconButton(
                        icon: const Icon(Icons.cancel_outlined),
                        onPressed: () => _rpc('respond_group_request',
                            {'gid': widget.groupId, 'uid': r['user_id'], 'approve': false})),
                  ]),
                ),
              const Divider(height: 32),
              Text('${s.t('pending_posts')} (${_pendingPosts.length})',
                  style: Theme.of(context).textTheme.titleMedium),
              for (final p in _pendingPosts)
                Card(
                  child: ListTile(
                    title: Text(displayName(p['author'] as Map?)),
                    subtitle: Text((p['body'] as String?) ?? '', maxLines: 3, overflow: TextOverflow.ellipsis),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(
                          icon: const Icon(Icons.check_circle_outline),
                          onPressed: () => _rpc('moderate_group_post', {'pid': p['id'], 'approve': true})),
                      IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => _rpc('moderate_group_post', {'pid': p['id'], 'approve': false})),
                    ]),
                  ),
                ),
              const Divider(height: 32),
              Text(s.t('members'), style: Theme.of(context).textTheme.titleMedium),
              for (final m in _members)
                ListTile(
                  title: Text(displayName(m['profiles'] as Map?)),
                  subtitle: Text(s.t('role_${m['role']}')),
                  trailing: m['role'] == 'owner'
                      ? null
                      : PopupMenuButton<String>(
                          onSelected: (v) {
                            final uid = m['user_id'];
                            switch (v) {
                              case 'promote':
                                _rpc('set_group_role', {'gid': widget.groupId, 'uid': uid, 'new_role': 'admin'});
                              case 'demote':
                                _rpc('set_group_role', {'gid': widget.groupId, 'uid': uid, 'new_role': 'member'});
                              case 'remove':
                                _rpc('remove_group_member', {'gid': widget.groupId, 'uid': uid, 'ban': false});
                              default:
                                _rpc('remove_group_member', {'gid': widget.groupId, 'uid': uid, 'ban': true});
                            }
                          },
                          itemBuilder: (_) => [
                            if (widget.isOwner && m['role'] == 'member')
                              PopupMenuItem(value: 'promote', child: Text(s.t('make_admin'))),
                            if (widget.isOwner && m['role'] == 'admin')
                              PopupMenuItem(value: 'demote', child: Text(s.t('remove_admin'))),
                            if (widget.isOwner || m['role'] == 'member')
                              PopupMenuItem(value: 'remove', child: Text(s.t('remove'))),
                            if (widget.isOwner || m['role'] == 'member')
                              PopupMenuItem(value: 'ban', child: Text(s.t('ban'))),
                          ],
                        ),
                ),
              const Divider(height: 32),
              Text(s.t('invite_friends'), style: Theme.of(context).textTheme.titleMedium),
              for (final f in _friends)
                if (!memberIds.contains(f['id']))
                  ListTile(
                    title: Text(displayName(f)),
                    trailing: TextButton(
                        onPressed: () => _rpc('invite_to_group', {'gid': widget.groupId, 'uid': f['id']}),
                        child: Text(s.t('invite'))),
                  ),
              if (widget.isOwner) ...[
                const Divider(height: 32),
                OutlinedButton.icon(
                    onPressed: _deleteGroup,
                    icon: const Icon(Icons.delete_forever),
                    label: Text(s.t('delete_group'))),
              ],
            ]),
    );
  }
}
