import 'package:flutter/material.dart';

import '../main.dart';
import '../strings.dart';
import 'chats_screen.dart' show displayName;

/// دعوات المشاركة في منشورات الآخرين: لا يظهر اسمك على المنشور إلا إذا قبلت.
class InvitationsScreen extends StatefulWidget {
  const InvitationsScreen({super.key});

  @override
  State<InvitationsScreen> createState() => _InvitationsScreenState();
}

class _InvitationsScreenState extends State<InvitationsScreen> {
  List<Map<String, dynamic>> _rows = [];
  bool _loading = true;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = await supabase
          .from('post_participants')
          .select(
              'post_id, posts(body, author:profiles!posts_author_id_fkey(username, display_name))')
          .eq('user_id', _uid)
          .eq('status', 'invited');
      if (mounted) setState(() => _rows = List<Map<String, dynamic>>.from(rows));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(S.of(context).error)));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _answer(String postId, bool accept) async {
    try {
      await supabase
          .from('post_participants')
          .update({'status': accept ? 'accepted' : 'declined'})
          .eq('post_id', postId)
          .eq('user_id', _uid);
      await _load();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(S.of(context).error)));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('invitations'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _rows.isEmpty
              ? Center(child: Text(s.t('no_invitations')))
              : ListView(children: [
                  for (final r in _rows)
                    Card(
                      margin: const EdgeInsets.all(12),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                  '${displayName((r['posts'] as Map?)?['author'] as Map?)} · ${s.t('invited_you')}',
                                  style: Theme.of(context).textTheme.labelLarge),
                              const SizedBox(height: 6),
                              Text(((r['posts'] as Map?)?['body'] as String?) ?? '',
                                  maxLines: 4, overflow: TextOverflow.ellipsis),
                              const SizedBox(height: 8),
                              Row(children: [
                                FilledButton(
                                    onPressed: () => _answer(r['post_id'] as String, true),
                                    child: Text(s.t('accept'))),
                                const SizedBox(width: 8),
                                OutlinedButton(
                                    onPressed: () => _answer(r['post_id'] as String, false),
                                    child: Text(s.t('decline'))),
                              ]),
                            ]),
                      ),
                    ),
                ]),
    );
  }
}
