import 'package:flutter/material.dart';

import '../main.dart';
import '../media/attachments.dart';
import '../media/media_service.dart';
import '../settings_store.dart';
import '../social_helpers.dart';
import '../strings.dart';

/// كتابة منشور: نص + صور + فيديو + ملفات صوتية + كتب + روابط، مع منشن وجدولة وتحكم في التنزيل والشير.
/// إن مُرّر [groupId] يُنشر داخل الجروب (وقد يحتاج موافقة المشرف).
class ComposeScreen extends StatefulWidget {
  final String? groupId;
  const ComposeScreen({super.key, this.groupId});

  @override
  State<ComposeScreen> createState() => _ComposeScreenState();
}

class _ComposeScreenState extends State<ComposeScreen> {
  final _body = TextEditingController();
  final _topics = TextEditingController();
  late String _audience;
  late bool _allowDownload;
  late bool _allowShare;
  DateTime? _publishAt;
  final List<PickedMedia> _media = [];
  final List<String> _links = [];
  List<Map<String, dynamic>> _friends = [];
  String _mentionQuery = '';
  bool _busy = false;
  String _step = '';

  @override
  void initState() {
    super.initState();
    final st = AppSettings.I;
    final a = st.str('default_audience', 'friends');
    _audience = const ['public', 'friends', 'only_me'].contains(a) ? a : 'friends';
    _allowDownload = st.flag('default_allow_download', true);
    _allowShare = st.flag('default_allow_share', true);
    _body.addListener(_onText);
    loadFriends().then((f) {
      if (mounted) setState(() => _friends = f);
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _body.dispose();
    _topics.dispose();
    super.dispose();
  }

  void _onText() {
    final t = _body.text;
    final sel = _body.selection.baseOffset;
    final upto = sel >= 0 && sel <= t.length ? t.substring(0, sel) : t;
    final m = RegExp(r'@([A-Za-z0-9_]*)$').firstMatch(upto);
    final q = m?.group(1) ?? '';
    final active = m != null;
    if (active != _mentionQuery.isNotEmpty || (active && q != _mentionQuery)) {
      setState(() => _mentionQuery = active ? (q.isEmpty ? ' ' : q) : '');
    }
  }

  void _applyMention(String username) {
    final t = _body.text;
    final sel = _body.selection.baseOffset.clamp(0, t.length);
    final before = t.substring(0, sel).replaceFirst(RegExp(r'@[A-Za-z0-9_]*$'), '@$username ');
    _body.value = TextEditingValue(
        text: before + t.substring(sel),
        selection: TextSelection.collapsed(offset: before.length));
    setState(() => _mentionQuery = '');
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  void _addPicked(PickResult r) {
    if (r.rejected > 0) _snack(S.of(context).t('some_files_rejected'));
    setState(() => _media.addAll(r.items));
  }

  Future<void> _addLink() async {
    final s = S.of(context);
    final ctrl = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('add_link')),
        content: TextField(
            controller: ctrl,
            keyboardType: TextInputType.url,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(hintText: 'https://')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: Text(s.t('add'))),
        ],
      ),
    );
    if (url == null || url.isEmpty) return;
    if (!RegExp(r'^https?://\S+$').hasMatch(url)) {
      _snack(s.t('bad_link'));
      return;
    }
    if (_links.length >= 5) return;
    setState(() => _links.add(url));
  }

  Future<void> _pickSchedule() async {
    final now = DateTime.now();
    final d = await showDatePicker(
        context: context,
        initialDate: now.add(const Duration(days: 1)),
        firstDate: now,
        lastDate: now.add(const Duration(days: 365)));
    if (d == null || !mounted) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (t == null) return;
    final at = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    if (at.isBefore(now)) {
      _snack(S.of(context).t('schedule_past'));
      return;
    }
    setState(() => _publishAt = at);
  }

  Future<Map<String, dynamic>?> _preview(String url) async {
    try {
      final res = await supabase.functions.invoke('link-preview', body: {'url': url});
      final d = res.data;
      return d is Map ? Map<String, dynamic>.from(d) : null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _publish() async {
    final s = S.of(context);
    final text = _body.text.trim();
    final inlineLinks = extractLinks(text);
    final allLinks = {..._links, ...inlineLinks}.take(5).toList();
    if (text.isEmpty && _media.isEmpty && allLinks.isEmpty) return;
    setState(() {
      _busy = true;
      _step = s.t('publishing');
    });
    String? postId;
    try {
      final row = await supabase
          .from('posts')
          .insert({
            'body': text,
            'audience': _audience,
            'topics': parseTopics(_topics.text),
            'allow_download': _allowDownload,
            'allow_share': _allowShare,
            if (_publishAt != null) 'publish_at': _publishAt!.toUtc().toIso8601String(),
            if (widget.groupId != null) 'group_id': widget.groupId,
          })
          .select('id, group_status')
          .single();
      postId = row['id'] as String;
      if (_media.isNotEmpty) {
        setState(() => _step = s.t('uploading'));
        await AttachmentUploader.attachToPost(postId, _media);
      }
      for (final u in allLinks) {
        final p = await _preview(u);
        await supabase.from('post_links').insert({
          'post_id': postId,
          'url': u,
          'title': p?['title'],
          'description': p?['description'],
        });
      }
      final mentions = extractMentions(text);
      if (mentions.isNotEmpty) {
        try {
          await supabase.rpc('add_mentions',
              params: {'p_type': 'post', 'p_source': postId, 'p_usernames': mentions});
        } catch (_) {}
      }
      if (mounted) {
        if (row['group_status'] == 'pending') _snack(s.t('post_pending_approval'));
        Navigator.of(context).pop(true);
      }
    } catch (_) {
      if (postId != null) {
        try {
          await supabase.from('posts').delete().eq('id', postId);
        } catch (_) {}
      }
      if (mounted) {
        _snack(s.t('error'));
        setState(() => _busy = false);
      }
    }
  }

  Widget _chip(IconData icon, String label, VoidCallback onTap) => ActionChip(
      avatar: Icon(icon, size: 18), label: Text(label), onPressed: _busy ? null : onTap);

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final suggestions = _mentionQuery.isEmpty
        ? <Map<String, dynamic>>[]
        : _friends
            .where((f) {
              final q = _mentionQuery.trim().toLowerCase();
              return q.isEmpty ||
                  (f['username'] as String).toLowerCase().startsWith(q) ||
                  ((f['display_name'] as String?) ?? '').toLowerCase().contains(q);
            })
            .take(5)
            .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(s.t('new_post')),
        actions: [
          TextButton(
              onPressed: _busy ? null : _publish,
              child: Text(_publishAt != null ? s.t('schedule') : s.t('publish'))),
        ],
      ),
      body: Column(children: [
        if (_busy) const LinearProgressIndicator(),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(16), children: [
            if (_busy) Text(_step),
            if (widget.groupId == null)
              DropdownButtonFormField<String>(
                value: _audience,
                decoration: InputDecoration(labelText: s.t('audience')),
                items: [
                  DropdownMenuItem(value: 'public', child: Text(s.t('aud_public'))),
                  DropdownMenuItem(value: 'friends', child: Text(s.t('aud_friends'))),
                  DropdownMenuItem(value: 'only_me', child: Text(s.t('aud_only_me'))),
                ],
                onChanged: (v) => setState(() => _audience = v ?? 'friends'),
              ),
            const SizedBox(height: 12),
            TextField(
              controller: _body,
              autofocus: true,
              maxLength: 5000,
              minLines: 4,
              maxLines: 12,
              decoration: InputDecoration(hintText: s.t('whats_on_mind')),
            ),
            if (suggestions.isNotEmpty)
              Wrap(spacing: 8, children: [
                for (final f in suggestions)
                  ActionChip(
                      label: Text('@${f['username']}'),
                      onPressed: () => _applyMention(f['username'] as String)),
              ]),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 4, children: [
              _chip(Icons.photo_library_outlined, s.t('add_photos'),
                  () async => _addPicked(await Pickers.images())),
              _chip(Icons.videocam_outlined, s.t('add_video'),
                  () async => _addPicked(await Pickers.video())),
              _chip(Icons.audiotrack_outlined, s.t('add_audio'),
                  () async => _addPicked(await Pickers.audio())),
              _chip(Icons.menu_book_outlined, s.t('add_book'),
                  () async => _addPicked(await Pickers.book())),
              _chip(Icons.link, s.t('add_link'), _addLink),
              _chip(Icons.schedule, s.t('schedule'), _pickSchedule),
            ]),
            if (_publishAt != null)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.schedule),
                title: Text(
                    '${s.t('scheduled_for')}: ${_publishAt!.year}/${_publishAt!.month}/${_publishAt!.day} ${_publishAt!.hour.toString().padLeft(2, '0')}:${_publishAt!.minute.toString().padLeft(2, '0')}'),
                trailing: IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => setState(() => _publishAt = null)),
              ),
            for (var i = 0; i < _media.length; i++)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: _media[i].kind == 'image'
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Image.file(_media[i].file, width: 48, height: 48, fit: BoxFit.cover))
                    : Icon(switch (_media[i].kind) {
                        'video' => Icons.movie,
                        'audio' => Icons.audiotrack,
                        _ => Icons.menu_book,
                      }),
                title: Text(_media[i].title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('${(_media[i].size / (1024 * 1024)).toStringAsFixed(1)} MB'),
                trailing: IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => setState(() => _media.removeAt(i))),
              ),
            for (var i = 0; i < _links.length; i++)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.link),
                title: Text(_links[i], maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => setState(() => _links.removeAt(i))),
              ),
            const SizedBox(height: 8),
            TextField(
              controller: _topics,
              decoration: InputDecoration(
                  labelText: s.t('post_topics'), helperText: s.t('post_topics_hint')),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(s.t('allow_download')),
              value: _allowDownload,
              onChanged: (v) => setState(() => _allowDownload = v),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(s.t('allow_share')),
              value: _allowShare,
              onChanged: (v) => setState(() => _allowShare = v),
            ),
          ]),
        ),
      ]),
    );
  }
}
