import 'package:flutter/material.dart';

import '../main.dart';
import '../strings.dart';

/// محتوى ألبوم. ما فقدتَ صلاحية رؤيته يختفي تلقائيًا (RLS).
class AlbumScreen extends StatefulWidget {
  final String albumId;
  final String title;
  const AlbumScreen({super.key, required this.albumId, required this.title});

  @override
  State<AlbumScreen> createState() => _AlbumScreenState();
}

class _AlbumScreenState extends State<AlbumScreen> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = await supabase
          .from('album_items')
          .select('post_id, added_at, posts(body, created_at)')
          .eq('album_id', widget.albumId)
          .order('added_at', ascending: false);
      if (mounted) setState(() => _items = List<Map<String, dynamic>>.from(rows));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(S.of(context).error)));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _remove(String postId) async {
    try {
      await supabase
          .from('album_items')
          .delete()
          .eq('album_id', widget.albumId)
          .eq('post_id', postId);
      await _load();
    } catch (_) {}
  }

  Future<void> _deleteAlbum() async {
    final s = S.of(context);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('delete_album')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(s.t('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true), child: Text(s.t('delete'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await supabase.from('albums').delete().eq('id', widget.albumId);
      if (mounted) Navigator.of(context).pop();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(widget.title), actions: [
        IconButton(
            tooltip: s.t('delete_album'),
            onPressed: _deleteAlbum,
            icon: const Icon(Icons.delete_outline)),
      ]),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? Center(child: Text(s.t('album_empty')))
              : ListView(children: [
                  for (final i in _items)
                    ListTile(
                      title: Text(((i['posts'] as Map?)?['body'] as String?) ?? '',
                          maxLines: 3, overflow: TextOverflow.ellipsis),
                      trailing: IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () => _remove(i['post_id'] as String),
                      ),
                    ),
                ]),
    );
  }
}
