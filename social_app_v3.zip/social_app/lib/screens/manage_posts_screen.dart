import 'package:flutter/material.dart';

import '../main.dart';
import '../social_helpers.dart';
import '../strings.dart';
import '../widgets/post_card.dart';

/// إدارة منشوراتي: المؤرشفة والمجدولة والمنشورة.
class ManagePostsScreen extends StatefulWidget {
  const ManagePostsScreen({super.key});

  @override
  State<ManagePostsScreen> createState() => _ManagePostsScreenState();
}

class _ManagePostsScreenState extends State<ManagePostsScreen> {
  List<Map<String, dynamic>> _all = [];
  bool _loading = true;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = await supabase
          .from('posts')
          .select(feedPostSelect)
          .eq('author_id', _uid)
          .order('created_at', ascending: false)
          .limit(200);
      if (!mounted) return;
      setState(() => _all = List<Map<String, dynamic>>.from(rows));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(S.of(context).error)));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _unarchive(String id) async {
    try {
      await supabase.from('posts').update({'archived_at': null}).eq('id', id);
      _load();
    } catch (_) {}
  }

  Widget _list(List<Map<String, dynamic>> items, {bool unarchive = false}) {
    final s = S.of(context);
    if (items.isEmpty) return Center(child: Text(s.t('nothing_here')));
    return ListView.separated(
      itemCount: items.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (_, i) => Column(children: [
        PostCard(key: ValueKey(items[i]['id']), post: items[i], onDeleted: _load),
        if (unarchive)
          TextButton.icon(
              onPressed: () => _unarchive(items[i]['id'] as String),
              icon: const Icon(Icons.unarchive_outlined),
              label: Text(s.t('unarchive'))),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final now = DateTime.now().toUtc();
    bool sched(Map p) {
      final t = p['publish_at'] as String?;
      return t != null && DateTime.parse(t).isAfter(now);
    }

    final archived = _all.where((p) => p['archived_at'] != null).toList();
    final scheduled = _all.where((p) => p['archived_at'] == null && sched(p)).toList();
    final live = _all.where((p) => p['archived_at'] == null && !sched(p)).toList();
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(s.t('manage_posts')),
          bottom: TabBar(tabs: [
            Tab(text: s.t('published')),
            Tab(text: s.t('scheduled')),
            Tab(text: s.t('archived')),
          ]),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(children: [
                _list(live),
                _list(scheduled),
                _list(archived, unarchive: true),
              ]),
      ),
    );
  }
}
