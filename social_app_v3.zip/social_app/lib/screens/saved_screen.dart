import 'package:flutter/material.dart';

import '../main.dart';
import '../social_helpers.dart';
import '../strings.dart';
import '../widgets/post_card.dart';
import 'stories/story_viewer_screen.dart';

/// المحفوظات: منشورات وستوريات حفظتها (أنت فقط ترى هذه القائمة).
class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key});

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  List<Map<String, dynamic>> _posts = [];
  List<Map<String, dynamic>> _stories = [];
  bool _loading = true;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final sp = await supabase
          .from('saved_posts')
          .select('post_id, created_at')
          .eq('user_id', _uid)
          .order('created_at', ascending: false)
          .limit(100);
      final ids = [for (final r in sp) r['post_id'] as String];
      var posts = <Map<String, dynamic>>[];
      if (ids.isNotEmpty) {
        final rows = await supabase.from('posts').select(feedPostSelect).inFilter('id', ids);
        final byId = {for (final r in rows) r['id'] as String: Map<String, dynamic>.from(r)};
        posts = [for (final id in ids) if (byId[id] != null) byId[id]!];
      }
      final ss = await supabase
          .from('saved_stories')
          .select('story_id, stories(id, author_id, kind, body, expires_at, profiles:profiles!stories_author_id_fkey(username, display_name))')
          .eq('user_id', _uid)
          .order('created_at', ascending: false)
          .limit(100);
      if (!mounted) return;
      setState(() {
        _posts = posts;
        _stories = [for (final r in ss) if (r['stories'] != null) Map<String, dynamic>.from(r)];
      });
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(S.of(context).error)));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(s.t('saved_items')),
          bottom: TabBar(tabs: [Tab(text: s.t('posts')), Tab(text: s.t('stories'))]),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(children: [
                RefreshIndicator(
                  onRefresh: _load,
                  child: _posts.isEmpty
                      ? ListView(children: [
                          const SizedBox(height: 80),
                          Center(child: Text(s.t('nothing_saved'))),
                        ])
                      : ListView.separated(
                          itemCount: _posts.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (_, i) => PostCard(
                            key: ValueKey(_posts[i]['id']),
                            post: _posts[i],
                            initiallySaved: true,
                            onDeleted: _load,
                          ),
                        ),
                ),
                _stories.isEmpty
                    ? Center(child: Text(s.t('nothing_saved')))
                    : ListView(children: [
                        for (final r in _stories)
                          ListTile(
                            leading: const CircleAvatar(child: Icon(Icons.auto_stories)),
                            title: Text(displayNameOf((r['stories'] as Map)['profiles'] as Map?)),
                            subtitle: Text(((r['stories'] as Map)['body'] as String?) ?? ''),
                            onTap: () => Navigator.of(context).push(MaterialPageRoute(
                                builder: (_) => StoryViewerScreen(
                                    authorIds: [(r['stories'] as Map)['author_id'] as String],
                                    startIndex: 0))),
                          ),
                      ]),
              ]),
      ),
    );
  }
}

String displayNameOf(Map? p) {
  if (p == null) return '';
  final d = (p['display_name'] as String?)?.trim() ?? '';
  return d.isNotEmpty ? d : '@${p['username'] ?? ''}';
}
