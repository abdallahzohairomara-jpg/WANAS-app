import 'package:flutter/material.dart';

import '../main.dart';
import '../social_helpers.dart';
import '../strings.dart';

/// مركز التحكم في الخلاصة: قواعد صريحة يختارها المستخدم (بلا خوارزمية خفية).
class FeedSettingsScreen extends StatefulWidget {
  const FeedSettingsScreen({super.key});

  @override
  State<FeedSettingsScreen> createState() => _FeedSettingsScreenState();
}

class _FeedSettingsScreenState extends State<FeedSettingsScreen> {
  String _mode = 'custom';
  bool _friendsFirst = true;
  bool _listsFirst = true;
  List<Map<String, dynamic>> _topics = [];
  final _topic = TextEditingController();
  String _action = 'more';
  bool _loading = true;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _topic.dispose();
    super.dispose();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _load() async {
    try {
      final p = await supabase
          .from('feed_prefs')
          .select()
          .eq('user_id', _uid)
          .maybeSingle();
      final t = await supabase.from('feed_topics').select().order('topic');
      if (!mounted) return;
      setState(() {
        if (p != null) {
          _mode = p['mode'] as String;
          _friendsFirst = p['friends_first'] as bool;
          _listsFirst = p['lists_first'] as bool;
        }
        _topics = List<Map<String, dynamic>>.from(t);
      });
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _savePrefs() async {
    try {
      await supabase.from('feed_prefs').upsert({
        'user_id': _uid,
        'mode': _mode,
        'friends_first': _friendsFirst,
        'lists_first': _listsFirst,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      });
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _addTopic() async {
    final t = normalizeTopic(_topic.text);
    if (t == null) {
      _snack(S.of(context).t('topic_rule'));
      return;
    }
    try {
      await supabase
          .from('feed_topics')
          .upsert({'user_id': _uid, 'topic': t, 'action': _action});
      _topic.clear();
      await _load();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _removeTopic(String topic) async {
    try {
      await supabase
          .from('feed_topics')
          .delete()
          .eq('user_id', _uid)
          .eq('topic', topic);
      await _load();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _reset() async {
    final s = S.of(context);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('reset_feed')),
        content: Text(s.t('reset_feed_confirm')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(s.t('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(s.t('reset_feed'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await supabase.rpc('reset_feed_prefs');
      setState(() {
        _mode = 'custom';
        _friendsFirst = true;
        _listsFirst = true;
      });
      await _load();
    } catch (_) {
      if (mounted) _snack(s.t('error'));
    }
  }

  String _actionLabel(S s, String a) =>
      s.t(a == 'more' ? 'topic_more' : a == 'less' ? 'topic_less' : 'topic_hide');

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('feed_control'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              Text(s.t('feed_order'),
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: [
                  ButtonSegment(
                      value: 'chronological', label: Text(s.t('mode_chrono'))),
                  ButtonSegment(value: 'custom', label: Text(s.t('mode_custom'))),
                ],
                selected: {_mode},
                onSelectionChanged: (v) {
                  setState(() => _mode = v.first);
                  _savePrefs();
                },
              ),
              const SizedBox(height: 4),
              Text(
                  _mode == 'chronological'
                      ? s.t('mode_chrono_hint')
                      : s.t('mode_custom_hint'),
                  style: Theme.of(context).textTheme.bodySmall),
              if (_mode == 'custom') ...[
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(s.t('friends_first')),
                  value: _friendsFirst,
                  onChanged: (v) {
                    setState(() => _friendsFirst = v);
                    _savePrefs();
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(s.t('lists_first')),
                  value: _listsFirst,
                  onChanged: (v) {
                    setState(() => _listsFirst = v);
                    _savePrefs();
                  },
                ),
              ],
              const Divider(height: 32),
              Text(s.t('topics'), style: Theme.of(context).textTheme.titleMedium),
              Text(s.t('topics_hint'),
                  style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: _topic,
                    maxLength: 30,
                    decoration: InputDecoration(
                        labelText: s.t('topic_name'), counterText: ''),
                    onSubmitted: (_) => _addTopic(),
                  ),
                ),
                const SizedBox(width: 8),
                DropdownButton<String>(
                  value: _action,
                  items: [
                    for (final a in const ['more', 'less', 'hide'])
                      DropdownMenuItem(value: a, child: Text(_actionLabel(s, a))),
                  ],
                  onChanged: (v) => setState(() => _action = v ?? 'more'),
                ),
                IconButton(onPressed: _addTopic, icon: const Icon(Icons.add)),
              ]),
              const SizedBox(height: 8),
              if (_topics.isEmpty)
                Text(s.t('no_topics'))
              else
                Wrap(spacing: 8, runSpacing: 4, children: [
                  for (final t in _topics)
                    InputChip(
                      label: Text('${t['topic']} · ${_actionLabel(s, t['action'] as String)}'),
                      onDeleted: () => _removeTopic(t['topic'] as String),
                    ),
                ]),
              const Divider(height: 32),
              OutlinedButton.icon(
                onPressed: _reset,
                icon: const Icon(Icons.restart_alt),
                label: Text(s.t('reset_feed')),
              ),
            ]),
    );
  }
}
