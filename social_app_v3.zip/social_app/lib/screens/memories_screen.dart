import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../main.dart';
import '../social_helpers.dart';
import '../strings.dart';
import 'album_screen.dart';

String _date(String? iso) {
  final d = DateTime.tryParse(iso ?? '')?.toLocal();
  return d == null ? '' : '${d.year}/${d.month}/${d.day}';
}

/// الذكريات: خط زمني لمنشوراتي، "في مثل هذا اليوم"، وألبوماتي الخاصة.
/// ما لا أملك صلاحية رؤيته الآن لا يظهر هنا (تفرضه قاعدة البيانات).
class MemoriesScreen extends StatefulWidget {
  const MemoriesScreen({super.key});

  @override
  State<MemoriesScreen> createState() => _MemoriesScreenState();
}

class _MemoriesScreenState extends State<MemoriesScreen> {
  List<Map<String, dynamic>> _timeline = [];
  List<Map<String, dynamic>> _today = [];
  List<Map<String, dynamic>> _albums = [];
  bool _remind = false;
  bool _loading = true;
  final _search = TextEditingController();

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _load() async {
    try {
      var q = supabase.from('posts').select('id, body, audience, created_at').eq('author_id', _uid);
      final text = _search.text.trim();
      if (text.isNotEmpty) {
        // إزالة محارف قد تكسر مرشّح PostgREST
        q = q.ilike('body', '%${text.replaceAll(RegExp(r'[%,()*]'), ' ')}%');
      }
      final t = await q.order('created_at', ascending: false).limit(200);
      final d = await supabase.rpc('on_this_day', params: {'p_tz': deviceTz()});
      final a = await supabase.from('albums').select().order('created_at');
      final m = await supabase
          .from('memory_settings')
          .select('on_this_day')
          .eq('user_id', _uid)
          .maybeSingle();
      if (!mounted) return;
      setState(() {
        _timeline = List<Map<String, dynamic>>.from(t);
        _today = List<Map<String, dynamic>>.from(d as List);
        _albums = List<Map<String, dynamic>>.from(a);
        _remind = m?['on_this_day'] == true;
      });
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _toggleRemind(bool v) async {
    setState(() => _remind = v);
    try {
      await supabase
          .from('memory_settings')
          .upsert({'user_id': _uid, 'on_this_day': v});
    } catch (_) {
      if (mounted) {
        setState(() => _remind = !v);
        _snack(S.of(context).error);
      }
    }
  }

  Future<void> _export() async {
    try {
      final j = await supabase.rpc('export_my_memories');
      await Clipboard.setData(
          ClipboardData(text: const JsonEncoder.withIndent('  ').convert(j)));
      if (mounted) _snack(S.of(context).t('exported'));
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _newAlbum() async {
    final s = S.of(context);
    final ctrl = TextEditingController();
    final title = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('new_album')),
        content: TextField(
            controller: ctrl,
            maxLength: 60,
            autofocus: true,
            decoration: InputDecoration(labelText: s.t('album_title'))),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: Text(s.t('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: Text(s.t('save'))),
        ],
      ),
    );
    if (title == null || title.isEmpty) return;
    try {
      await supabase.from('albums').insert({'title': title});
      await _load();
    } catch (_) {
      if (mounted) _snack(s.t('album_limit'));
    }
  }

  Widget _postTile(Map<String, dynamic> p) => ListTile(
        title: Text((p['body'] as String?) ?? '', maxLines: 3, overflow: TextOverflow.ellipsis),
        subtitle: Text(_date(p['created_at'] as String?)),
      );

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(s.t('memories')),
          actions: [
            IconButton(
                tooltip: s.t('export_memories'),
                onPressed: _export,
                icon: const Icon(Icons.ios_share)),
          ],
          bottom: TabBar(tabs: [
            Tab(text: s.t('timeline')),
            Tab(text: s.t('on_this_day')),
            Tab(text: s.t('albums')),
          ]),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(children: [
                // الخط الزمني
                Column(children: [
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: TextField(
                      controller: _search,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _load(),
                      decoration: InputDecoration(
                          prefixIcon: const Icon(Icons.search),
                          hintText: s.t('search_memories')),
                    ),
                  ),
                  Expanded(
                    child: _timeline.isEmpty
                        ? Center(child: Text(s.t('no_memories')))
                        : ListView.builder(
                            itemCount: _timeline.length,
                            itemBuilder: (_, i) {
                              final p = _timeline[i];
                              final y = DateTime.tryParse(p['created_at'] ?? '')?.toLocal().year;
                              final prev = i == 0
                                  ? null
                                  : DateTime.tryParse(_timeline[i - 1]['created_at'] ?? '')?.toLocal().year;
                              return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    if (y != prev)
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                                        child: Text('$y',
                                            style: Theme.of(context).textTheme.titleLarge),
                                      ),
                                    _postTile(p),
                                  ]);
                            },
                          ),
                  ),
                ]),
                // في مثل هذا اليوم
                Column(children: [
                  SwitchListTile(
                    title: Text(s.t('remind_on_this_day')),
                    value: _remind,
                    onChanged: _toggleRemind,
                  ),
                  Expanded(
                    child: _today.isEmpty
                        ? Center(child: Text(s.t('nothing_today')))
                        : ListView(children: [for (final p in _today) _postTile(p)]),
                  ),
                ]),
                // الألبومات
                Scaffold(
                  floatingActionButton: FloatingActionButton.small(
                      onPressed: _newAlbum, child: const Icon(Icons.add)),
                  body: _albums.isEmpty
                      ? Center(child: Text(s.t('no_albums')))
                      : ListView(children: [
                          for (final a in _albums)
                            ListTile(
                              leading: const Icon(Icons.photo_album_outlined),
                              title: Text(a['title'] as String),
                              onTap: () async {
                                await Navigator.of(context).push(MaterialPageRoute(
                                    builder: (_) => AlbumScreen(
                                        albumId: a['id'] as String,
                                        title: a['title'] as String)));
                                _load();
                              },
                            ),
                        ]),
                ),
              ]),
      ),
    );
  }
}
