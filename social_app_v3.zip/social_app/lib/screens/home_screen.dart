import 'package:flutter/material.dart';

import '../main.dart';
import '../push.dart';
import '../social_helpers.dart';
import '../strings.dart';
import '../widgets/post_card.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'call_screen.dart';
import 'chats_screen.dart';
import '../settings_store.dart';
import 'compose_screen.dart';
import 'groups_screen.dart';
import 'saved_screen.dart';
import 'settings/settings_screen.dart';
import 'stories/story_tray.dart';
import 'manage_posts_screen.dart';
import 'feed_settings_screen.dart';
import 'invitations_screen.dart';
import 'memories_screen.dart';
import 'people_screen.dart';
import 'profile_screen.dart';

/// الخلاصة الزمنية. الصلاحيات تُفرض في قاعدة البيانات (RLS)،
/// فالاستعلام يرجع فقط المنشورات التي يحق للمستخدم رؤيتها.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, dynamic>> _posts = [];
  Set<String> _saved = {};
  bool _loading = true;
  bool _error = false;
  int _todayCount = 0;
  bool _bannerDismissed = false;

  RealtimeChannel? _callChannel;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    AppSettings.I.load();
    _load();
    _listenForCalls();
    PushService.init();
  }

  @override
  void dispose() {
    _callChannel?.unsubscribe();
    super.dispose();
  }

  /// إشعار المكالمات الواردة داخل التطبيق فقط (والتطبيق مفتوح).
  /// الرنين والتطبيق مغلق يحتاج Firebase Cloud Messaging وشاشة اتصال النظام.
  void _listenForCalls() {
    _callChannel = supabase
        .channel('incoming-calls')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'calls',
          callback: (payload) async {
            final call = Map<String, dynamic>.from(payload.newRecord);
            if (call['caller_id'] == _uid || !mounted) return;
            String name = '';
            try {
              final p = await supabase
                  .from('profiles')
                  .select('username, display_name')
                  .eq('id', call['caller_id'])
                  .single();
              name = displayName(p);
            } catch (_) {}
            if (!mounted) return;
            _showIncoming(call, name);
          },
        )
        .subscribe();
  }

  Future<void> _showIncoming(Map<String, dynamic> call, String name) async {
    final s = S.of(context);
    final accept = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        icon: Icon(call['is_video'] == true ? Icons.videocam : Icons.call),
        title: Text('$name ${s.t('incoming_call')}'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(s.t('decline'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(s.t('accept'))),
        ],
      ),
    );
    if (accept != true || !mounted) return;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => CallScreen(
        callId: call['id'] as String,
        conversationId: call['conversation_id'] as String,
        provider: call['provider'] as String,
        video: call['is_video'] as bool,
        title: name,
      ),
    ));
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = false;
    });
    try {
      // الترتيب والإخفاء تقررهما دالة get_feed حسب إعدادات مركز التحكم
      final order = List<Map<String, dynamic>>.from(
          await supabase.rpc('get_feed', params: {'p_limit': 50, 'p_offset': 0}) as List);
      final reasons = {for (final o in order) o['post_id'] as String: o['reason'] as String};
      final orderIds = order.map((o) => o['post_id'] as String).toList();
      var posts = <Map<String, dynamic>>[];
      if (orderIds.isNotEmpty) {
        final rows = await supabase
            .from('posts')
            .select(
                '*, author:profiles!posts_author_id_fkey(username, display_name, avatar_url), comments(count), group:groups(id, name), post_media(id, storage_path, thumb_path, kind, title, mime), post_links(id, url, title, description), post_participants(user_id, status)')
            .inFilter('id', orderIds);
        final byId = {for (final r in rows) r['id'] as String: Map<String, dynamic>.from(r)};
        posts = [
          for (final id in orderIds)
            if (byId[id] != null) {...byId[id]!, 'feed_reason': reasons[id]}
        ];
      }
      final ids = posts.map((p) => p['id'] as String).toList();
      Set<String> saved = {};
      if (ids.isNotEmpty) {
        final s = await supabase
            .from('saved_posts')
            .select('post_id')
            .eq('user_id', _uid)
            .inFilter('post_id', ids);
        saved = {for (final r in s) r['post_id'] as String};
      }
      int today = 0;
      try {
        final m = await supabase
            .from('memory_settings')
            .select('on_this_day')
            .eq('user_id', _uid)
            .maybeSingle();
        if (m?['on_this_day'] == true) {
          today = ((await supabase.rpc('on_this_day', params: {'p_tz': deviceTz()})) as List).length;
        }
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _todayCount = today;
        _posts = posts;
        _saved = saved;
      });
    } catch (_) {
      if (mounted) setState(() => _error = true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _compose() async {
    final posted = await Navigator.of(context)
        .push<bool>(MaterialPageRoute(builder: (_) => const ComposeScreen()));
    if (posted == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(s.t('app_name')),
        actions: [
          IconButton(
            icon: const Icon(Icons.chat_bubble_outline),
            tooltip: s.t('chats'),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const ChatsScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.group),
            tooltip: s.t('people'),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const PeopleScreen()))
                .then((_) => _load()),
          ),
          IconButton(
            icon: const Icon(Icons.person),
            tooltip: s.t('profile'),
            onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ProfileScreen())),
          ),
          PopupMenuButton<String>(
            onSelected: (v) async {
              final Widget page = switch (v) {
                'feed' => const FeedSettingsScreen(),
                'memories' => const MemoriesScreen(),
                'groups' => const GroupsScreen(),
                'saved' => const SavedScreen(),
                'manage' => const ManagePostsScreen(),
                'settings' => const SettingsScreen(),
                _ => const InvitationsScreen(),
              };
              await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => page));
              _load();
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'groups', child: Text(s.t('groups'))),
              PopupMenuItem(value: 'saved', child: Text(s.t('saved_items'))),
              PopupMenuItem(value: 'feed', child: Text(s.t('feed_control'))),
              PopupMenuItem(value: 'memories', child: Text(s.t('memories'))),
              PopupMenuItem(value: 'manage', child: Text(s.t('manage_posts'))),
              PopupMenuItem(value: 'invites', child: Text(s.t('invitations'))),
              PopupMenuItem(value: 'settings', child: Text(s.t('settings'))),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _compose,
        tooltip: s.t('new_post'),
        child: const Icon(Icons.edit),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error
                ? ListView(children: [
                    const SizedBox(height: 120),
                    Center(child: Text(s.t('error'))),
                    Center(
                        child: TextButton(
                            onPressed: _load, child: const Icon(Icons.refresh))),
                  ])
                : _posts.isEmpty
                    ? ListView(children: [
                        const StoryTray(),
                        const SizedBox(height: 80),
                        Padding(
                          padding: const EdgeInsets.all(24),
                          child: Center(
                              child: Text(s.t('empty_feed'),
                                  textAlign: TextAlign.center)),
                        ),
                      ])
                    : ListView.separated(
                        padding: const EdgeInsets.only(bottom: 88),
                        itemCount: _posts.length + 1,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (_, i) {
                          if (i == 0) {
                            return Column(children: [
                              const StoryTray(),
                              if (_todayCount > 0 && !_bannerDismissed) ListTile(
                              leading: const Icon(Icons.history),
                              title: Text(s.t('on_this_day')),
                              subtitle: Text('$_todayCount'),
                              trailing: IconButton(
                                icon: const Icon(Icons.close),
                                onPressed: () =>
                                    setState(() => _bannerDismissed = true),
                              ),
                              onTap: () => Navigator.of(context).push(
                                  MaterialPageRoute(
                                      builder: (_) => const MemoriesScreen())),
                              ),
                            ]);
                          }
                          final p = _posts[i - 1];
                          final id = p['id'] as String;
                          return PostCard(
                            key: ValueKey(id),
                            post: p,
                            initiallySaved: _saved.contains(id),
                            onDeleted: _load,
                          );
                        },
                      ),
      ),
    );
  }
}
