import 'package:flutter/material.dart';

import '../main.dart';
import '../strings.dart';
import 'chat_screen.dart';
import 'new_chat_screen.dart';

String displayName(Map? p) {
  if (p == null) return '';
  final d = p['display_name'] as String?;
  return (d != null && d.isNotEmpty) ? d : (p['username'] ?? '') as String;
}

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});

  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  List<Map<String, dynamic>> _chats = [];
  bool _loading = true;
  bool _error = false;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final mine = await supabase
          .from('conversation_members')
          .select('conversation_id, conversations(id, is_group, title, last_message_at)')
          .eq('user_id', _uid);
      final convs = <Map<String, dynamic>>[];
      for (final r in mine) {
        final c = r['conversations'];
        if (c != null) convs.add(Map<String, dynamic>.from(c));
      }
      final dmIds =
          convs.where((c) => c['is_group'] == false).map((c) => c['id']).toList();
      final others = <String, String>{};
      if (dmIds.isNotEmpty) {
        final rows = await supabase
            .from('conversation_members')
            .select('conversation_id, profiles(username, display_name)')
            .inFilter('conversation_id', dmIds)
            .neq('user_id', _uid);
        for (final r in rows) {
          others[r['conversation_id'] as String] = displayName(r['profiles'] as Map?);
        }
      }
      for (final c in convs) {
        c['name'] = c['is_group'] == true
            ? (c['title'] ?? '')
            : (others[c['id']] ?? '');
      }
      convs.sort((a, b) =>
          (b['last_message_at'] as String).compareTo(a['last_message_at'] as String));
      if (mounted) setState(() => _chats = convs);
    } catch (_) {
      if (mounted) setState(() => _error = true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _new() async {
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const NewChatScreen()));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('chats'))),
      floatingActionButton: FloatingActionButton(
          onPressed: _new, tooltip: s.t('new_chat'), child: const Icon(Icons.add)),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error
                ? ListView(children: [
                    const SizedBox(height: 120),
                    Center(child: Text(s.t('error')))
                  ])
                : _chats.isEmpty
                    ? ListView(children: [
                        const SizedBox(height: 120),
                        Center(child: Text(s.t('no_chats')))
                      ])
                    : ListView.builder(
                        itemCount: _chats.length,
                        itemBuilder: (_, i) {
                          final c = _chats[i];
                          return ListTile(
                            leading: CircleAvatar(
                                child: Icon(c['is_group'] == true
                                    ? Icons.group
                                    : Icons.person)),
                            title: Text(c['name'] ?? ''),
                            onTap: () async {
                              await Navigator.of(context).push(MaterialPageRoute(
                                  builder: (_) => ChatScreen(
                                      conversationId: c['id'] as String,
                                      title: c['name'] ?? '')));
                              _load();
                            },
                          );
                        },
                      ),
      ),
    );
  }
}
