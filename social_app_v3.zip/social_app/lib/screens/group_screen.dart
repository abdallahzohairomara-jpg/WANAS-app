import 'package:flutter/material.dart';

import '../main.dart';
import '../social_helpers.dart';
import '../strings.dart';
import '../widgets/post_card.dart';
import 'chats_screen.dart' show displayName;
import 'compose_screen.dart';
import 'group_admin_screen.dart';

/// صفحة جروب: المنشورات، الأعضاء، الانضمام والمغادرة.
/// محتوى الجروب الخاص لا يظهر لغير الأعضاء (تفرضه قاعدة البيانات).
class GroupScreen extends StatefulWidget {
  final String groupId;
  const GroupScreen({super.key, required this.groupId});

  @override
  State<GroupScreen> createState() => _GroupScreenState();
}

class _GroupScreenState extends State<GroupScreen> {
  Map<String, dynamic>? _group;
  String? _role; // دوري إن كنت عضوًا نشطًا
  String? _status; // حالتي: active/pending/invited/null
  List<Map<String, dynamic>> _posts = [];
  Set<String> _saved = {};
  List<Map<String, dynamic>> _members = [];
  bool _loading = true;

  String get _uid => supabase.auth.currentUser!.id;
  bool get _isAdmin => _role == 'owner' || _role == 'admin';

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _load() async {
    try {
      final g = await supabase.from('groups').select().eq('id', widget.groupId).single();
      final me = await supabase
          .from('group_members')
          .select('role, status')
          .eq('group_id', widget.groupId)
          .eq('user_id', _uid)
          .maybeSingle();
      final status = me?['status'] as String?;
      final role = status == 'active' ? me?['role'] as String? : null;
      var posts = <Map<String, dynamic>>[];
      var members = <Map<String, dynamic>>[];
      final canSee = role != null || g['privacy'] == 'public';
      if (canSee) {
        final rows = await supabase
            .from('posts')
            .select(feedPostSelect)
            .eq('group_id', widget.groupId)
            .order('created_at', ascending: false)
            .limit(50);
        posts = List<Map<String, dynamic>>.from(rows);
        final m = await supabase
            .from('group_members')
            .select('user_id, role, status, profiles(username, display_name)')
            .eq('group_id', widget.groupId)
            .eq('status', 'active');
        members = List<Map<String, dynamic>>.from(m);
      }
      Set<String> saved = {};
      if (posts.isNotEmpty) {
        final r = await supabase
            .from('saved_posts')
            .select('post_id')
            .eq('user_id', _uid)
            .inFilter('post_id', posts.map((p) => p['id'] as String).toList());
        saved = {for (final x in r) x['post_id'] as String};
      }
      if (!mounted) return;
      setState(() {
        _group = Map<String, dynamic>.from(g);
        _status = status;
        _role = role;
        _posts = posts;
        _members = members;
        _saved = saved;
      });
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _join() async {
    try {
      await supabase.rpc('join_group', params: {'gid': widget.groupId});
      await _load();
    } catch (_) {
      if (mounted) _snack(S.of(context).t('join_failed'));
    }
  }

  Future<void> _leave() async {
    try {
      await supabase.rpc('leave_group', params: {'gid': widget.groupId});
      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      if (mounted) _snack(S.of(context).t('owner_cannot_leave'));
    }
  }

  Future<void> _compose() async {
    final ok = await Navigator.of(context).push<bool>(
        MaterialPageRoute(builder: (_) => ComposeScreen(groupId: widget.groupId)));
    if (ok == true) _load();
  }

  Future<void> _report() async {
    final s = S.of(context);
    final ctrl = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('report')),
        content: TextField(controller: ctrl, maxLength: 500,
            decoration: InputDecoration(labelText: s.t('report_reason'))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text.trim()), child: Text(s.t('send'))),
        ],
      ),
    );
    if (reason == null || reason.length < 3) return;
    try {
      await supabase.from('reports').insert(
          {'target_type': 'group', 'target_id': widget.groupId, 'reason': reason});
      if (mounted) _snack(s.t('report_sent'));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final g = _group;
    if (_loading || g == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    }
    final canSee = _role != null || g['privacy'] == 'public';
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(g['name'] as String),
          actions: [
            if (_isAdmin)
              IconButton(
                tooltip: s.t('manage_group'),
                icon: const Icon(Icons.admin_panel_settings_outlined),
                onPressed: () async {
                  await Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => GroupAdminScreen(groupId: widget.groupId, isOwner: _role == 'owner')));
                  _load();
                },
              ),
            PopupMenuButton<String>(
              onSelected: (v) => v == 'leave' ? _leave() : _report(),
              itemBuilder: (_) => [
                if (_role != null) PopupMenuItem(value: 'leave', child: Text(s.t('leave_group'))),
                PopupMenuItem(value: 'report', child: Text(s.t('report'))),
              ],
            ),
          ],
          bottom: canSee
              ? TabBar(tabs: [Tab(text: s.t('posts')), Tab(text: '${s.t('members')} (${_members.length})')])
              : null,
        ),
        floatingActionButton: _role != null
            ? FloatingActionButton(onPressed: _compose, child: const Icon(Icons.edit))
            : null,
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(g['privacy'] == 'private' ? Icons.lock_outline : Icons.public, size: 18),
                const SizedBox(width: 6),
                Text(s.t(g['privacy'] == 'private' ? 'group_private' : 'group_public')),
              ]),
              if ((g['description'] as String).isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(g['description'] as String),
              ],
              if ((g['rules'] as String).isNotEmpty)
                ExpansionTile(
                  tilePadding: EdgeInsets.zero,
                  title: Text(s.t('group_rules')),
                  children: [Align(alignment: AlignmentDirectional.centerStart, child: Text(g['rules'] as String))],
                ),
              const SizedBox(height: 8),
              if (_role == null)
                _status == 'pending'
                    ? Chip(label: Text(s.t('request_pending')))
                    : FilledButton(
                        onPressed: _join,
                        child: Text(_status == 'invited'
                            ? s.t('accept')
                            : g['privacy'] == 'private'
                                ? s.t('request_join')
                                : s.t('join'))),
            ]),
          ),
          const Divider(),
          Expanded(
            child: !canSee
                ? Center(child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(s.t('private_group_hint'), textAlign: TextAlign.center)))
                : TabBarView(children: [
                    RefreshIndicator(
                      onRefresh: _load,
                      child: _posts.isEmpty
                          ? ListView(children: [
                              const SizedBox(height: 80),
                              Center(child: Text(s.t('group_no_posts'))),
                            ])
                          : ListView.separated(
                              padding: const EdgeInsets.only(bottom: 88),
                              itemCount: _posts.length,
                              separatorBuilder: (_, __) => const Divider(height: 1),
                              itemBuilder: (_, i) {
                                final p = _posts[i];
                                final id = p['id'] as String;
                                return PostCard(
                                  key: ValueKey(id),
                                  post: p,
                                  initiallySaved: _saved.contains(id),
                                  onDeleted: _load,
                                );
                              },
                            ),
                    ),
                    ListView(children: [
                      for (final m in _members)
                        ListTile(
                          leading: const CircleAvatar(child: Icon(Icons.person)),
                          title: Text(displayName(m['profiles'] as Map?)),
                          subtitle: Text(s.t('role_${m['role']}')),
                        ),
                    ]),
                  ]),
          ),
        ]),
      ),
    );
  }
}
