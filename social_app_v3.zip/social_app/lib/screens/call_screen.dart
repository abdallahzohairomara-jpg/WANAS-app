import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../calls/agora_engine.dart';
import '../calls/call_engine.dart';
import '../calls/call_service.dart';
import '../main.dart';
import '../strings.dart';
import 'chats_screen.dart' show displayName;

class CallScreen extends StatefulWidget {
  final String callId;
  final String conversationId;
  final String provider;
  final bool video;
  final String title;

  const CallScreen({
    super.key,
    required this.callId,
    required this.conversationId,
    required this.provider,
    required this.video,
    required this.title,
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  late final CallEngine _engine = CallService.createEngine(widget.provider);
  final Map<String, String> _names = {};
  bool _connecting = true;
  String? _error;
  bool _left = false;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _engine.addListener(() {
      if (mounted) setState(() {});
    });
    // بعد أول إطار لأن S.of(context) لا يصح استدعاؤه داخل initState
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  Future<void> _start() async {
    final s = S.of(context);
    try {
      final perms = [Permission.microphone, if (widget.video) Permission.camera];
      final res = await perms.request();
      if (res.values.any((p) => !p.isGranted)) {
        setState(() => _error = s.t('perm_denied'));
        return;
      }

      final members = await supabase
          .from('conversation_members')
          .select('user_id, profiles(username, display_name)')
          .eq('conversation_id', widget.conversationId);
      for (final m in members) {
        _names[m['user_id'] as String] = displayName(m['profiles'] as Map?);
      }
      if (_engine is AgoraEngine) {
        (_engine as AgoraEngine).registerMembers(_names.keys);
      }

      final creds = await CallService.fetchCredentials(
          conversationId: widget.conversationId, provider: widget.provider);
      await _engine.join(creds, video: widget.video, myUserId: _uid);
      if (mounted) setState(() => _connecting = false);
    } on FunctionException catch (e) {
      final notConfigured = e.details.toString().contains('not configured');
      if (mounted) {
        setState(() =>
            _error = notConfigured ? s.t('call_not_configured') : s.t('call_failed'));
      }
    } catch (_) {
      if (mounted) setState(() => _error = s.t('call_failed'));
    }
  }

  Future<void> _hangUp() async {
    if (_left) return;
    _left = true;
    // إن كنت الوحيد في المكالمة عند الخروج فهي انتهت
    final alone = _engine.participants.length <= 1;
    await _engine.leave();
    if (alone) await CallService.endCall(widget.callId);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() {
    if (!_left) {
      _left = true;
      _engine.leave();
    }
    _engine.dispose();
    super.dispose();
  }

  Widget _tile(CallParticipant p) {
    final name = p.isLocal ? S.of(context).t('you') : (_names[p.userId] ?? '');
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Container(
        color: Colors.grey.shade900,
        child: Stack(fit: StackFit.expand, children: [
          if (p.video != null)
            p.video!
          else
            Center(
                child: CircleAvatar(
                    radius: 32,
                    child: Text(name.isNotEmpty ? name[0] : '?',
                        style: const TextStyle(fontSize: 28)))),
          PositionedDirectional(
            start: 8,
            bottom: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                  color: Colors.black54, borderRadius: BorderRadius.circular(8)),
              child: Text(name,
                  style: const TextStyle(color: Colors.white, fontSize: 12)),
            ),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final parts = _engine.participants;
    final cols = parts.length <= 1 ? 1 : (parts.length <= 4 ? 2 : 3);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _hangUp();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          automaticallyImplyLeading: false,
          title: Text('${widget.title} · ${callProviders[widget.provider]}'),
        ),
        body: SafeArea(
          child: _error != null
              ? Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(_error!,
                            style: const TextStyle(color: Colors.white),
                            textAlign: TextAlign.center)),
                    FilledButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: Text(s.t('cancel'))),
                  ]),
                )
              : _connecting
                  ? const Center(child: CircularProgressIndicator())
                  : Column(children: [
                      Expanded(
                        child: GridView.count(
                          padding: const EdgeInsets.all(8),
                          crossAxisCount: cols,
                          mainAxisSpacing: 8,
                          crossAxisSpacing: 8,
                          children: [for (final p in parts) _tile(p)],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              IconButton.filledTonal(
                                tooltip: s.t('mic'),
                                onPressed: _engine.toggleMic,
                                icon: Icon(
                                    _engine.micOn ? Icons.mic : Icons.mic_off),
                              ),
                              IconButton.filledTonal(
                                tooltip: s.t('camera'),
                                onPressed: _engine.toggleCamera,
                                icon: Icon(_engine.camOn
                                    ? Icons.videocam
                                    : Icons.videocam_off),
                              ),
                              IconButton.filledTonal(
                                onPressed:
                                    _engine.camOn ? _engine.switchCamera : null,
                                icon: const Icon(Icons.cameraswitch),
                              ),
                              IconButton.filled(
                                tooltip: s.t('hang_up'),
                                style: IconButton.styleFrom(
                                    backgroundColor: Colors.red),
                                onPressed: _hangUp,
                                icon: const Icon(Icons.call_end),
                              ),
                            ]),
                      ),
                    ]),
        ),
      ),
    );
  }
}
