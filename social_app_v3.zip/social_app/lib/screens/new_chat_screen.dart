import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';
import '../strings.dart';
import 'chat_screen.dart';
import 'chats_screen.dart' show displayName;

class NewChatScreen extends StatefulWidget {
  const NewChatScreen({super.key});

  @override
  State<NewChatScreen> createState() => _NewChatScreenState();
}

class _NewChatScreenState extends State<NewChatScreen> {
  List<Map<String, dynamic>> _friends = [];
  final Set<String> _selected = {};
  bool _loading = true;
  bool _busy = false;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = await supabase
          .from('friendships')
          .select('requester_id, addressee_id')
          .eq('status', 'accepted');
      final ids = <String>[
        for (final r in rows)
          (r['requester_id'] == _uid ? r['addressee_id'] : r['requester_id'])
              as String
      ];
      if (ids.isNotEmpty) {
        final profs = await supabase
            .from('profiles')
            .select('id, username, display_name')
            .inFilter('id', ids);
        _friends = List<Map<String, dynamic>>.from(profs);
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(S.of(context).error)));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<String?> _askGroupName() {
    final s = S.of(context);
    final ctrl = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('group_name')),
        content: TextField(controller: ctrl, maxLength: 60, autofocus: true),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: Text(s.t('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: Text(s.t('start'))),
        ],
      ),
    );
  }

  Future<void> _start() async {
    if (_selected.isEmpty) return;
    final s = S.of(context);
    setState(() => _busy = true);
    try {
      String convId;
      String title;
      if (_selected.length == 1) {
        final id = _selected.first;
        convId = await supabase.rpc('get_or_create_dm', params: {'other': id});
        title = displayName(_friends.firstWhere((f) => f['id'] == id));
      } else {
        final name = await _askGroupName();
        if (name == null || name.isEmpty) {
          setState(() => _busy = false);
          return;
        }
        convId = await supabase.rpc('create_group',
            params: {'title': name, 'member_ids': _selected.toList()});
        title = name;
      }
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (_) => ChatScreen(conversationId: convId, title: title)));
    } on PostgrestException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(e.message.contains('not allowed')
                ? s.t('not_allowed')
                : s.t('error'))));
        setState(() => _busy = false);
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(s.t('error'))));
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('new_chat')), actions: [
        TextButton(
            onPressed: (_busy || _selected.isEmpty) ? null : _start,
            child: Text(s.t('start'))),
      ]),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _friends.isEmpty
              ? Center(
                  child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(s.t('no_friends'), textAlign: TextAlign.center)))
              : Column(children: [
                  Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(s.t('pick_friends'))),
                  Expanded(
                    child: ListView(children: [
                      for (final f in _friends)
                        CheckboxListTile(
                          value: _selected.contains(f['id']),
                          title: Text(displayName(f)),
                          subtitle: Text('@${f['username']}'),
                          onChanged: (v) => setState(() {
                            v == true
                                ? _selected.add(f['id'] as String)
                                : _selected.remove(f['id']);
                          }),
                        ),
                    ]),
                  ),
                ]),
    );
  }
}
