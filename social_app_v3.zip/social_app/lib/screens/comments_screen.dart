import 'package:flutter/material.dart';

import '../main.dart';
import '../social_helpers.dart';
import '../strings.dart';
import '../widgets/reaction_bar.dart';
import '../widgets/rich_body.dart';

class CommentsScreen extends StatefulWidget {
  final String postId;
  const CommentsScreen({super.key, required this.postId});

  @override
  State<CommentsScreen> createState() => _CommentsScreenState();
}

class _CommentsScreenState extends State<CommentsScreen> {
  List<Map<String, dynamic>> _items = [];
  final _ctrl = TextEditingController();
  bool _loading = true;
  bool _sending = false;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final rows = await supabase
          .from('comments')
          .select(
              '*, author:profiles!comments_author_id_fkey(username, display_name)')
          .eq('post_id', widget.postId)
          .order('created_at');
      if (mounted) setState(() => _items = List<Map<String, dynamic>>.from(rows));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(S.of(context).error)));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    setState(() => _sending = true);
    try {
      final row = await supabase
          .from('comments')
          .insert({'post_id': widget.postId, 'body': text})
          .select('id')
          .single();
      final names = extractMentions(text);
      if (names.isNotEmpty) {
        try {
          await supabase.rpc('add_mentions',
              params: {'p_type': 'comment', 'p_source': row['id'], 'p_usernames': names});
        } catch (_) {}
      }
      _ctrl.clear();
      await _load();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(S.of(context).error)));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _delete(String id) async {
    try {
      await supabase.from('comments').delete().eq('id', id);
      await _load();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('comments'))),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  itemCount: _items.length,
                  itemBuilder: (_, i) {
                    final c = _items[i];
                    final a = (c['author'] ?? {}) as Map;
                    final name = (a['display_name'] as String?)?.isNotEmpty ==
                            true
                        ? a['display_name'] as String
                        : (a['username'] ?? '') as String;
                    return ListTile(
                      title: Text(name,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        RichBody((c['body'] as String?) ?? ''),
                        ReactionBar(type: 'comment', id: c['id'] as String, compact: true),
                      ]),
                      trailing: c['author_id'] == _uid
                          ? IconButton(
                              icon: const Icon(Icons.delete_outline),
                              onPressed: () => _delete(c['id'] as String))
                          : null,
                    );
                  },
                ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _ctrl,
                  maxLength: 2000,
                  decoration: InputDecoration(
                      hintText: s.t('write_comment'), counterText: ''),
                ),
              ),
              IconButton(
                  onPressed: _sending ? null : _send,
                  icon: const Icon(Icons.send)),
            ]),
          ),
        ),
      ]),
    );
  }
}
