import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../calls/call_service.dart';
import '../main.dart';
import '../media/media_service.dart';
import '../media/video_audio_widgets.dart';
import '../social_helpers.dart';
import '../strings.dart';
import '../widgets/post_card.dart';
import 'stories/story_viewer_screen.dart';
import 'call_screen.dart';
import 'chats_screen.dart' show displayName;

class ChatScreen extends StatefulWidget {
  final String conversationId;
  final String title;
  const ChatScreen(
      {super.key, required this.conversationId, required this.title});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  // الأحدث أولًا (القائمة معكوسة في الواجهة)
  final List<Map<String, dynamic>> _messages = [];
  final Map<String, String> _names = {};
  final _ctrl = TextEditingController();
  RealtimeChannel? _channel;
  bool _loading = true;
  bool _sending = false;
  final _recorder = AudioRecorder();
  bool _recording = false;
  Map<String, dynamic>? _openCall; // مكالمة جارية في هذه المحادثة

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _init();
    _loadOpenCall();
  }

  @override
  void dispose() {
    _channel?.unsubscribe();
    _ctrl.dispose();
    _recorder.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    try {
      final members = await supabase
          .from('conversation_members')
          .select('user_id, profiles(username, display_name)')
          .eq('conversation_id', widget.conversationId);
      for (final m in members) {
        _names[m['user_id'] as String] = displayName(m['profiles'] as Map?);
      }
      final rows = await supabase
          .from('messages')
          .select()
          .eq('conversation_id', widget.conversationId)
          .order('created_at', ascending: false)
          .limit(100);
      _messages
        ..clear()
        ..addAll(List<Map<String, dynamic>>.from(rows));
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(S.of(context).error)));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }

    _channel = supabase
        .channel('messages:${widget.conversationId}')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'messages',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'conversation_id',
            value: widget.conversationId,
          ),
          callback: (payload) {
            final msg = Map<String, dynamic>.from(payload.newRecord);
            if (_messages.any((m) => m['id'] == msg['id'])) return;
            if (mounted) setState(() => _messages.insert(0, msg));
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.delete,
          schema: 'public',
          table: 'messages',
          callback: (payload) {
            final id = payload.oldRecord['id'];
            if (id != null && mounted) {
              setState(() => _messages.removeWhere((m) => m['id'] == id));
            }
          },
        )
        .subscribe();
  }

  Future<void> _deleteMessage(Map<String, dynamic> m) async {
    final s = S.of(context);
    final idx = _messages.indexWhere((x) => x['id'] == m['id']);
    if (idx < 0) return;
    setState(() => _messages.removeAt(idx));
    try {
      await supabase.from('messages').delete().eq('id', m['id']);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('message_deleted'))));
    } catch (_) {
      if (mounted) {
        setState(() => _messages.insert(idx, m));
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s.t('error'))));
      }
    }
  }

  Future<void> _openShared(Map<String, dynamic> m) async {
    try {
      if (m['shared_post_id'] != null) {
        final row = await supabase
            .from('posts')
            .select(feedPostSelect)
            .eq('id', m['shared_post_id'])
            .maybeSingle();
        if (!mounted) return;
        if (row == null) return _fail('content_unavailable');
        await Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => Scaffold(
                appBar: AppBar(),
                body: SingleChildScrollView(child: PostCard(post: Map<String, dynamic>.from(row))))));
      } else if (m['shared_story_id'] != null) {
        final row = await supabase
            .from('stories')
            .select('author_id')
            .eq('id', m['shared_story_id'])
            .gt('expires_at', DateTime.now().toUtc().toIso8601String())
            .maybeSingle();
        if (!mounted) return;
        if (row == null) return _fail('content_unavailable');
        await Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => StoryViewerScreen(authorIds: [row['author_id'] as String], startIndex: 0)));
      }
    } catch (_) {
      _fail('content_unavailable');
    }
  }

  Future<void> _loadOpenCall() async {
    try {
      final since =
          DateTime.now().toUtc().subtract(const Duration(hours: 4)).toIso8601String();
      final rows = await supabase
          .from('calls')
          .select()
          .eq('conversation_id', widget.conversationId)
          .eq('status', 'open')
          .gt('created_at', since)
          .order('created_at', ascending: false)
          .limit(1);
      if (mounted) {
        setState(() => _openCall =
            rows.isEmpty ? null : Map<String, dynamic>.from(rows.first));
      }
    } catch (_) {}
  }

  Future<void> _enterCall(Map<String, dynamic> call) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => CallScreen(
        callId: call['id'] as String,
        conversationId: widget.conversationId,
        provider: call['provider'] as String,
        video: call['is_video'] as bool,
        title: widget.title,
      ),
    ));
    _loadOpenCall();
  }

  Future<void> _startCall(bool video) async {
    try {
      final call = await CallService.startCall(
        conversationId: widget.conversationId,
        video: video,
        provider: providerNotifier.value,
      );
      if (mounted) await _enterCall(call);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(S.of(context).t('call_failed'))));
      }
    }
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      final row = await supabase
          .from('messages')
          .insert({'conversation_id': widget.conversationId, 'body': text})
          .select()
          .single();
      _ctrl.clear();
      if (mounted && !_messages.any((m) => m['id'] == row['id'])) {
        setState(() => _messages.insert(0, Map<String, dynamic>.from(row)));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(S.of(context).t('not_allowed'))));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _fail(String key) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(S.of(context).t(key))));
  }

  Future<void> _sendMedia(File file, String kind) async {
    if (_sending) return;
    if (await file.length() > 25 * 1024 * 1024) return _fail('file_too_big');
    setState(() => _sending = true);
    try {
      final path =
          '${widget.conversationId}/${DateTime.now().millisecondsSinceEpoch}.${MediaService.extOf(file.path)}';
      await MediaService.upload('chat-media', path, file);
      final row = await supabase
          .from('messages')
          .insert({
            'conversation_id': widget.conversationId,
            'body': '',
            'media_path': path,
            'media_kind': kind,
          })
          .select()
          .single();
      if (mounted && !_messages.any((m) => m['id'] == row['id'])) {
        setState(() => _messages.insert(0, Map<String, dynamic>.from(row)));
      }
    } catch (_) {
      _fail('not_allowed');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _pickPhoto() async {
    final x = await ImagePicker()
        .pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 2048);
    if (x != null) await _sendMedia(File(x.path), 'image');
  }

  Future<void> _toggleRecord() async {
    if (_recording) {
      final path = await _recorder.stop();
      setState(() => _recording = false);
      if (path != null) await _sendMedia(File(path), 'audio');
      return;
    }
    if (!await _recorder.hasPermission()) return _fail('perm_denied');
    final dir = await getTemporaryDirectory();
    await _recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc),
        path: '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a');
    setState(() => _recording = true);
  }

  Widget _messageContent(Map<String, dynamic> m) {
    final path = m['media_path'] as String?;
    final kind = m['media_kind'] as String?;
    final body = (m['body'] as String?) ?? '';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (path != null && kind == 'image')
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(
                width: 220,
                height: 220,
                child: SignedImage(bucket: 'chat-media', path: path)),
          ),
        if (path != null && kind == 'audio') AudioBubble(path: path),
        if (kind == 'document' && path != null)
          Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.insert_drive_file_outlined),
            const SizedBox(width: 6),
            Flexible(child: Text(path.split('/').last, overflow: TextOverflow.ellipsis)),
          ]),
        if (m['shared_post_id'] != null || m['shared_story_id'] != null)
          InkWell(
            onTap: () => _openShared(m),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(m['shared_post_id'] != null ? Icons.article_outlined : Icons.auto_stories),
                const SizedBox(width: 6),
                Text(S.of(context).t(m['shared_post_id'] != null ? 'shared_a_post' : 'shared_a_story')),
              ]),
            ),
          ),
        if (body.isNotEmpty) Text(body),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title), actions: [
        IconButton(
          icon: const Icon(Icons.call),
          tooltip: s.t('voice_call'),
          onPressed: () => _startCall(false),
        ),
        IconButton(
          icon: const Icon(Icons.videocam),
          tooltip: s.t('video_call'),
          onPressed: () => _startCall(true),
        ),
        PopupMenuButton<String>(
          tooltip: s.t('call_provider'),
          icon: const Icon(Icons.settings_input_antenna),
          onSelected: (v) => providerNotifier.value = v,
          itemBuilder: (_) => [
            for (final e in callProviders.entries)
              CheckedPopupMenuItem(
                  value: e.key,
                  checked: providerNotifier.value == e.key,
                  child: Text(e.value)),
          ],
        ),
      ]),
      body: Column(children: [
        if (_openCall != null)
          Material(
            color: scheme.tertiaryContainer,
            child: ListTile(
              dense: true,
              leading: Icon(_openCall!['is_video'] == true
                  ? Icons.videocam
                  : Icons.call),
              title: Text(s.t('call_in_progress')),
              onTap: () => _enterCall(_openCall!),
            ),
          ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.all(12),
                  itemCount: _messages.length,
                  itemBuilder: (_, i) {
                    final m = _messages[i];
                    final mine = m['sender_id'] == _uid;
                    return GestureDetector(
                      onLongPress: mine ? () => _deleteMessage(m) : null,
                      child: Align(
                      alignment: mine
                          ? AlignmentDirectional.centerEnd
                          : AlignmentDirectional.centerStart,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 3),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width * 0.75),
                        decoration: BoxDecoration(
                          color: mine
                              ? scheme.primaryContainer
                              : scheme.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (!mine)
                              Text(_names[m['sender_id']] ?? '',
                                  style: Theme.of(context)
                                      .textTheme
                                      .labelSmall
                                      ?.copyWith(fontWeight: FontWeight.w600)),
                            _messageContent(m),
                          ],
                        ),
                      ),
                    ));
                  },
                ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              IconButton(
                  tooltip: s.t('add_photos'),
                  onPressed: _sending ? null : _pickPhoto,
                  icon: const Icon(Icons.image_outlined)),
              IconButton(
                  tooltip: s.t('voice_note'),
                  onPressed: _sending ? null : _toggleRecord,
                  icon: Icon(_recording ? Icons.stop_circle : Icons.mic_none,
                      color: _recording ? Colors.red : null)),
              Expanded(
                child: TextField(
                  controller: _ctrl,
                  maxLength: 4000,
                  minLines: 1,
                  maxLines: 4,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _send(),
                  decoration: InputDecoration(
                      hintText: s.t('type_message'), counterText: ''),
                ),
              ),
              IconButton(
                  onPressed: _sending ? null : _send,
                  icon: const Icon(Icons.send)),
            ]),
          ),
        ),
      ]),
    );
  }
}
