import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../main.dart';
import '../../media/download_service.dart';
import '../../media/media_service.dart';
import '../../media/pdf_reader_screen.dart';
import '../../media/video_audio_widgets.dart';
import '../../strings.dart';
import '../../widgets/reaction_bar.dart';
import '../../widgets/share_sheet.dart';
import '../chats_screen.dart' show displayName;

Color _hex(String? h) {
  if (h == null || !RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(h)) return const Color(0xFF0E6B63);
  return Color(int.parse('FF${h.substring(1)}', radix: 16));
}

/// عارض الستوريات: يتنقل بين ستوريات الشخص ثم الشخص التالي. لمسة يمين/يسار للتنقل،
/// ضغطة مطوّلة للإيقاف المؤقت.
class StoryViewerScreen extends StatefulWidget {
  final List<String> authorIds;
  final int startIndex;
  const StoryViewerScreen({super.key, required this.authorIds, this.startIndex = 0});

  @override
  State<StoryViewerScreen> createState() => _StoryViewerScreenState();
}

class _StoryViewerScreenState extends State<StoryViewerScreen>
    with SingleTickerProviderStateMixin {
  late int _a = widget.startIndex;
  int _i = 0;
  List<Map<String, dynamic>> _stories = [];
  Map<String, dynamic>? _author;
  bool _loading = true;
  late final AnimationController _anim = AnimationController(vsync: this);
  final _reply = TextEditingController();
  final _replyFocus = FocusNode();
  bool _saved = false;
  int _views = 0;

  String get _uid => supabase.auth.currentUser!.id;
  Map<String, dynamic>? get _cur => _i < _stories.length ? _stories[_i] : null;
  bool get _mine => _cur?['author_id'] == _uid;

  @override
  void initState() {
    super.initState();
    _anim.addStatusListener((st) {
      if (st == AnimationStatus.completed) _next();
    });
    _replyFocus.addListener(() {
      if (_replyFocus.hasFocus) {
        _anim.stop();
      } else if (!_anim.isCompleted) {
        _anim.forward();
      }
    });
    _loadAuthor();
  }

  @override
  void dispose() {
    _anim.dispose();
    _reply.dispose();
    _replyFocus.dispose();
    super.dispose();
  }

  Future<void> _loadAuthor() async {
    setState(() => _loading = true);
    final aid = widget.authorIds[_a];
    try {
      final prof = await supabase
          .from('profiles')
          .select('id, username, display_name, avatar_url')
          .eq('id', aid)
          .single();
      final nowIso = DateTime.now().toUtc().toIso8601String();
      final rows = await supabase
          .from('stories')
          .select()
          .eq('author_id', aid)
          .gt('expires_at', nowIso)
          .order('created_at');
      if (!mounted) return;
      _author = Map<String, dynamic>.from(prof);
      _stories = List<Map<String, dynamic>>.from(rows);
      _i = 0;
      if (_stories.isEmpty) {
        _nextAuthor();
        return;
      }
      setState(() => _loading = false);
      _startStory();
    } catch (_) {
      if (mounted) Navigator.of(context).pop();
    }
  }

  void _nextAuthor() {
    if (_a + 1 < widget.authorIds.length) {
      _a++;
      _loadAuthor();
    } else if (mounted) {
      Navigator.of(context).pop();
    }
  }

  void _prevAuthor() {
    if (_a > 0) {
      _a--;
      _loadAuthor();
    } else {
      _startStory();
    }
  }

  void _next() {
    if (!mounted) return;
    if (_i + 1 < _stories.length) {
      setState(() => _i++);
      _startStory();
    } else {
      _nextAuthor();
    }
  }

  void _prev() {
    if (_i > 0) {
      setState(() => _i--);
      _startStory();
    } else {
      _prevAuthor();
    }
  }

  Future<void> _startStory() async {
    final st = _cur;
    if (st == null) return;
    final kind = st['kind'] as String;
    _anim.stop();
    // فيديو/صوت: ينتهي عند انتهاء التشغيل (والمؤقّت احتياطي فقط)
    _anim.duration = (kind == 'video' || kind == 'audio')
        ? const Duration(minutes: 10)
        : const Duration(seconds: 6);
    _anim.forward(from: 0);
    _saved = false;
    _views = 0;
    if (!_mine) {
      try {
        await supabase.from('story_views').upsert(
            {'story_id': st['id'], 'viewer_id': _uid},
            onConflict: 'story_id,viewer_id', ignoreDuplicates: true);
      } catch (_) {}
      try {
        final r = await supabase
            .from('saved_stories')
            .select('story_id')
            .eq('story_id', st['id'])
            .eq('user_id', _uid)
            .maybeSingle();
        if (mounted) setState(() => _saved = r != null);
      } catch (_) {}
    } else {
      try {
        final r = await supabase.from('story_views').select('viewer_id').eq('story_id', st['id']);
        if (mounted) setState(() => _views = (r as List).length);
      } catch (_) {}
    }
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _sendReply() async {
    final t = _reply.text.trim();
    final st = _cur;
    if (t.isEmpty || st == null) return;
    try {
      await supabase.from('story_replies').insert({'story_id': st['id'], 'body': t});
      _reply.clear();
      _replyFocus.unfocus();
      if (mounted) _snack(S.of(context).t('reply_sent'));
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _toggleSave() async {
    final st = _cur!;
    final was = _saved;
    setState(() => _saved = !was);
    try {
      if (was) {
        await supabase.from('saved_stories').delete().eq('story_id', st['id']).eq('user_id', _uid);
      } else {
        await supabase.from('saved_stories').insert({'story_id': st['id']});
      }
    } catch (_) {
      if (mounted) setState(() => _saved = was);
    }
  }

  Future<void> _download() async {
    final st = _cur!;
    final path = st['media_path'] as String?;
    if (path == null) return;
    await DownloadService.saveToDevice(context, 'story-media', path, st['kind'] as String,
        name: st['title'] as String?);
  }

  Future<void> _delete() async {
    final st = _cur!;
    try {
      await supabase.from('stories').delete().eq('id', st['id']);
      _stories.removeAt(_i);
      if (_stories.isEmpty) {
        _nextAuthor();
      } else {
        if (_i >= _stories.length) _i = _stories.length - 1;
        setState(() {});
        _startStory();
      }
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _toggleHighlight() async {
    final st = _cur!;
    final v = st['highlight'] != true;
    try {
      await supabase.from('stories').update({'highlight': v}).eq('id', st['id']);
      setState(() => st['highlight'] = v);
      if (mounted) _snack(S.of(context).t(v ? 'highlight_on' : 'highlight_off'));
    } catch (_) {}
  }

  Future<void> _report() async {
    final s = S.of(context);
    final ctrl = TextEditingController();
    _anim.stop();
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('report')),
        content: TextField(
            controller: ctrl, maxLength: 500,
            decoration: InputDecoration(labelText: s.t('report_reason'))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text.trim()), child: Text(s.t('send'))),
        ],
      ),
    );
    if (reason != null && reason.length >= 3) {
      try {
        await supabase.from('reports').insert(
            {'target_type': 'story', 'target_id': _cur!['id'], 'reason': reason});
        if (mounted) _snack(s.t('report_sent'));
      } catch (_) {}
    }
    if (mounted) _anim.forward();
  }

  Future<void> _showViewers() async {
    final s = S.of(context);
    _anim.stop();
    final st = _cur!;
    try {
      final views = await supabase
          .from('story_views')
          .select('viewer_id, viewed_at, profiles(username, display_name)')
          .eq('story_id', st['id'])
          .order('viewed_at', ascending: false);
      final replies = await supabase
          .from('story_replies')
          .select('body, created_at, profiles(username, display_name)')
          .eq('story_id', st['id'])
          .order('created_at', ascending: false);
      if (!mounted) return;
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        builder: (ctx) => DraggableScrollableSheet(
          expand: false,
          builder: (_, sc) => ListView(controller: sc, children: [
            ListTile(title: Text('${s.t('viewers')} (${(views as List).length})',
                style: const TextStyle(fontWeight: FontWeight.w700))),
            for (final v in views)
              ListTile(
                  leading: const Icon(Icons.visibility_outlined),
                  title: Text(displayName(v['profiles'] as Map?))),
            if ((replies as List).isNotEmpty)
              ListTile(title: Text(s.t('replies'),
                  style: const TextStyle(fontWeight: FontWeight.w700))),
            for (final r in replies)
              ListTile(
                  leading: const Icon(Icons.reply),
                  title: Text(displayName(r['profiles'] as Map?)),
                  subtitle: Text(r['body'] as String)),
          ]),
        ),
      );
    } catch (_) {}
    if (mounted) _anim.forward();
  }

  Widget _content(Map<String, dynamic> st) {
    final s = S.of(context);
    final kind = st['kind'] as String;
    final path = st['media_path'] as String?;
    switch (kind) {
      case 'text':
        return Container(
          color: _hex(st['bg_color'] as String?),
          alignment: Alignment.center,
          padding: const EdgeInsets.all(32),
          child: Text(st['body'] as String,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w700)),
        );
      case 'image':
        return SignedImage(bucket: 'story-media', path: path!, fit: BoxFit.contain);
      case 'video':
        return Center(
          child: SignedVideo(
            key: ValueKey(st['id']),
            bucket: 'story-media',
            path: path!,
            thumbPath: st['thumb_path'] as String?,
            forceAutoplay: true,
            onEnded: _next,
          ),
        );
      case 'audio':
        return Center(
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: AudioBubble(
                key: ValueKey(st['id']),
                bucket: 'story-media',
                path: path!,
                title: st['title'] as String?,
                autoplay: true,
                onEnded: _next,
              ),
            ),
          ),
        );
      case 'document':
        return Center(
          child: Card(
            child: ListTile(
              leading: const Icon(Icons.menu_book, size: 40),
              title: Text((st['title'] as String?) ?? s.t('book')),
              subtitle: Text(s.t('tap_to_open')),
              onTap: () {
                _anim.stop();
                final isPdf = (st['mime'] as String?) == 'application/pdf';
                if (isPdf) {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => PdfReaderScreen(
                          bucket: 'story-media', path: path!, title: (st['title'] as String?) ?? '')));
                } else {
                  DownloadService.saveToDevice(context, 'story-media', path!, 'document',
                      name: st['title'] as String?);
                }
              },
            ),
          ),
        );
      default: // link
        final url = st['link_url'] as String;
        return Center(
          child: Card(
            margin: const EdgeInsets.all(24),
            child: ListTile(
              leading: const Icon(Icons.link, size: 36),
              title: Text((st['link_title'] as String?)?.isNotEmpty == true ? st['link_title'] as String : url,
                  maxLines: 3, overflow: TextOverflow.ellipsis),
              subtitle: Text(Uri.tryParse(url)?.host ?? ''),
              onTap: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
            ),
          ),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final st = _cur;
    return Scaffold(
      backgroundColor: Colors.black,
      body: _loading || st == null
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: Column(children: [
                // أشرطة التقدّم
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
                  child: Row(children: [
                    for (var k = 0; k < _stories.length; k++)
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 2),
                          child: k == _i
                              ? AnimatedBuilder(
                                  animation: _anim,
                                  builder: (_, __) => LinearProgressIndicator(
                                      value: _anim.value, minHeight: 3,
                                      backgroundColor: Colors.white24, color: Colors.white))
                              : LinearProgressIndicator(
                                  value: k < _i ? 1 : 0, minHeight: 3,
                                  backgroundColor: Colors.white24, color: Colors.white),
                        ),
                      ),
                  ]),
                ),
                ListTile(
                  dense: true,
                  leading: CircleAvatar(
                    radius: 16,
                    backgroundImage: _author?['avatar_url'] != null
                        ? NetworkImage(_author!['avatar_url'] as String) : null,
                    child: _author?['avatar_url'] == null ? const Icon(Icons.person, size: 16) : null,
                  ),
                  title: Text(displayName(_author), style: const TextStyle(color: Colors.white)),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    PopupMenuButton<String>(
                      iconColor: Colors.white,
                      onSelected: (v) {
                        switch (v) {
                          case 'delete':
                            _delete();
                          case 'highlight':
                            _toggleHighlight();
                          case 'report':
                            _report();
                          default:
                            break;
                        }
                      },
                      itemBuilder: (_) => [
                        if (_mine) PopupMenuItem(value: 'highlight', child: Text(s.t('highlight'))),
                        if (_mine) PopupMenuItem(value: 'delete', child: Text(s.t('delete'))),
                        if (!_mine) PopupMenuItem(value: 'report', child: Text(s.t('report'))),
                      ],
                    ),
                    IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () => Navigator.of(context).pop()),
                  ]),
                ),
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTapUp: (d) {
                      final w = MediaQuery.of(context).size.width;
                      // اتجاه العربية: اليمين = التالي
                      final rtl = Directionality.of(context) == TextDirection.rtl;
                      final right = d.localPosition.dx > w / 2;
                      if (right == rtl) {
                        _next();
                      } else {
                        _prev();
                      }
                    },
                    onLongPressStart: (_) => _anim.stop(),
                    onLongPressEnd: (_) {
                      if (!_anim.isCompleted) _anim.forward();
                    },
                    child: _content(st),
                  ),
                ),
                if ((st['body'] as String).isNotEmpty && st['kind'] != 'text')
                  Container(
                    width: double.infinity,
                    color: Colors.black54,
                    padding: const EdgeInsets.all(12),
                    child: Text(st['body'] as String, style: const TextStyle(color: Colors.white)),
                  ),
                Container(
                  color: Colors.black,
                  padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
                  child: _mine
                      ? Row(children: [
                          TextButton.icon(
                            onPressed: _showViewers,
                            icon: const Icon(Icons.visibility_outlined, color: Colors.white),
                            label: Text('$_views', style: const TextStyle(color: Colors.white)),
                          ),
                        ])
                      : Row(children: [
                          Expanded(
                            child: TextField(
                              controller: _reply,
                              focusNode: _replyFocus,
                              style: const TextStyle(color: Colors.white),
                              decoration: InputDecoration(
                                hintText: s.t('reply_story'),
                                hintStyle: const TextStyle(color: Colors.white54),
                                isDense: true,
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(24),
                                    borderSide: const BorderSide(color: Colors.white38)),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(24),
                                    borderSide: const BorderSide(color: Colors.white)),
                              ),
                              onSubmitted: (_) => _sendReply(),
                            ),
                          ),
                          IconButton(
                              icon: const Icon(Icons.send, color: Colors.white),
                              onPressed: _sendReply),
                          Theme(
                            data: Theme.of(context).copyWith(
                                iconTheme: const IconThemeData(color: Colors.white),
                                textTheme: Theme.of(context).textTheme.apply(bodyColor: Colors.white)),
                            child: ReactionBar(type: 'story', id: st['id'] as String, compact: true),
                          ),
                          IconButton(
                              icon: Icon(_saved ? Icons.bookmark : Icons.bookmark_border,
                                  color: Colors.white),
                              onPressed: _toggleSave),
                          if (st['media_path'] != null && st['allow_download'] != false)
                            IconButton(
                                icon: const Icon(Icons.download, color: Colors.white),
                                onPressed: _download),
                          if (st['allow_share'] != false)
                            IconButton(
                                icon: const Icon(Icons.share_outlined, color: Colors.white),
                                onPressed: () => showShareSheet(context,
                                    type: 'story', id: st['id'] as String,
                                    allowShare: true, isMine: false)),
                        ]),
                ),
              ]),
            ),
    );
  }
}
