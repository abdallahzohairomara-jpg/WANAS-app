import 'dart:io';

import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../../main.dart';
import '../../media/attachments.dart';
import '../../media/media_service.dart';
import '../../settings_store.dart';
import '../../social_helpers.dart';
import '../../strings.dart';

const _bgColors = [
  '#0E6B63', '#F2A93B', '#1F1A12', '#7B2D8E', '#B3261E', '#1565C0', '#2E7D32', '#455A64',
];

Color _hex(String h) => Color(int.parse('FF${h.substring(1)}', radix: 16));

/// إنشاء ستوري: نص بخلفية، أو صورة/فيديو/صوت/كتاب/رابط.
class StoryComposerScreen extends StatefulWidget {
  const StoryComposerScreen({super.key});

  @override
  State<StoryComposerScreen> createState() => _StoryComposerScreenState();
}

class _StoryComposerScreenState extends State<StoryComposerScreen> {
  String _kind = 'text';
  final _text = TextEditingController();
  final _caption = TextEditingController();
  final _link = TextEditingController();
  String _bg = _bgColors.first;
  List<PickedMedia> _media = [];
  String _audience = 'friends';
  String? _listId;
  late bool _allowDownload;
  late bool _allowShare;
  List<Map<String, dynamic>> _lists = [];
  bool _busy = false;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    final st = AppSettings.I;
    final a = st.str('default_audience', 'friends');
    _audience = const ['public', 'friends', 'only_me'].contains(a) ? a : 'friends';
    _allowDownload = st.flag('default_allow_download', true);
    _allowShare = st.flag('default_allow_share', true);
    supabase.from('friend_lists').select('id, name').eq('owner_id', _uid).then((r) {
      if (mounted) setState(() => _lists = List<Map<String, dynamic>>.from(r));
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _text.dispose();
    _caption.dispose();
    _link.dispose();
    super.dispose();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _pick(String kind) async {
    final r = switch (kind) {
      'image' => await Pickers.images(limit: 10),
      'video' => await Pickers.video(),
      'audio' => await Pickers.audio(),
      _ => await Pickers.book(),
    };
    if (r.rejected > 0) _snack(S.of(context).t('some_files_rejected'));
    setState(() {
      _kind = kind;
      _media = r.items;
    });
  }

  Map<String, dynamic> _common() => {
        'audience': _listId != null ? 'list' : _audience,
        if (_listId != null) 'list_id': _listId,
        'allow_download': _allowDownload,
        'allow_share': _allowShare,
      };

  Future<void> _mentions(String sid, String text) async {
    final m = extractMentions(text);
    if (m.isEmpty) return;
    try {
      await supabase.rpc('add_mentions',
          params: {'p_type': 'story', 'p_source': sid, 'p_usernames': m});
    } catch (_) {}
  }

  Future<void> _publish() async {
    final s = S.of(context);
    setState(() => _busy = true);
    try {
      if (_kind == 'text') {
        final t = _text.text.trim();
        if (t.isEmpty) {
          setState(() => _busy = false);
          return;
        }
        final r = await supabase
            .from('stories')
            .insert({'kind': 'text', 'body': t, 'bg_color': _bg, ..._common()})
            .select('id')
            .single();
        await _mentions(r['id'] as String, t);
      } else if (_kind == 'link') {
        final u = _link.text.trim();
        if (!RegExp(r'^https?://\S+$').hasMatch(u)) {
          _snack(s.t('bad_link'));
          setState(() => _busy = false);
          return;
        }
        String? title;
        try {
          final res = await supabase.functions.invoke('link-preview', body: {'url': u});
          if (res.data is Map) title = (res.data as Map)['title'] as String?;
        } catch (_) {}
        await supabase.from('stories').insert({
          'kind': 'link',
          'link_url': u,
          'link_title': title,
          'body': _caption.text.trim(),
          ..._common(),
        });
      } else {
        if (_media.isEmpty) {
          setState(() => _busy = false);
          return;
        }
        for (final m in _media) {
          final sid = const Uuid().v4();
          final ts = DateTime.now().millisecondsSinceEpoch;
          final file = await AttachmentUploader.prepare(m);
          final ext = MediaService.extOf(file.path);
          final path = '$_uid/$sid/$ts.$ext';
          await supabase.from('stories').insert({
            'id': sid,
            'kind': m.kind,
            'body': _caption.text.trim(),
            'media_path': path,
            'mime': MediaService.mimeOf(file.path),
            'title': m.title,
            'size_bytes': await file.length(),
            ..._common(),
          });
          try {
            await MediaService.upload('story-media', path, file);
            final t = await AttachmentUploader.thumbFor(m);
            if (t != null) {
              final tp = '$_uid/$sid/${ts}_t.jpg';
              await MediaService.upload('story-media', tp, File(t.path));
              await supabase.from('stories').update({'thumb_path': tp}).eq('id', sid);
            }
          } catch (_) {
            await supabase.from('stories').delete().eq('id', sid);
            rethrow;
          }
          await _mentions(sid, _caption.text);
        }
      }
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        _snack(s.t('error'));
        setState(() => _busy = false);
      }
    }
  }

  Widget _typeButton(IconData icon, String label, String kind, {VoidCallback? onTap}) =>
      ChoiceChip(
        avatar: Icon(icon, size: 18),
        label: Text(label),
        selected: _kind == kind,
        onSelected: _busy
            ? null
            : (_) => onTap != null ? onTap() : setState(() => _kind = kind),
      );

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final isText = _kind == 'text';
    return Scaffold(
      appBar: AppBar(title: Text(s.t('new_story')), actions: [
        TextButton(onPressed: _busy ? null : _publish, child: Text(s.t('publish'))),
      ]),
      body: Column(children: [
        if (_busy) const LinearProgressIndicator(),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Wrap(spacing: 8, runSpacing: 4, children: [
              _typeButton(Icons.text_fields, s.t('story_text'), 'text'),
              _typeButton(Icons.photo_outlined, s.t('story_photo'), 'image', onTap: () => _pick('image')),
              _typeButton(Icons.videocam_outlined, s.t('story_video'), 'video', onTap: () => _pick('video')),
              _typeButton(Icons.audiotrack_outlined, s.t('story_audio'), 'audio', onTap: () => _pick('audio')),
              _typeButton(Icons.menu_book_outlined, s.t('story_book'), 'document', onTap: () => _pick('document')),
              _typeButton(Icons.link, s.t('story_link'), 'link'),
            ]),
            const SizedBox(height: 16),
            if (isText) ...[
              Container(
                height: 260,
                alignment: Alignment.center,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: _hex(_bg), borderRadius: BorderRadius.circular(16)),
                child: TextField(
                  controller: _text,
                  maxLength: 400,
                  maxLines: null,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w700),
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      counterStyle: const TextStyle(color: Colors.white70),
                      hintText: s.t('whats_on_mind'),
                      hintStyle: const TextStyle(color: Colors.white54)),
                ),
              ),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                for (final c in _bgColors)
                  GestureDetector(
                    onTap: () => setState(() => _bg = c),
                    child: CircleAvatar(
                      radius: 16,
                      backgroundColor: _hex(c),
                      child: _bg == c ? const Icon(Icons.check, size: 18, color: Colors.white) : null,
                    ),
                  ),
              ]),
            ] else if (_kind == 'link') ...[
              TextField(
                controller: _link,
                keyboardType: TextInputType.url,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(labelText: 'https://'),
              ),
            ] else ...[
              if (_media.isEmpty)
                Text(s.t('pick_file_first'))
              else
                for (final m in _media)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: m.kind == 'image'
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: Image.file(m.file, width: 48, height: 48, fit: BoxFit.cover))
                        : Icon(switch (m.kind) {
                            'video' => Icons.movie,
                            'audio' => Icons.audiotrack,
                            _ => Icons.menu_book,
                          }),
                    title: Text(m.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('${(m.size / (1024 * 1024)).toStringAsFixed(1)} MB'),
                  ),
            ],
            if (!isText) ...[
              const SizedBox(height: 8),
              TextField(
                controller: _caption,
                maxLength: 1000,
                decoration: InputDecoration(labelText: s.t('caption')),
              ),
            ],
            const Divider(height: 32),
            DropdownButtonFormField<String>(
              value: _listId ?? _audience,
              decoration: InputDecoration(labelText: s.t('story_audience')),
              items: [
                DropdownMenuItem(value: 'public', child: Text(s.t('aud_public'))),
                DropdownMenuItem(value: 'friends', child: Text(s.t('aud_friends'))),
                DropdownMenuItem(value: 'only_me', child: Text(s.t('aud_only_me'))),
                for (final l in _lists)
                  DropdownMenuItem(value: 'list:${l['id']}', child: Text('${s.t('list')}: ${l['name']}')),
              ],
              onChanged: (v) => setState(() {
                if (v != null && v.startsWith('list:')) {
                  _listId = v.substring(5);
                } else {
                  _listId = null;
                  _audience = v ?? 'friends';
                }
              }),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(s.t('allow_download')),
              value: _allowDownload,
              onChanged: (v) => setState(() => _allowDownload = v),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(s.t('allow_share')),
              value: _allowShare,
              onChanged: (v) => setState(() => _allowShare = v),
            ),
            Text(s.t('story_24h'), style: Theme.of(context).textTheme.bodySmall),
          ]),
        ),
      ]),
    );
  }
}
