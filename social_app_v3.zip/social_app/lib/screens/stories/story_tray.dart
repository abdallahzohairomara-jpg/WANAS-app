import 'package:flutter/material.dart';

import '../../main.dart';
import '../../strings.dart';
import 'story_composer_screen.dart';
import 'story_viewer_screen.dart';

/// شريط الستوريات أعلى الخلاصة: ستوريك أولًا ثم أصدقاؤك (غير المشاهَد أولًا).
class StoryTray extends StatefulWidget {
  const StoryTray({super.key});

  @override
  State<StoryTray> createState() => _StoryTrayState();
}

class _StoryTrayState extends State<StoryTray> {
  List<Map<String, dynamic>> _items = [];
  Map<String, Map<String, dynamic>> _profiles = {};
  bool _myActive = false;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = List<Map<String, dynamic>>.from(await supabase.rpc('story_tray') as List);
      final ids = rows.map((r) => r['author_id'] as String).toSet().toList();
      final profs = <String, Map<String, dynamic>>{};
      if (ids.isNotEmpty) {
        final p = await supabase
            .from('profiles')
            .select('id, username, display_name, avatar_url')
            .inFilter('id', ids);
        for (final r in p) {
          profs[r['id'] as String] = Map<String, dynamic>.from(r);
        }
      }
      rows.sort((a, b) {
        final sa = a['all_seen'] == true ? 1 : 0;
        final sb = b['all_seen'] == true ? 1 : 0;
        if (sa != sb) return sa.compareTo(sb);
        return (b['latest'] as String).compareTo(a['latest'] as String);
      });
      if (!mounted) return;
      setState(() {
        _myActive = rows.any((r) => r['author_id'] == _uid);
        _items = rows.where((r) => r['author_id'] != _uid).toList();
        _profiles = profs;
      });
    } catch (_) {}
  }

  Future<void> _open(List<String> authors, int index) async {
    await Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => StoryViewerScreen(authorIds: authors, startIndex: index)));
    _load();
  }

  Future<void> _create() async {
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const StoryComposerScreen()));
    _load();
  }

  Widget _bubble(
      {required String label,
      String? avatar,
      required bool ring,
      required bool seen,
      required VoidCallback onTap,
      Widget? badge}) {
    final primary = Theme.of(context).colorScheme.primary;
    return InkWell(
      onTap: onTap,
      child: SizedBox(
        width: 76,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Stack(clipBehavior: Clip.none, children: [
            Container(
              padding: const EdgeInsets.all(2.5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: ring
                    ? Border.all(color: seen ? Colors.grey : primary, width: 2.5)
                    : null,
              ),
              child: CircleAvatar(
                radius: 26,
                backgroundImage: avatar != null ? NetworkImage(avatar) : null,
                child: avatar == null ? const Icon(Icons.person) : null,
              ),
            ),
            if (badge != null) PositionedDirectional(end: 0, bottom: 0, child: badge),
          ]),
          const SizedBox(height: 4),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelSmall),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final authors = _items.map((r) => r['author_id'] as String).toList();
    return SizedBox(
      height: 100,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        children: [
          _bubble(
            label: s.t('your_story'),
            ring: _myActive,
            seen: true,
            onTap: _myActive ? () => _open([_uid], 0) : _create,
            badge: GestureDetector(
              onTap: _create,
              child: CircleAvatar(
                radius: 11,
                backgroundColor: Theme.of(context).colorScheme.secondary,
                child: Icon(Icons.add, size: 16, color: Theme.of(context).colorScheme.onSecondary),
              ),
            ),
          ),
          for (var i = 0; i < _items.length; i++)
            _bubble(
              label: (() {
                final p = _profiles[_items[i]['author_id']];
                final dn = p?['display_name'] as String?;
                return (dn != null && dn.isNotEmpty) ? dn : (p?['username'] ?? '') as String;
              })(),
              avatar: _profiles[_items[i]['author_id']]?['avatar_url'] as String?,
              ring: true,
              seen: _items[i]['all_seen'] == true,
              onTap: () => _open(authors, i),
            ),
        ],
      ),
    );
  }
}
