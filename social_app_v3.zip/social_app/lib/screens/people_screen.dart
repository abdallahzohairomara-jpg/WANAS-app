import 'package:flutter/material.dart';

import '../main.dart';
import '../strings.dart';

/// البحث عن مستخدمين، إرسال/قبول طلبات الصداقة، والحظر.
class PeopleScreen extends StatefulWidget {
  const PeopleScreen({super.key});

  @override
  State<PeopleScreen> createState() => _PeopleScreenState();
}

class _PeopleScreenState extends State<PeopleScreen> {
  final _q = TextEditingController();
  List<Map<String, dynamic>> _results = [];
  List<Map<String, dynamic>> _incoming = [];
  // معرّف المستخدم -> حالة العلاقة: sent / friends
  Map<String, String> _rel = {};

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _loadRelations();
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _loadRelations() async {
    try {
      final rows = await supabase.from('friendships').select(
          '*, requester:profiles!friendships_requester_id_fkey(id, username, display_name)');
      final rel = <String, String>{};
      final incoming = <Map<String, dynamic>>[];
      for (final r in rows) {
        final other =
            r['requester_id'] == _uid ? r['addressee_id'] : r['requester_id'];
        if (r['status'] == 'accepted') {
          rel[other] = 'friends';
        } else if (r['requester_id'] == _uid) {
          rel[other] = 'sent';
        } else {
          incoming.add(Map<String, dynamic>.from(r));
        }
      }
      if (mounted) {
        setState(() {
          _rel = rel;
          _incoming = incoming;
        });
      }
    } catch (_) {}
  }

  Future<void> _search() async {
    final q = _q.text.trim().replaceAll('%', '').replaceAll('_', r'\_');
    if (q.length < 2) return;
    try {
      final rows = await supabase
          .from('profiles')
          .select('id, username, display_name')
          .ilike('username', '$q%')
          .neq('id', _uid)
          .limit(20);
      if (mounted) setState(() => _results = List<Map<String, dynamic>>.from(rows));
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _request(String id) async {
    try {
      await supabase
          .from('friendships')
          .insert({'requester_id': _uid, 'addressee_id': id});
      await _loadRelations();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _accept(String requesterId) async {
    try {
      await supabase
          .from('friendships')
          .update({'status': 'accepted'})
          .eq('requester_id', requesterId)
          .eq('addressee_id', _uid);
      await _loadRelations();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _block(String id) async {
    try {
      await supabase.from('blocks').insert({'blocker_id': _uid, 'blocked_id': id});
      // الحظر يلغي الصداقة القائمة
      await supabase.from('friendships').delete().or(
          'and(requester_id.eq.$_uid,addressee_id.eq.$id),and(requester_id.eq.$id,addressee_id.eq.$_uid)');
      if (mounted) {
        _snack(S.of(context).t('blocked'));
        setState(() => _results.removeWhere((r) => r['id'] == id));
      }
      await _loadRelations();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  String _name(Map m) => (m['display_name'] as String?)?.isNotEmpty == true
      ? '${m['display_name']} (@${m['username']})'
      : '@${m['username']}';

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('people'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _q,
            textDirection: TextDirection.ltr,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _search(),
            decoration: InputDecoration(
              hintText: s.t('search_user'),
              suffixIcon: IconButton(
                  icon: const Icon(Icons.search), onPressed: _search),
            ),
          ),
          if (_incoming.isNotEmpty) ...[
            const SizedBox(height: 24),
            Text(s.t('requests'), style: Theme.of(context).textTheme.titleMedium),
            for (final r in _incoming)
              ListTile(
                title: Text(_name(r['requester'] as Map)),
                trailing: FilledButton(
                    onPressed: () => _accept(r['requester_id'] as String),
                    child: Text(s.t('accept'))),
              ),
          ],
          const SizedBox(height: 16),
          for (final u in _results)
            ListTile(
              title: Text(_name(u)),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                if (_rel[u['id']] == 'friends')
                  Text(s.t('friends_now'))
                else if (_rel[u['id']] == 'sent')
                  Text(s.t('requested'))
                else
                  OutlinedButton(
                      onPressed: () => _request(u['id'] as String),
                      child: Text(s.t('add_friend'))),
                PopupMenuButton<String>(
                  onSelected: (_) => _block(u['id'] as String),
                  itemBuilder: (_) =>
                      [PopupMenuItem(value: 'b', child: Text(s.t('block')))],
                ),
              ]),
            ),
        ],
      ),
    );
  }
}
