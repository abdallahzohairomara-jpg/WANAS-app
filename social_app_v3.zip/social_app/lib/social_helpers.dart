import 'main.dart';

/// المنطقة الزمنية للجهاز بصيغة يفهمها Postgres (بدون مكتبات إضافية).
/// UTC+3 تُكتب 'Etc/GMT-3' (الإشارة معكوسة في هذه الصيغة). الأنصاف تعود إلى UTC.
String deviceTz() {
  final o = DateTime.now().timeZoneOffset;
  if (o.inMinutes % 60 != 0 || o.inHours == 0) return 'UTC';
  final h = o.inHours;
  return 'Etc/GMT${h > 0 ? '-' : '+'}${h.abs()}';
}

/// أصدقائي المقبولون (id, username, display_name)
Future<List<Map<String, dynamic>>> loadFriends() async {
  final uid = supabase.auth.currentUser!.id;
  final rows = await supabase
      .from('friendships')
      .select('requester_id, addressee_id')
      .eq('status', 'accepted');
  final ids = <String>[
    for (final r in rows)
      (r['requester_id'] == uid ? r['addressee_id'] : r['requester_id']) as String
  ];
  if (ids.isEmpty) return [];
  final profs = await supabase
      .from('profiles')
      .select('id, username, display_name')
      .inFilter('id', ids);
  return List<Map<String, dynamic>>.from(profs);
}

/// تطبيع الموضوع: أحرف صغيرة بلا # ولا مسافات زائدة، بين 2 و30 حرفًا.
String? normalizeTopic(String raw) {
  final t = raw.trim().replaceAll('#', '').trim().toLowerCase();
  if (t.length < 2 || t.length > 30) return null;
  return t;
}

List<String> parseTopics(String raw) {
  final out = <String>[];
  for (final part in raw.split(RegExp(r'[,،\n]'))) {
    final t = normalizeTopic(part);
    if (t != null && !out.contains(t)) out.add(t);
    if (out.length == 5) break;
  }
  return out;
}

/// المحادثات التي أنا عضو فيها بأسماء جاهزة (للمشاركة في محادثة).
Future<List<Map<String, String>>> loadChatTargets() async {
  final uid = supabase.auth.currentUser!.id;
  final mine = await supabase
      .from('conversation_members')
      .select('conversation_id, conversations(title, is_group)')
      .eq('user_id', uid);
  final ids = [for (final r in mine) r['conversation_id'] as String];
  if (ids.isEmpty) return [];
  final others = await supabase
      .from('conversation_members')
      .select('conversation_id, profiles(username, display_name)')
      .inFilter('conversation_id', ids)
      .neq('user_id', uid);
  final dmName = <String, String>{};
  for (final o in others) {
    final p = o['profiles'] as Map?;
    final n = ((p?['display_name'] as String?)?.isNotEmpty == true
            ? p!['display_name']
            : p?['username'] ?? '') as String;
    dmName[o['conversation_id'] as String] = n;
  }
  return [
    for (final r in mine)
      {
        'id': r['conversation_id'] as String,
        'title': ((r['conversations'] as Map?)?['is_group'] == true
                ? ((r['conversations'] as Map?)?['title'] as String? ?? '')
                : dmName[r['conversation_id']] ?? '')
            .toString(),
      }
  ];
}

/// أسماء المستخدمين المذكورين (@name) في نص.
List<String> extractMentions(String text) {
  final out = <String>{};
  for (final m in RegExp(r'@([A-Za-z0-9_]{3,30})').allMatches(text)) {
    out.add(m.group(1)!);
    if (out.length == 10) break;
  }
  return out.toList();
}

/// روابط http(s) داخل نص.
List<String> extractLinks(String text) => [
      for (final m in RegExp(r'https?://[^\s]+').allMatches(text)) m.group(0)!
    ];

/// حقول المنشور الكاملة للعرض في أي قائمة (الخلاصة، الجروبات، المحفوظات).
const feedPostSelect =
    '*, author:profiles!posts_author_id_fkey(username, display_name, avatar_url), comments(count), group:groups(id, name), post_media(id, storage_path, thumb_path, kind, title, mime), post_links(id, url, title, description), post_participants(user_id, status)';
