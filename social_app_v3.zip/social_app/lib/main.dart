import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'theme.dart';
import 'screens/auth_gate.dart';

final supabase = Supabase.instance.client;

/// للتنقل من خارج الواجهة (مثل فتح محادثة عند الضغط على إشعار).
final navigatorKey = GlobalKey<NavigatorState>();

/// لغة التطبيق الحالية، تتغير من شاشة الملف الشخصي.
final localeNotifier = ValueNotifier<Locale>(const Locale('ar'));

/// وضع المظهر وحجم الخط (يضبطهما AppSettings من إعدادات المستخدم).
final themeModeNotifier = ValueNotifier<ThemeMode>(ThemeMode.system);
final fontScaleNotifier = ValueNotifier<double>(1.0);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const SocialApp());
}

class SocialApp extends StatelessWidget {
  const SocialApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeModeNotifier,
      builder: (_, mode, __) => ValueListenableBuilder<double>(
      valueListenable: fontScaleNotifier,
      builder: (_, scale, __) => ValueListenableBuilder<Locale>(
      valueListenable: localeNotifier,
      builder: (_, locale, __) => MaterialApp(
        builder: (ctx, child) => MediaQuery(
          data: MediaQuery.of(ctx).copyWith(textScaler: TextScaler.linear(scale)),
          child: child ?? const SizedBox.shrink(),
        ),
        navigatorKey: navigatorKey,
        debugShowCheckedModeBanner: false,
        locale: locale,
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        themeMode: mode,
        home: const AuthGate(),
      ),
      ),
      ),
    );
  }
}
