import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

import 'main.dart';

/// إعدادات المستخدم المحفوظة في قاعدة البيانات (جدول user_settings) لتتبعه بين أجهزته.
class AppSettings extends ChangeNotifier {
  AppSettings._();
  static final AppSettings I = AppSettings._();

  Map<String, dynamic> _v = {};
  bool loaded = false;

  String get _uid => supabase.auth.currentUser!.id;

  String str(String key, String def) => (_v[key] as String?) ?? def;
  bool flag(String key, bool def) => (_v[key] as bool?) ?? def;
  double dbl(String key, double def) => (_v[key] as num?)?.toDouble() ?? def;
  int? intOrNull(String key) => (_v[key] as num?)?.toInt();

  Future<void> load() async {
    try {
      final row = await supabase
          .from('user_settings')
          .select()
          .eq('user_id', _uid)
          .maybeSingle();
      _v = row == null ? {} : Map<String, dynamic>.from(row);
      loaded = true;
    } catch (_) {}
    _apply();
    notifyListeners();
  }

  void reset() {
    _v = {};
    loaded = false;
    _apply();
  }

  void _apply() {
    themeModeNotifier.value = switch (str('theme_mode', 'system')) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    fontScaleNotifier.value = dbl('font_scale', 1.0);
  }

  /// يحفظ قيمة واحدة (null تعني إزالتها). يرجع false عند الفشل ويتراجع محليًا.
  Future<bool> set(String key, dynamic value) async {
    final old = _v[key];
    if (value == null) {
      _v.remove(key);
    } else {
      _v[key] = value;
    }
    _apply();
    notifyListeners();
    try {
      await supabase.from('user_settings').upsert({
        'user_id': _uid,
        key: value,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      });
      return true;
    } catch (_) {
      if (old == null) {
        _v.remove(key);
      } else {
        _v[key] = old;
      }
      _apply();
      notifyListeners();
      return false;
    }
  }

  /// هل يُشغَّل الفيديو تلقائيًا الآن؟ (حسب الإعداد وتوفير البيانات ونوع الشبكة)
  Future<bool> canAutoplay() async {
    if (flag('data_saver', false)) return false;
    final mode = str('autoplay', 'wifi');
    if (mode == 'never') return false;
    if (mode == 'always') return true;
    try {
      final c = await Connectivity().checkConnectivity();
      return c.contains(ConnectivityResult.wifi) ||
          c.contains(ConnectivityResult.ethernet);
    } catch (_) {
      return false;
    }
  }
}
