import 'package:flutter/material.dart';

/// مصدر وحيد للهوية. لتغيير الاسم عدّل السطرين الأولين فقط
/// (ثم اسم التطبيق في AndroidManifest.xml).
class Brand {
  static const nameAr = 'ونس';
  static const nameEn = 'Wanas';

  static const taglineAr = 'مساحتك الاجتماعية تحت سيطرتك';
  static const taglineEn = 'Your social space, under your control';

  // الألوان (التفاصيل والتباين في brand/BRAND.md)
  static const primary = Color(0xFF0E6B63);
  static const primaryOnDark = Color(0xFF5FD0C4);
  static const accent = Color(0xFFF2A93B);
  static const ink = Color(0xFF1F1A12);
  static const paper = Color(0xFFFAF7F2);
  static const night = Color(0xFF0F1514);
}
