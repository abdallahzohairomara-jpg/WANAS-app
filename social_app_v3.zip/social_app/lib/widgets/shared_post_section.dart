import 'package:flutter/material.dart';

import '../main.dart';
import '../screens/chats_screen.dart' show displayName;
import '../strings.dart';

/// قسم "منشور مشترك": المشاركون الموافقون ومساهماتهم.
/// قاعدة البيانات هي التي تخفي المدعوين غير الموافقين وتمنع غير المشاركين من الكتابة.
class SharedPostSection extends StatefulWidget {
  final String postId;
  final String ownerId;
  const SharedPostSection({super.key, required this.postId, required this.ownerId});

  @override
  State<SharedPostSection> createState() => _SharedPostSectionState();
}

class _SharedPostSectionState extends State<SharedPostSection> {
  List<Map<String, dynamic>> _people = [];
  List<Map<String, dynamic>> _contribs = [];
  final _ctrl = TextEditingController();
  bool _loaded = false;

  String get _uid => supabase.auth.currentUser!.id;
  bool get _isOwner => widget.ownerId == _uid;
  bool get _iAmAccepted =>
      _people.any((p) => p['user_id'] == _uid && p['status'] == 'accepted');

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final p = await supabase
          .from('post_participants')
          .select(
              'user_id, status, profile:profiles!post_participants_user_id_fkey(username, display_name)')
          .eq('post_id', widget.postId);
      final c = await supabase
          .from('post_contributions')
          .select(
              'id, author_id, body, profile:profiles!post_contributions_author_id_fkey(username, display_name)')
          .eq('post_id', widget.postId)
          .order('created_at');
      if (!mounted) return;
      setState(() {
        _people = List<Map<String, dynamic>>.from(p);
        _contribs = List<Map<String, dynamic>>.from(c);
        _loaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _loaded = true);
    }
  }

  Future<void> _add() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    try {
      await supabase
          .from('post_contributions')
          .insert({'post_id': widget.postId, 'body': text});
      _ctrl.clear();
      await _load();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(S.of(context).error)));
      }
    }
  }

  Future<void> _deleteContribution(String id) async {
    try {
      await supabase.from('post_contributions').delete().eq('id', id);
      await _load();
    } catch (_) {}
  }

  Future<void> _withdraw() async {
    try {
      await supabase
          .from('post_participants')
          .delete()
          .eq('post_id', widget.postId)
          .eq('user_id', _uid);
      await _load();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const SizedBox.shrink();
    final s = S.of(context);
    final shown = _people.where((p) => p['status'] == 'accepted' || _isOwner).toList();
    if (shown.isEmpty && _contribs.isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsetsDirectional.only(top: 8, end: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.group_outlined, size: 18),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              '${s.t('shared_with')}: ${shown.map((p) => '${displayName(p['profile'] as Map?)}${p['status'] == 'accepted' ? '' : ' (${s.t('pstatus_${p['status']}')})'}').join('، ')}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
          if (_iAmAccepted && !_isOwner)
            TextButton(onPressed: _withdraw, child: Text(s.t('withdraw'))),
        ]),
        for (final c in _contribs)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: Text.rich(TextSpan(children: [
                  TextSpan(
                      text: '${displayName(c['profile'] as Map?)}: ',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  TextSpan(text: c['body'] as String),
                ])),
              ),
              if (c['author_id'] == _uid || _isOwner)
                InkWell(
                    onTap: () => _deleteContribution(c['id'] as String),
                    child: const Icon(Icons.close, size: 16)),
            ]),
          ),
        if (_iAmAccepted)
          Row(children: [
            Expanded(
              child: TextField(
                controller: _ctrl,
                maxLength: 1000,
                decoration: InputDecoration(
                    hintText: s.t('add_contribution'), counterText: ''),
                onSubmitted: (_) => _add(),
              ),
            ),
            IconButton(onPressed: _add, icon: const Icon(Icons.send, size: 18)),
          ]),
      ]),
    );
  }
}
