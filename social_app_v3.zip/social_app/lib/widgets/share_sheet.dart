import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../main.dart';
import '../social_helpers.dart';
import '../strings.dart';

/// قائمة المشاركة. type: post | story
/// - نشر على صفحتي (للمنشورات فقط): منشور جديد يحمل إشارة للأصل، والأصل يُعرض لمن يحق له رؤيته.
/// - إرسال في محادثة.
/// - مشاركة نص خارج التطبيق (للمنشورات العامة فقط).
Future<void> showShareSheet(
  BuildContext context, {
  required String type,
  required String id,
  required bool allowShare,
  required bool isMine,
  String? publicText,
}) async {
  final s = S.of(context);
  if (!allowShare && !isMine) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(s.t('share_disabled'))));
    return;
  }
  final choice = await showModalBottomSheet<String>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (type == 'post')
          ListTile(
              leading: const Icon(Icons.repeat),
              title: Text(s.t('share_to_profile')),
              onTap: () => Navigator.pop(ctx, 'repost')),
        ListTile(
            leading: const Icon(Icons.send_outlined),
            title: Text(s.t('share_in_chat')),
            onTap: () => Navigator.pop(ctx, 'chat')),
        if (publicText != null)
          ListTile(
              leading: const Icon(Icons.ios_share),
              title: Text(s.t('share_external')),
              onTap: () => Navigator.pop(ctx, 'external')),
      ]),
    ),
  );
  if (choice == null || !context.mounted) return;
  final messenger = ScaffoldMessenger.of(context);
  try {
    if (choice == 'repost') {
      final ctrl = TextEditingController();
      final text = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(s.t('share_to_profile')),
          content: TextField(
              controller: ctrl,
              maxLength: 2000,
              maxLines: 3,
              decoration: InputDecoration(hintText: s.t('add_comment_optional'))),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('cancel'))),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
                child: Text(s.t('publish'))),
          ],
        ),
      );
      if (text == null) return;
      await supabase.from('posts').insert({
        'body': text,
        'audience': 'friends',
        'shared_post_id': id,
      });
      messenger.showSnackBar(SnackBar(content: Text(s.t('shared_ok'))));
    } else if (choice == 'chat') {
      final targets = await loadChatTargets();
      if (!context.mounted) return;
      if (targets.isEmpty) {
        messenger.showSnackBar(SnackBar(content: Text(s.t('no_chats'))));
        return;
      }
      final conv = await showModalBottomSheet<String>(
        context: context,
        builder: (ctx) => SafeArea(
          child: ListView(shrinkWrap: true, children: [
            for (final t in targets)
              ListTile(
                  leading: const Icon(Icons.chat_bubble_outline),
                  title: Text(t['title']!.isEmpty ? s.t('group') : t['title']!),
                  onTap: () => Navigator.pop(ctx, t['id'])),
          ]),
        ),
      );
      if (conv == null) return;
      await supabase.from('messages').insert({
        'conversation_id': conv,
        'body': '',
        if (type == 'post') 'shared_post_id': id else 'shared_story_id': id,
      });
      messenger.showSnackBar(SnackBar(content: Text(s.t('shared_ok'))));
    } else if (choice == 'external' && publicText != null) {
      final t = publicText.length > 300 ? '${publicText.substring(0, 299)}…' : publicText;
      await Share.share('$t\n\n— ${s.t('app_name')}');
    }
  } catch (_) {
    messenger.showSnackBar(SnackBar(content: Text(s.t('share_failed'))));
  }
}
