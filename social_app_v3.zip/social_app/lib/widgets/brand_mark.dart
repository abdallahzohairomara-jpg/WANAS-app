import 'package:flutter/material.dart';

import '../brand.dart';

/// رمز الهوية: دائرتان متداخلتان، والتقاطع الكهرماني هو "مساحتك".
/// نفس هندسة brand/logo.svg (مساحة رسم 1024).
class BrandMark extends StatelessWidget {
  final double size;

  /// true: مربع أخضر بحواف دائرية (للأيقونة). false: الرمز فقط ويتلوّن حسب الثيم.
  final bool withBackground;

  const BrandMark({super.key, this.size = 96, this.withBackground = false});

  @override
  Widget build(BuildContext context) {
    final ring = withBackground
        ? Colors.white
        : Theme.of(context).colorScheme.primary;
    return CustomPaint(
      size: Size.square(size),
      painter: _MarkPainter(withBackground: withBackground, ringColor: ring),
    );
  }
}

class _MarkPainter extends CustomPainter {
  final bool withBackground;
  final Color ringColor;
  _MarkPainter({required this.withBackground, required this.ringColor});

  @override
  void paint(Canvas canvas, Size size) {
    final u = size.width / 1024;
    if (withBackground) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
            Offset.zero & size, Radius.circular(224 * u)),
        Paint()..color = Brand.primary,
      );
    }
    final c1 = Offset(430 * u, 512 * u);
    final c2 = Offset(594 * u, 512 * u);
    final r = 200 * u;

    final lens = Path.combine(
      PathOperation.intersect,
      Path()..addOval(Rect.fromCircle(center: c1, radius: r)),
      Path()..addOval(Rect.fromCircle(center: c2, radius: r)),
    );
    canvas.drawPath(lens, Paint()..color = Brand.accent);

    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 44 * u
      ..color = ringColor;
    canvas.drawCircle(c1, r, ring);
    canvas.drawCircle(c2, r, ring);
  }

  @override
  bool shouldRepaint(_MarkPainter old) =>
      old.withBackground != withBackground || old.ringColor != ringColor;
}
