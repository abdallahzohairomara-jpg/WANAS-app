import 'package:flutter/material.dart';

import '../main.dart';
import '../strings.dart';

const reactionKinds = ['like', 'love', 'haha', 'wow', 'sad', 'angry'];
const reactionEmoji = {
  'like': '👍',
  'love': '❤️',
  'haha': '😂',
  'wow': '😮',
  'sad': '😢',
  'angry': '😡',
};

/// شريط التفاعلات: ضغطة = إعجاب/إلغاء، ضغطة مطوّلة = اختيار تفاعل (وخيار "تفاعل خاص").
/// type: post | comment | story
class ReactionBar extends StatefulWidget {
  final String type;
  final String id;
  final bool compact;
  const ReactionBar({super.key, required this.type, required this.id, this.compact = false});

  @override
  State<ReactionBar> createState() => _ReactionBarState();
}

class _ReactionBarState extends State<ReactionBar> {
  Map<String, int> _counts = {};
  String? _mine;

  String get _uid => supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = await supabase.rpc('reaction_counts',
          params: {'p_type': widget.type, 'p_ids': [widget.id]}) as List;
      final counts = <String, int>{};
      String? mine;
      for (final r in rows) {
        counts[r['kind'] as String] = (r['n'] as num).toInt();
        if (r['mine'] == true) mine = r['kind'] as String;
      }
      if (mounted) {
        setState(() {
          _counts = counts;
          _mine = mine;
        });
      }
    } catch (_) {}
  }

  Future<void> _set(String? kind, {bool private = false}) async {
    final old = _mine;
    setState(() {
      if (old != null) _counts[old] = ((_counts[old] ?? 1) - 1).clamp(0, 1 << 30);
      if (kind != null) _counts[kind] = (_counts[kind] ?? 0) + 1;
      _mine = kind;
    });
    try {
      if (kind == null) {
        await supabase
            .from('reactions')
            .delete()
            .eq('target_type', widget.type)
            .eq('target_id', widget.id)
            .eq('user_id', _uid);
      } else {
        await supabase.from('reactions').upsert({
          'target_type': widget.type,
          'target_id': widget.id,
          'user_id': _uid,
          'kind': kind,
          'is_private': private,
        }, onConflict: 'target_type,target_id,user_id');
      }
    } catch (_) {
      await _load();
    }
  }

  Future<void> _pick() async {
    final s = S.of(context);
    var private = false;
    final kind = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Wrap(spacing: 8, children: [
                for (final k in reactionKinds)
                  InkWell(
                    borderRadius: BorderRadius.circular(24),
                    onTap: () => Navigator.pop(ctx, private ? 'p:$k' : k),
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Text(reactionEmoji[k]!, style: const TextStyle(fontSize: 34)),
                    ),
                  ),
              ]),
              SwitchListTile(
                dense: true,
                title: Text(s.t('private_reaction')),
                subtitle: Text(s.t('private_reaction_hint')),
                value: private,
                onChanged: (v) => setSt(() => private = v),
              ),
            ]),
          ),
        ),
      ),
    );
    if (kind == null) return;
    if (kind.startsWith('p:')) {
      await _set(kind.substring(2), private: true);
    } else {
      await _set(kind);
    }
  }

  @override
  Widget build(BuildContext context) {
    final total = _counts.values.fold<int>(0, (a, b) => a + b);
    final top = (_counts.entries.where((e) => e.value > 0).toList()
          ..sort((a, b) => b.value.compareTo(a.value)))
        .take(3)
        .map((e) => reactionEmoji[e.key]!)
        .join();
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => _set(_mine == null ? 'like' : null),
      onLongPress: _pick,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (_mine != null)
            Text(reactionEmoji[_mine]!, style: const TextStyle(fontSize: 22))
          else
            const Icon(Icons.thumb_up_outlined),
          if (total > 0) ...[
            const SizedBox(width: 6),
            if (!widget.compact && top.isNotEmpty) Text(top),
            const SizedBox(width: 4),
            Text('$total'),
          ],
        ]),
      ),
    );
  }
}
