import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../main.dart';
import '../media/download_service.dart';
import '../media/media_service.dart';
import '../media/pdf_reader_screen.dart';
import '../media/video_audio_widgets.dart';
import '../screens/comments_screen.dart';
import '../screens/participants_screen.dart';
import '../strings.dart';
import 'reaction_bar.dart';
import 'rich_body.dart';
import 'share_sheet.dart';
import 'shared_post_section.dart';

int _count(dynamic agg) {
  if (agg is List && agg.isNotEmpty) return (agg.first['count'] as num).toInt();
  return 0;
}

String _authorName(Map? a) {
  final dn = a?['display_name'] as String?;
  return (dn != null && dn.isNotEmpty) ? dn : (a?['username'] ?? '') as String;
}

class PostCard extends StatefulWidget {
  final Map<String, dynamic> post;
  final bool initiallySaved;
  final VoidCallback onDeleted;
  /// إخفاء الأزرار الثانوية (عند عرض المنشور مضمّنًا داخل مشاركة)
  final bool embedded;

  const PostCard({
    super.key,
    required this.post,
    required this.initiallySaved,
    required this.onDeleted,
    this.embedded = false,
  });

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  late bool _saved = widget.initiallySaved;
  late int _comments = _count(widget.post['comments']);
  Map<String, dynamic>? _original;
  bool _originalLoaded = false;

  String get _uid => supabase.auth.currentUser!.id;
  String get _postId => widget.post['id'] as String;
  bool get _mine => widget.post['author_id'] == _uid;
  bool get _allowDownload => _mine || widget.post['allow_download'] != false;
  bool get _allowShare => _mine || widget.post['allow_share'] != false;
  List get _media => (widget.post['post_media'] as List?) ?? const [];

  @override
  void initState() {
    super.initState();
    if (widget.post['shared_post_id'] != null && !widget.embedded) _loadOriginal();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _loadOriginal() async {
    try {
      final r = await supabase
          .from('posts')
          .select(
              '*, author:profiles!posts_author_id_fkey(username, display_name, avatar_url), post_media(id, storage_path, thumb_path, kind, title, mime), post_links(id, url, title, description)')
          .eq('id', widget.post['shared_post_id'])
          .maybeSingle();
      if (mounted) {
        setState(() {
          _original = r == null ? null : Map<String, dynamic>.from(r);
          _originalLoaded = true;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _originalLoaded = true);
    }
  }

  Future<void> _toggleSave() async {
    final was = _saved;
    setState(() => _saved = !was);
    try {
      if (was) {
        await supabase.from('saved_posts').delete().eq('post_id', _postId).eq('user_id', _uid);
      } else {
        await supabase.from('saved_posts').insert({'post_id': _postId});
      }
    } catch (_) {
      if (!mounted) return;
      setState(() => _saved = was);
      _snack(S.of(context).error);
    }
  }

  Future<void> _delete() async {
    try {
      await supabase.from('posts').delete().eq('id', _postId);
      widget.onDeleted();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _archive() async {
    try {
      await supabase
          .from('posts')
          .update({'archived_at': DateTime.now().toUtc().toIso8601String()}).eq('id', _postId);
      if (mounted) _snack(S.of(context).t('archived_ok'));
      widget.onDeleted();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _muteAuthor() async {
    try {
      await supabase.from('user_mutes').upsert({
        'user_id': _uid,
        'muted_id': widget.post['author_id'],
        'until': DateTime.now().toUtc().add(const Duration(days: 30)).toIso8601String(),
        'scope': 'all',
      });
      if (mounted) _snack(S.of(context).t('muted_ok'));
      widget.onDeleted();
    } catch (_) {
      if (mounted) _snack(S.of(context).error);
    }
  }

  Future<void> _downloadAll() async {
    for (final m in _media) {
      await DownloadService.saveToDevice(
          context, 'post-media', m['storage_path'] as String, m['kind'] as String,
          name: m['title'] as String?);
    }
  }

  Future<void> _report() async {
    final s = S.of(context);
    final ctrl = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('report')),
        content: TextField(
          controller: ctrl,
          maxLength: 500,
          decoration: InputDecoration(labelText: s.t('report_reason'), helperText: s.t('report_hint')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text.trim()), child: Text(s.t('send'))),
        ],
      ),
    );
    if (reason == null || reason.length < 3) return;
    try {
      await supabase.from('reports').insert({'target_type': 'post', 'target_id': _postId, 'reason': reason});
      if (mounted) _snack(s.t('report_sent'));
    } catch (_) {
      if (mounted) _snack(s.t('error'));
    }
  }

  Future<void> _why() async {
    final s = S.of(context);
    final reason = (widget.post['feed_reason'] as String?) ?? 'recent';
    final topics = ((widget.post['topics'] as List?) ?? const []).join('، ');
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('why_title')),
        content: Text('${s.t('why_$reason')}${topics.isNotEmpty ? '\n${s.t('topics')}: $topics' : ''}'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('ok')))],
      ),
    );
  }

  Future<void> _addToAlbum() async {
    final s = S.of(context);
    try {
      final albums = List<Map<String, dynamic>>.from(
          await supabase.from('albums').select().order('created_at'));
      if (!mounted) return;
      if (albums.isEmpty) {
        _snack(s.t('no_albums'));
        return;
      }
      final id = await showModalBottomSheet<String>(
        context: context,
        builder: (ctx) => SafeArea(
          child: ListView(shrinkWrap: true, children: [
            for (final a in albums)
              ListTile(
                leading: const Icon(Icons.photo_album_outlined),
                title: Text(a['title'] as String),
                onTap: () => Navigator.pop(ctx, a['id'] as String),
              ),
          ]),
        ),
      );
      if (id == null) return;
      await supabase.from('album_items').upsert({'album_id': id, 'post_id': _postId});
      if (mounted) _snack(s.t('added_to_album'));
    } catch (_) {
      if (mounted) _snack(s.t('error'));
    }
  }

  Future<void> _openComments() async {
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => CommentsScreen(postId: _postId)));
    try {
      final r = await supabase.from('comments').select('id').eq('post_id', _postId);
      if (mounted) setState(() => _comments = (r as List).length);
    } catch (_) {}
  }

  String _audienceLabel(S s) {
    if (widget.post['group_id'] != null) {
      return (widget.post['group'] as Map?)?['name'] as String? ?? s.t('group');
    }
    switch (widget.post['audience']) {
      case 'public':
        return s.t('aud_public');
      case 'only_me':
        return s.t('aud_only_me');
      default:
        return s.t('aud_friends');
    }
  }

  Widget _mediaBlock(List media, List links) {
    if (media.isEmpty && links.isEmpty) return const SizedBox.shrink();
    final images = media.where((m) => m['kind'] == 'image').toList();
    final videos = media.where((m) => m['kind'] == 'video').toList();
    final audios = media.where((m) => m['kind'] == 'audio').toList();
    final docs = media.where((m) => m['kind'] == 'document').toList();
    return Padding(
      padding: const EdgeInsetsDirectional.only(top: 8, end: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (images.isNotEmpty)
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: images.length == 1 ? 1 : 2,
            childAspectRatio: images.length == 1 ? 4 / 3 : 1,
            mainAxisSpacing: 4,
            crossAxisSpacing: 4,
            children: [
              for (final m in images)
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: GestureDetector(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => FullImageScreen(
                            bucket: 'post-media',
                            path: m['storage_path'] as String,
                            thumbPath: m['thumb_path'] as String?))),
                    child: SignedImage(
                        bucket: 'post-media',
                        path: (m['thumb_path'] ?? m['storage_path']) as String),
                  ),
                ),
            ],
          ),
        for (final m in videos)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: SignedVideo(
                  bucket: 'post-media',
                  path: m['storage_path'] as String,
                  thumbPath: m['thumb_path'] as String?),
            ),
          ),
        for (final m in audios)
          Card(
            margin: const EdgeInsets.only(top: 6),
            child: Padding(
              padding: const EdgeInsets.all(4),
              child: AudioBubble(
                  bucket: 'post-media',
                  path: m['storage_path'] as String,
                  title: m['title'] as String?),
            ),
          ),
        for (final m in docs)
          Card(
            margin: const EdgeInsets.only(top: 6),
            child: ListTile(
              leading: const Icon(Icons.menu_book, size: 32),
              title: Text((m['title'] as String?) ?? S.of(context).t('book'),
                  maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: Text(m['mime'] == 'application/epub+zip' ? 'EPUB' : 'PDF'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                final isPdf = m['mime'] == 'application/pdf';
                if (isPdf) {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => PdfReaderScreen(
                          bucket: 'post-media',
                          path: m['storage_path'] as String,
                          title: (m['title'] as String?) ?? '')));
                } else {
                  DownloadService.saveToDevice(context, 'post-media',
                      m['storage_path'] as String, 'document',
                      name: m['title'] as String?);
                }
              },
            ),
          ),
        for (final l in links)
          Card(
            margin: const EdgeInsets.only(top: 6),
            child: ListTile(
              leading: const Icon(Icons.link),
              title: Text(((l['title'] as String?)?.isNotEmpty == true ? l['title'] : l['url']) as String,
                  maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: Text(
                  ((l['description'] as String?)?.isNotEmpty == true
                      ? l['description']
                      : Uri.tryParse(l['url'] as String)?.host ?? '') as String,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis),
              onTap: () => launchUrl(Uri.parse(l['url'] as String),
                  mode: LaunchMode.externalApplication),
            ),
          ),
      ]),
    );
  }

  Widget _originalBlock(S s) {
    if (widget.post['shared_post_id'] == null || widget.embedded) {
      return const SizedBox.shrink();
    }
    return Container(
      margin: const EdgeInsetsDirectional.only(top: 8, end: 8),
      decoration: BoxDecoration(
        border: Border.all(color: Theme.of(context).dividerColor),
        borderRadius: BorderRadius.circular(12),
      ),
      child: !_originalLoaded
          ? const Padding(padding: EdgeInsets.all(16), child: LinearProgressIndicator())
          : _original == null
              ? Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(s.t('original_unavailable')))
              : PostCard(
                  key: ValueKey('orig_${_original!['id']}'),
                  post: _original!,
                  initiallySaved: false,
                  onDeleted: () {},
                  embedded: true,
                ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final author = (widget.post['author'] ?? {}) as Map;
    final name = _authorName(author);
    final avatar = author['avatar_url'] as String?;
    final created = DateTime.tryParse(widget.post['created_at'] ?? '')?.toLocal();
    final links = (widget.post['post_links'] as List?) ?? const [];
    final body = (widget.post['body'] as String?) ?? '';
    final pending = widget.post['group_status'] == 'pending';
    final scheduled = DateTime.tryParse(widget.post['publish_at'] ?? '');

    return Padding(
      padding: EdgeInsets.fromLTRB(widget.embedded ? 12 : 16, 12, 8, 4),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(
            radius: widget.embedded ? 14 : 20,
            backgroundImage: avatar != null ? NetworkImage(avatar) : null,
            child: avatar == null ? const Icon(Icons.person, size: 18) : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
              Text(
                '${created != null ? '${created.year}/${created.month}/${created.day}  ${created.hour.toString().padLeft(2, '0')}:${created.minute.toString().padLeft(2, '0')}' : ''} · ${_audienceLabel(s)}${pending ? ' · ${s.t('pending_approval')}' : ''}${scheduled != null && scheduled.isAfter(DateTime.now()) ? ' · ${s.t('scheduled')}' : ''}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ]),
          ),
          if (!widget.embedded)
            PopupMenuButton<String>(
              onSelected: (v) {
                switch (v) {
                  case 'delete':
                    _delete();
                  case 'why':
                    _why();
                  case 'album':
                    _addToAlbum();
                  case 'download':
                    _downloadAll();
                  case 'archive':
                    _archive();
                  case 'mute':
                    _muteAuthor();
                  case 'invite':
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => ParticipantsScreen(postId: _postId)));
                  default:
                    _report();
                }
              },
              itemBuilder: (_) => [
                if (widget.post['feed_reason'] != null)
                  PopupMenuItem(value: 'why', child: Text(s.t('why_title'))),
                if (_media.isNotEmpty && _allowDownload)
                  PopupMenuItem(value: 'download', child: Text(s.t('download'))),
                PopupMenuItem(value: 'album', child: Text(s.t('add_to_album'))),
                if (_mine) PopupMenuItem(value: 'invite', child: Text(s.t('participants'))),
                if (_mine) PopupMenuItem(value: 'archive', child: Text(s.t('archive'))),
                if (!_mine) PopupMenuItem(value: 'mute', child: Text(s.t('mute_30d'))),
                if (_mine)
                  PopupMenuItem(value: 'delete', child: Text(s.t('delete')))
                else
                  PopupMenuItem(value: 'report', child: Text(s.t('report'))),
              ],
            ),
        ]),
        if (body.isNotEmpty)
          Padding(
            padding: const EdgeInsetsDirectional.only(top: 8, end: 8),
            child: RichBody(body),
          ),
        _originalBlock(s),
        _mediaBlock(_media, links),
        if (!widget.embedded &&
            ((widget.post['post_participants'] as List?) ?? const []).isNotEmpty)
          SharedPostSection(postId: _postId, ownerId: widget.post['author_id'] as String),
        if (!widget.embedded)
          Row(children: [
            ReactionBar(type: 'post', id: _postId),
            IconButton(onPressed: _openComments, icon: const Icon(Icons.mode_comment_outlined)),
            Text('$_comments'),
            if (_allowShare)
              IconButton(
                tooltip: s.t('share'),
                icon: const Icon(Icons.share_outlined),
                onPressed: () => showShareSheet(context,
                    type: 'post',
                    id: _postId,
                    allowShare: _allowShare,
                    isMine: _mine,
                    publicText: widget.post['audience'] == 'public' &&
                            widget.post['group_id'] == null &&
                            body.isNotEmpty
                        ? body
                        : null),
              ),
            const Spacer(),
            IconButton(
              onPressed: _toggleSave,
              icon: Icon(_saved ? Icons.bookmark : Icons.bookmark_border),
            ),
          ]),
      ]),
    );
  }
}
