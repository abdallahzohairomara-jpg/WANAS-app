import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

/// نص منشور مع تمييز @المنشن وروابط http(s) قابلة للفتح.
class RichBody extends StatefulWidget {
  final String text;
  final TextStyle? style;
  const RichBody(this.text, {super.key, this.style});

  @override
  State<RichBody> createState() => _RichBodyState();
}

class _RichBodyState extends State<RichBody> {
  final List<TapGestureRecognizer> _recognizers = [];

  @override
  void dispose() {
    for (final r in _recognizers) {
      r.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    for (final r in _recognizers) {
      r.dispose();
    }
    _recognizers.clear();
    final color = Theme.of(context).colorScheme.primary;
    final spans = <InlineSpan>[];
    final re = RegExp(r'(https?://[^\s]+)|(@[A-Za-z0-9_]{3,30})');
    var last = 0;
    for (final m in re.allMatches(widget.text)) {
      if (m.start > last) spans.add(TextSpan(text: widget.text.substring(last, m.start)));
      final tok = m.group(0)!;
      if (tok.startsWith('@')) {
        spans.add(TextSpan(
            text: tok, style: TextStyle(color: color, fontWeight: FontWeight.w700)));
      } else {
        final rec = TapGestureRecognizer()
          ..onTap = () => launchUrl(Uri.parse(tok), mode: LaunchMode.externalApplication);
        _recognizers.add(rec);
        spans.add(TextSpan(
            text: tok,
            style: TextStyle(color: color, decoration: TextDecoration.underline),
            recognizer: rec));
      }
      last = m.end;
    }
    if (last < widget.text.length) spans.add(TextSpan(text: widget.text.substring(last)));
    return Text.rich(TextSpan(style: widget.style, children: spans));
  }
}
