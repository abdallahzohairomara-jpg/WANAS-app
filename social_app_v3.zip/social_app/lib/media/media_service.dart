import 'dart:io';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../main.dart';

/// رفع الوسائط وإنشاء روابط مؤقتة لعرضها.
/// المسارات (تفرضها سياسات التخزين في phase6/phase8):
///   post-media: {author}/{post}/{file}   story-media: {author}/{story}/{file}
///   chat-media: {conversation}/{file}
class MediaService {
  static const mimeByExt = {
    'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png',
    'webp': 'image/webp', 'gif': 'image/gif', 'heic': 'image/heic',
    'avif': 'image/avif',
    'mp4': 'video/mp4', 'mov': 'video/quicktime', 'webm': 'video/webm',
    'mp3': 'audio/mpeg', 'm4a': 'audio/mp4', 'aac': 'audio/aac',
    'wav': 'audio/wav', 'ogg': 'audio/ogg', 'oga': 'audio/ogg',
    'opus': 'audio/opus', 'flac': 'audio/flac', 'weba': 'audio/webm',
    'pdf': 'application/pdf', 'epub': 'application/epub+zip',
  };

  static String extOf(String path) {
    final i = path.lastIndexOf('.');
    return i < 0 ? '' : path.substring(i + 1).toLowerCase();
  }

  static String? mimeOf(String path) => mimeByExt[extOf(path)];

  /// image | video | audio | document (الافتراضي image للمجهول)
  static String kindOf(String path) {
    final m = mimeOf(path) ?? '';
    if (m.startsWith('video/')) return 'video';
    if (m.startsWith('audio/')) return 'audio';
    if (m.startsWith('application/')) return 'document';
    return 'image';
  }

  static String fileName(String path) => path.split(Platform.pathSeparator).last;

  static Future<String> upload(String bucket, String objectPath, File file) async {
    await supabase.storage.from(bucket).upload(
          objectPath,
          file,
          fileOptions: FileOptions(
              contentType: mimeOf(file.path) ?? 'application/octet-stream',
              upsert: false),
        );
    return objectPath;
  }

  static final _cache = <String, ({String url, DateTime at})>{};

  /// رابط موقّع لمدة ساعة، مع تخزين مؤقت قصير.
  static Future<String> signedUrl(String bucket, String path) async {
    final key = '$bucket/$path';
    final hit = _cache[key];
    if (hit != null && DateTime.now().difference(hit.at).inMinutes < 45) {
      return hit.url;
    }
    final url = await supabase.storage.from(bucket).createSignedUrl(path, 3600);
    _cache[key] = (url: url, at: DateTime.now());
    return url;
  }
}

/// عرض صورة من التخزين الخاص. إن وُجدت نسخة مصغرة تظهر فورًا (سريعة وخفيفة)،
/// وعند فتح الصورة بملء الشاشة تُحمَّل النسخة الأصلية بدقتها الكاملة.
class SignedImage extends StatelessWidget {
  final String bucket;
  final String path;
  final BoxFit fit;
  const SignedImage(
      {super.key, required this.bucket, required this.path, this.fit = BoxFit.cover});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: MediaService.signedUrl(bucket, path),
      builder: (_, snap) {
        if (snap.hasError) return const Center(child: Icon(Icons.broken_image));
        if (!snap.hasData) {
          return const ColoredBox(color: Colors.black12);
        }
        return Image.network(snap.data!,
            fit: fit,
            gaplessPlayback: true,
            frameBuilder: (ctx, child, frame, sync) => AnimatedOpacity(
                opacity: frame == null && !sync ? 0 : 1,
                duration: const Duration(milliseconds: 180),
                child: child),
            errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image)));
      },
    );
  }
}

/// صورة بملء الشاشة بدقتها الكاملة مع تكبير بالأصابع.
class FullImageScreen extends StatelessWidget {
  final String bucket;
  final String path;
  final String? thumbPath;
  const FullImageScreen(
      {super.key, required this.bucket, required this.path, this.thumbPath});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          backgroundColor: Colors.black, foregroundColor: Colors.white),
      body: Center(
        child: InteractiveViewer(
          maxScale: 8,
          child: Stack(alignment: Alignment.center, children: [
            if (thumbPath != null)
              SignedImage(bucket: bucket, path: thumbPath!, fit: BoxFit.contain),
            SignedImage(bucket: bucket, path: path, fit: BoxFit.contain),
          ]),
        ),
      ),
    );
  }
}
