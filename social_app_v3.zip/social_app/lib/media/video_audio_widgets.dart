import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../settings_store.dart';
import 'media_service.dart';

/// مشغّل فيديو: يعرض الصورة المصغرة أولًا، ويحمّل الفيديو عند الضغط
/// (أو تلقائيًا إذا سمح إعداد التشغيل التلقائي وتوفير البيانات).
class SignedVideo extends StatefulWidget {
  final String bucket;
  final String path;
  final String? thumbPath;
  final VoidCallback? onEnded;
  final bool forceAutoplay;
  const SignedVideo(
      {super.key,
      required this.bucket,
      required this.path,
      this.thumbPath,
      this.onEnded,
      this.forceAutoplay = false});

  @override
  State<SignedVideo> createState() => _SignedVideoState();
}

class _SignedVideoState extends State<SignedVideo> {
  VideoPlayerController? _c;
  bool _loading = false, _failed = false, _endedFired = false;

  @override
  void initState() {
    super.initState();
    if (widget.forceAutoplay) {
      _load();
    } else {
      AppSettings.I.canAutoplay().then((ok) {
        if (ok && mounted) _load();
      });
    }
  }

  @override
  void dispose() {
    _c?.removeListener(_tick);
    _c?.dispose();
    super.dispose();
  }

  void _tick() {
    final c = _c;
    if (c == null || _endedFired) return;
    final v = c.value;
    if (v.isInitialized && !v.isPlaying && v.position >= v.duration && v.duration > Duration.zero) {
      _endedFired = true;
      widget.onEnded?.call();
    }
  }

  Future<void> _load() async {
    if (_loading || _c != null) return;
    setState(() => _loading = true);
    try {
      final url = await MediaService.signedUrl(widget.bucket, widget.path);
      final c = VideoPlayerController.networkUrl(Uri.parse(url));
      await c.initialize();
      if (!mounted) {
        c.dispose();
        return;
      }
      c.addListener(_tick);
      setState(() => _c = c);
      c.play();
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    if (c == null) {
      return AspectRatio(
        aspectRatio: 16 / 9,
        child: Stack(fit: StackFit.expand, children: [
          if (widget.thumbPath != null)
            SignedImage(bucket: widget.bucket, path: widget.thumbPath!)
          else
            const ColoredBox(color: Colors.black26),
          Center(
            child: _loading
                ? const CircularProgressIndicator(strokeWidth: 2)
                : IconButton(
                    iconSize: 56,
                    color: Colors.white,
                    icon: Icon(_failed ? Icons.error_outline : Icons.play_circle),
                    onPressed: _load),
          ),
        ]),
      );
    }
    return AspectRatio(
      aspectRatio: c.value.aspectRatio,
      child: Stack(alignment: Alignment.center, children: [
        VideoPlayer(c),
        ValueListenableBuilder<VideoPlayerValue>(
          valueListenable: c,
          builder: (_, v, __) => IconButton(
            iconSize: 48,
            color: Colors.white,
            icon: Icon(v.isPlaying ? Icons.pause_circle : Icons.play_circle),
            onPressed: () => v.isPlaying ? c.pause() : c.play(),
          ),
        ),
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: VideoProgressIndicator(c, allowScrubbing: true),
        ),
      ]),
    );
  }
}

/// مقطع صوتي (رسالة صوتية أو ملف صوتي كامل) مع شريط تقدّم.
class AudioBubble extends StatefulWidget {
  final String path;
  final String bucket;
  final String? title;
  final VoidCallback? onEnded;
  final bool autoplay;
  const AudioBubble(
      {super.key,
      required this.path,
      this.bucket = 'chat-media',
      this.title,
      this.onEnded,
      this.autoplay = false});

  @override
  State<AudioBubble> createState() => _AudioBubbleState();
}

class _AudioBubbleState extends State<AudioBubble> {
  final _player = AudioPlayer();
  bool _playing = false;
  Duration _pos = Duration.zero, _dur = Duration.zero;

  @override
  void initState() {
    super.initState();
    _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = false);
      widget.onEnded?.call();
    });
    _player.onPositionChanged.listen((p) {
      if (mounted) setState(() => _pos = p);
    });
    _player.onDurationChanged.listen((d) {
      if (mounted) setState(() => _dur = d);
    });
    if (widget.autoplay) _toggle();
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_playing) {
      await _player.pause();
      if (mounted) setState(() => _playing = false);
      return;
    }
    try {
      if (_pos > Duration.zero && _pos < _dur) {
        await _player.resume();
      } else {
        final url = await MediaService.signedUrl(widget.bucket, widget.path);
        await _player.play(UrlSource(url));
      }
      if (mounted) setState(() => _playing = true);
    } catch (_) {}
  }

  String _fmt(Duration d) =>
      '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final max = _dur.inMilliseconds == 0 ? 1.0 : _dur.inMilliseconds.toDouble();
    return SizedBox(
      width: 240,
      child: Row(children: [
        IconButton(
            onPressed: _toggle,
            icon: Icon(_playing ? Icons.pause_circle : Icons.play_circle, size: 34)),
        Expanded(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (widget.title != null)
              Text(widget.title!, maxLines: 1, overflow: TextOverflow.ellipsis),
            Slider(
              value: _pos.inMilliseconds.toDouble().clamp(0.0, max),
              max: max,
              onChanged: (v) => _player.seek(Duration(milliseconds: v.toInt())),
            ),
            Text('${_fmt(_pos)} / ${_fmt(_dur)}',
                style: Theme.of(context).textTheme.labelSmall),
          ]),
        ),
      ]),
    );
  }
}
