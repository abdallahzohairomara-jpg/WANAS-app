import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';
import 'package:share_plus/share_plus.dart';

import '../strings.dart';
import 'download_service.dart';

/// قارئ كتب PDF داخل التطبيق. EPUB يُفتح عبر قارئ كتب على الهاتف (مشاركة).
class PdfReaderScreen extends StatefulWidget {
  final String bucket;
  final String path;
  final String title;
  const PdfReaderScreen(
      {super.key, required this.bucket, required this.path, required this.title});

  @override
  State<PdfReaderScreen> createState() => _PdfReaderScreenState();
}

class _PdfReaderScreenState extends State<PdfReaderScreen> {
  PdfControllerPinch? _c;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _open();
  }

  Future<void> _open() async {
    try {
      final f = await DownloadService.fetch(widget.bucket, widget.path,
          name: widget.path.split('/').last);
      if (!mounted) return;
      setState(() => _c = PdfControllerPinch(document: PdfDocument.openFile(f.path)));
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(widget.title), actions: [
        IconButton(
          icon: const Icon(Icons.ios_share),
          onPressed: () async {
            try {
              final f = await DownloadService.fetch(widget.bucket, widget.path,
                  name: widget.path.split('/').last);
              await Share.shareXFiles([XFile(f.path)]);
            } catch (_) {}
          },
        ),
      ]),
      body: _failed
          ? Center(child: Text(s.t('error')))
          : _c == null
              ? const Center(child: CircularProgressIndicator())
              : PdfViewPinch(controller: _c!),
    );
  }
}
