import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

import '../config.dart';
import '../main.dart';
import '../settings_store.dart';
import 'media_service.dart';

/// ملف مرفق قبل الرفع.
class PickedMedia {
  final File file;
  final String kind; // image | video | audio | document
  final String title;
  final int size;
  PickedMedia(this.file, this.kind, this.title, this.size);
}

class PickResult {
  final List<PickedMedia> items;
  final int rejected; // كبير جدًا أو نوع غير مدعوم
  PickResult(this.items, this.rejected);
}

class Pickers {
  static Future<PickResult> _build(Iterable<String> paths, {String? only}) async {
    final out = <PickedMedia>[];
    var rejected = 0;
    for (final p in paths) {
      final f = File(p);
      final mime = MediaService.mimeOf(p);
      final kind = MediaService.kindOf(p);
      final size = await f.length();
      if (mime == null || size > maxUploadBytes || (only != null && kind != only)) {
        rejected++;
        continue;
      }
      out.add(PickedMedia(f, kind, MediaService.fileName(p), size));
    }
    return PickResult(out, rejected);
  }

  static Future<PickResult> images({int limit = 10}) async {
    final x = await ImagePicker().pickMultiImage(limit: limit);
    return _build(x.map((e) => e.path), only: 'image');
  }

  static Future<PickResult> video() async {
    final x = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (x == null) return PickResult([], 0);
    return _build([x.path], only: 'video');
  }

  /// أي ملف صوتي من الهاتف (mp3, m4a, wav, ogg, flac, opus, aac...)
  static Future<PickResult> audio() async {
    final r = await FilePicker.platform
        .pickFiles(type: FileType.audio, allowMultiple: true);
    if (r == null) return PickResult([], 0);
    return _build(r.files.map((f) => f.path).whereType<String>(), only: 'audio');
  }

  /// كتاب: PDF أو EPUB
  static Future<PickResult> book() async {
    final r = await FilePicker.platform.pickFiles(
        type: FileType.custom, allowedExtensions: ['pdf', 'epub']);
    if (r == null) return PickResult([], 0);
    return _build(r.files.map((f) => f.path).whereType<String>(), only: 'document');
  }
}

class Uploaded {
  final String path;
  final String? thumbPath;
  final String mime;
  final int size;
  Uploaded(this.path, this.thumbPath, this.mime, this.size);
}

class AttachmentUploader {
  static Future<File> _tmp(String name) async =>
      File('${(await getTemporaryDirectory()).path}/$name');

  /// صورة مصغرة سريعة للعرض في الخلاصة (الأصل يبقى كاملًا للفتح والتنزيل).
  static Future<File?> thumbFor(PickedMedia m) async {
    try {
      if (m.kind == 'image') {
        final out = await _tmp('th_${DateTime.now().microsecondsSinceEpoch}.jpg');
        final x = await FlutterImageCompress.compressAndGetFile(
            m.file.path, out.path,
            quality: 72, minWidth: 720, minHeight: 720);
        return x == null ? null : File(x.path);
      }
      if (m.kind == 'video') {
        final dir = (await getTemporaryDirectory()).path;
        final p = await VideoThumbnail.thumbnailFile(
            video: m.file.path,
            thumbnailPath: dir,
            imageFormat: ImageFormat.JPEG,
            maxWidth: 960,
            quality: 78);
        return p == null ? null : File(p);
      }
    } catch (_) {}
    return null;
  }

  /// ضغط الصورة قبل الرفع حسب إعداد "جودة الرفع" (الأصلية افتراضيًا).
  static Future<File> prepare(PickedMedia m) async {
    if (m.kind != 'image') return m.file;
    final q = AppSettings.I.str('upload_quality', 'original');
    if (q == 'original') return m.file;
    try {
      final out = await _tmp('up_${DateTime.now().microsecondsSinceEpoch}.jpg');
      final side = q == 'saver' ? 1280 : 2560;
      final x = await FlutterImageCompress.compressAndGetFile(
          m.file.path, out.path,
          quality: q == 'saver' ? 70 : 88, minWidth: side, minHeight: side);
      return x == null ? m.file : File(x.path);
    } catch (_) {
      return m.file;
    }
  }

  /// يرفع ملفًا وصورته المصغرة إلى [bucket] تحت المجلد [folder] (مثل "{uid}/{postId}").
  static Future<Uploaded> upload(String bucket, String folder, PickedMedia m, int n) async {
    final file = await prepare(m);
    final ext = MediaService.extOf(file.path);
    final base = '${DateTime.now().millisecondsSinceEpoch}_$n';
    final path = '$folder/$base.$ext';
    await MediaService.upload(bucket, path, file);
    String? thumb;
    final t = await thumbFor(m);
    if (t != null) {
      final tp = '$folder/${base}_t.jpg';
      try {
        await MediaService.upload(bucket, tp, t);
        thumb = tp;
      } catch (_) {}
    }
    return Uploaded(path, thumb, MediaService.mimeOf(file.path) ?? 'application/octet-stream',
        await file.length());
  }

  /// يرفع مرفقات منشور وينشئ صفوف post_media.
  static Future<void> attachToPost(String postId, List<PickedMedia> items) async {
    final uid = supabase.auth.currentUser!.id;
    var n = 0;
    for (final m in items) {
      final u = await upload('post-media', '$uid/$postId', m, n++);
      await supabase.from('post_media').insert({
        'post_id': postId,
        'storage_path': u.path,
        'thumb_path': u.thumbPath,
        'kind': m.kind,
        'title': m.title,
        'mime': u.mime,
        'size_bytes': u.size,
      });
    }
  }
}
