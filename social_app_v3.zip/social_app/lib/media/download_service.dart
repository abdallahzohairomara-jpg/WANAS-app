import 'dart:io';

import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../strings.dart';
import 'media_service.dart';

/// تنزيل ملف من التخزين الخاص (بالجودة الأصلية) وحفظه على الجهاز.
/// الصور والفيديو تُحفظ في المعرض، والباقي عبر قائمة المشاركة ("حفظ في الملفات").
class DownloadService {
  static Future<File> fetch(String bucket, String path, {String? name}) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/${name ?? path.split('/').last}');
    if (await file.exists() && await file.length() > 0) return file;
    final url = await MediaService.signedUrl(bucket, path);
    final client = HttpClient();
    try {
      final req = await client.getUrl(Uri.parse(url));
      final resp = await req.close();
      if (resp.statusCode != 200) {
        throw HttpException('status ${resp.statusCode}');
      }
      final sink = file.openWrite();
      await resp.pipe(sink);
      return file;
    } catch (e) {
      if (await file.exists()) await file.delete();
      rethrow;
    } finally {
      client.close();
    }
  }

  static Future<void> saveToDevice(
      BuildContext context, String bucket, String path, String kind,
      {String? name}) async {
    final s = S.of(context);
    final messenger = ScaffoldMessenger.of(context);
    messenger.showSnackBar(SnackBar(content: Text(s.t('downloading'))));
    try {
      final f = await fetch(bucket, path, name: name);
      if (kind == 'image') {
        await Gal.putImage(f.path);
      } else if (kind == 'video') {
        await Gal.putVideo(f.path);
      } else {
        await Share.shareXFiles([XFile(f.path)]);
      }
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(s.t('saved_to_device'))));
    } catch (_) {
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(s.t('error'))));
    }
  }
}
