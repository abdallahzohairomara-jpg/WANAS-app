// ضع هنا بيانات مشروع Supabase (Project Settings > API).
// مهم: استخدم مفتاح anon فقط. لا تضع مفتاح service_role أبدًا داخل التطبيق.
const supabaseUrl = 'https://YOUR-PROJECT.supabase.co';
const supabaseAnonKey = 'YOUR-ANON-KEY';

// المزود الافتراضي لبدء مكالمة جديدة: 'livekit' أو 'agora'.
// أسرار المزودين تُضبط على الخادم (Edge Function) وليس هنا.
const defaultCallProvider = 'livekit';

// الحد الأقصى لحجم الملف الواحد (بايت). يطابق حد الحاويات في phase6/phase8 (الخطة المجانية 50MB).
// لرفعه: غيّر حد الحاويات في Supabase (Storage > Settings) ثم هذا الرقم.
const maxUploadBytes = 50 * 1024 * 1024;
