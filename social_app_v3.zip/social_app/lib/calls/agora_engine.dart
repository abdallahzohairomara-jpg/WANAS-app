import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/widgets.dart';

import 'call_engine.dart';

class AgoraEngine extends CallEngine {
  RtcEngine? _engine;
  String _channel = '';
  String _myId = '';
  bool _mic = true;
  bool _cam = false;

  // معرّف Agora الرقمي -> هل الفيديو يعمل عنده
  final Map<int, bool> _remoteVideo = {};
  // نحتفظ بالودجت لكل مشارك حتى لا يعاد إنشاؤها مع كل تحديث
  final Map<int, Widget> _views = {};
  Widget? _localView;

  @override
  bool get micOn => _mic;
  @override
  bool get camOn => _cam;

  // معرّف Agora الرقمي -> معرّف المستخدم، يُبنى من أعضاء المحادثة
  final Map<int, String> _uidToUser = {};
  void registerMembers(Iterable<String> userIds) {
    for (final id in userIds) {
      _uidToUser[agoraUidFor(id)] = id;
    }
  }

  @override
  List<CallParticipant> get participants {
    final e = _engine;
    if (e == null) return const [];
    final list = <CallParticipant>[
      CallParticipant(
          userId: _myId, isLocal: true, video: _cam ? _localView : null),
    ];
    for (final entry in _remoteVideo.entries) {
      final uid = entry.key;
      Widget? v;
      if (entry.value) {
        v = _views.putIfAbsent(
          uid,
          () => AgoraVideoView(
            controller: VideoViewController.remote(
              rtcEngine: e,
              canvas: VideoCanvas(uid: uid),
              connection: RtcConnection(channelId: _channel),
            ),
          ),
        );
      }
      list.add(CallParticipant(
          userId: _uidToUser[uid] ?? '$uid', isLocal: false, video: v));
    }
    return list;
  }

  @override
  Future<void> join(CallCredentials creds,
      {required bool video, required String myUserId}) async {
    _myId = myUserId;
    _channel = creds.channel!;
    final e = createAgoraRtcEngine();
    _engine = e;
    await e.initialize(RtcEngineContext(
      appId: creds.appId!,
      channelProfile: ChannelProfileType.channelProfileCommunication,
    ));

    e.registerEventHandler(RtcEngineEventHandler(
      onUserJoined: (conn, remoteUid, elapsed) {
        _remoteVideo.putIfAbsent(remoteUid, () => false);
        notifyListeners();
      },
      onUserOffline: (conn, remoteUid, reason) {
        _remoteVideo.remove(remoteUid);
        _views.remove(remoteUid);
        notifyListeners();
      },
      onRemoteVideoStateChanged: (conn, remoteUid, state, reason, elapsed) {
        final on = state == RemoteVideoState.remoteVideoStateDecoding;
        _remoteVideo[remoteUid] = on;
        if (!on) _views.remove(remoteUid);
        notifyListeners();
      },
    ));

    await e.enableVideo();
    _localView = AgoraVideoView(
      controller: VideoViewController(
        rtcEngine: e,
        canvas: const VideoCanvas(uid: 0),
      ),
    );
    if (video) {
      await e.startPreview();
      _cam = true;
    }

    await e.joinChannel(
      token: creds.token,
      channelId: creds.channel!,
      uid: creds.uid!,
      options: ChannelMediaOptions(
        autoSubscribeAudio: true,
        autoSubscribeVideo: true,
        publishMicrophoneTrack: true,
        publishCameraTrack: video,
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
      ),
    );
    notifyListeners();
  }

  @override
  Future<void> toggleMic() async {
    _mic = !_mic;
    await _engine?.muteLocalAudioStream(!_mic);
    notifyListeners();
  }

  @override
  Future<void> toggleCamera() async {
    _cam = !_cam;
    if (_cam) {
      await _engine?.startPreview();
    } else {
      await _engine?.stopPreview();
    }
    await _engine
        ?.updateChannelMediaOptions(ChannelMediaOptions(publishCameraTrack: _cam));
    notifyListeners();
  }

  @override
  Future<void> switchCamera() async => _engine?.switchCamera();

  @override
  Future<void> leave() async {
    final e = _engine;
    _engine = null;
    if (e != null) {
      await e.leaveChannel();
      await e.release();
    }
  }
}
