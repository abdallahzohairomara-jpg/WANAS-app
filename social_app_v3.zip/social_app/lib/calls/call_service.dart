import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../main.dart';
import 'agora_engine.dart';
import 'call_engine.dart';
import 'livekit_engine.dart';

const callProviders = {'livekit': 'LiveKit', 'agora': 'Agora'};

/// المزود الذي تبدأ به أنت مكالماتك الجديدة. المنضمّون يتبعون مزود المكالمة نفسها.
final providerNotifier = ValueNotifier<String>(defaultCallProvider);

class CallService {
  static CallEngine createEngine(String provider) {
    switch (provider) {
      case 'agora':
        return AgoraEngine();
      case 'livekit':
      default:
        return LiveKitEngine();
    }
  }

  /// ينشئ سجل المكالمة (فيصل الإشعار لباقي الأعضاء) ويرجع صفّها.
  static Future<Map<String, dynamic>> startCall({
    required String conversationId,
    required bool video,
    required String provider,
  }) async {
    final row = await supabase
        .from('calls')
        .insert({
          'conversation_id': conversationId,
          'provider': provider,
          'is_video': video,
        })
        .select()
        .single();
    return Map<String, dynamic>.from(row);
  }

  /// تصريح الدخول من دالة الخادم (تتحقق من العضوية والحظر).
  static Future<CallCredentials> fetchCredentials({
    required String conversationId,
    required String provider,
  }) async {
    final res = await supabase.functions.invoke('call-token',
        body: {'conversation_id': conversationId, 'provider': provider});
    final data = res.data;
    if (data is! Map) throw Exception('bad response');
    return CallCredentials.fromJson(Map<String, dynamic>.from(data));
  }

  static Future<void> endCall(String callId) async {
    try {
      await supabase.from('calls').update({'status': 'ended'}).eq('id', callId);
    } on PostgrestException catch (_) {}
  }
}
