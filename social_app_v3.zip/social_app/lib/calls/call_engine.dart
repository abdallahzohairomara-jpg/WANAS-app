import 'package:flutter/widgets.dart';

/// بيانات الدخول التي تُرجعها دالة call-token.
class CallCredentials {
  final String provider;
  final String token;
  final String? url; // LiveKit
  final String? appId; // Agora
  final int? uid; // Agora
  final String? channel; // Agora

  const CallCredentials({
    required this.provider,
    required this.token,
    this.url,
    this.appId,
    this.uid,
    this.channel,
  });

  factory CallCredentials.fromJson(Map<String, dynamic> j) => CallCredentials(
        provider: j['provider'] as String,
        token: j['token'] as String,
        url: j['url'] as String?,
        appId: j['appId'] as String?,
        uid: (j['uid'] as num?)?.toInt(),
        channel: j['channel'] as String?,
      );
}

/// مشارك في المكالمة كما تعرضه الواجهة، بغض النظر عن المزود.
class CallParticipant {
  final String userId;
  final bool isLocal;
  final Widget? video; // null = الكاميرا مغلقة
  const CallParticipant(
      {required this.userId, required this.isLocal, this.video});
}

/// نفس معرّف Agora الرقمي الذي تحسبه الدالة على الخادم.
int agoraUidFor(String userId) {
  final n = int.parse(userId.replaceAll('-', '').substring(0, 8), radix: 16);
  return n == 0 ? 1 : n;
}

/// واجهة موحدة: لإضافة مزود جديد (Daily, 100ms...) يكفي تنفيذ هذه الواجهة.
abstract class CallEngine extends ChangeNotifier {
  bool _disposed = false;

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }

  // أحداث المزود قد تصل بعد إغلاق الشاشة؛ نتجاهلها بدل رمي خطأ
  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  List<CallParticipant> get participants;
  bool get micOn;
  bool get camOn;

  Future<void> join(CallCredentials creds,
      {required bool video, required String myUserId});
  Future<void> toggleMic();
  Future<void> toggleCamera();
  Future<void> switchCamera();
  Future<void> leave();
}
