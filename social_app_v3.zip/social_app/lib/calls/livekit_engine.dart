import 'package:flutter/widgets.dart';
import 'package:livekit_client/livekit_client.dart';

import 'call_engine.dart';

class LiveKitEngine extends CallEngine {
  Room? _room;
  bool _mic = true;
  bool _cam = false;
  bool _front = true;
  String _myId = '';

  @override
  bool get micOn => _mic;
  @override
  bool get camOn => _cam;

  Widget? _videoOf(Participant p) {
    for (final pub in p.videoTrackPublications) {
      final t = pub.track;
      if (t is VideoTrack &&
          !pub.muted &&
          pub.source != TrackSource.screenShareVideo) {
        return VideoTrackRenderer(t, key: ValueKey(pub.sid));
      }
    }
    return null;
  }

  @override
  List<CallParticipant> get participants {
    final room = _room;
    if (room == null) return const [];
    final list = <CallParticipant>[];
    final local = room.localParticipant;
    if (local != null) {
      list.add(CallParticipant(
          userId: _myId, isLocal: true, video: _cam ? _videoOf(local) : null));
    }
    for (final p in room.remoteParticipants.values) {
      list.add(CallParticipant(
          userId: p.identity, isLocal: false, video: _videoOf(p)));
    }
    return list;
  }

  @override
  Future<void> join(CallCredentials creds,
      {required bool video, required String myUserId}) async {
    _myId = myUserId;
    final room =
        Room(roomOptions: RoomOptions(adaptiveStream: true, dynacast: true));
    _room = room;
    room.addListener(notifyListeners);
    await room.connect(creds.url!, creds.token);
    await room.localParticipant?.setMicrophoneEnabled(true);
    _mic = true;
    if (video) {
      await room.localParticipant?.setCameraEnabled(true);
      _cam = true;
    }
    notifyListeners();
  }

  @override
  Future<void> toggleMic() async {
    _mic = !_mic;
    await _room?.localParticipant?.setMicrophoneEnabled(_mic);
    notifyListeners();
  }

  @override
  Future<void> toggleCamera() async {
    _cam = !_cam;
    await _room?.localParticipant?.setCameraEnabled(_cam);
    notifyListeners();
  }

  @override
  Future<void> switchCamera() async {
    for (final pub in _room?.localParticipant?.videoTrackPublications ?? []) {
      final t = pub.track;
      if (t is LocalVideoTrack) {
        _front = !_front;
        await t.setCameraPosition(
            _front ? CameraPosition.front : CameraPosition.back);
      }
    }
  }

  @override
  Future<void> leave() async {
    final room = _room;
    _room = null;
    if (room != null) {
      room.removeListener(notifyListeners);
      await room.disconnect();
      await room.dispose();
    }
  }
}
