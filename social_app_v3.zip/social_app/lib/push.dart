import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

import 'main.dart';
import 'screens/call_screen.dart';
import 'screens/chat_screen.dart';

/// إشعارات FCM. إن لم يُضبط Firebase بعد (لا يوجد google-services.json)
/// يعمل التطبيق كالمعتاد بدون إشعارات خارجية.
class PushService {
  static bool _started = false;
  static bool get _ready => Firebase.apps.isNotEmpty;

  static Future<void> init() async {
    if (_started) return;
    _started = true;
    try {
      await Firebase.initializeApp();
    } catch (_) {
      return;
    }
    final fm = FirebaseMessaging.instance;
    try {
      await fm.requestPermission();
      final token = await fm.getToken();
      if (token != null) await _register(token);
      fm.onTokenRefresh.listen(_register);
      FirebaseMessaging.onMessageOpenedApp.listen(_open);
      final initial = await fm.getInitialMessage();
      if (initial != null) _open(initial);
    } catch (_) {}
  }

  static Future<void> _register(String token) async {
    try {
      await supabase.rpc('register_device_token', params: {'t': token});
    } catch (_) {}
  }

  /// يُستدعى قبل تسجيل الخروج حتى لا تصل إشعارات الحساب لهذا الجهاز.
  static Future<void> unregister() async {
    _started = false;
    if (!_ready) return;
    try {
      final fm = FirebaseMessaging.instance;
      final token = await fm.getToken();
      if (token != null) {
        await supabase.from('device_tokens').delete().eq('token', token);
      }
      await fm.deleteToken();
    } catch (_) {}
  }

  static Future<void> _open(RemoteMessage m) async {
    final d = m.data;
    final nav = navigatorKey.currentState;
    if (nav == null) return;

    if (d['type'] == 'message' && d['conversation_id'] != null) {
      nav.push(MaterialPageRoute(
        builder: (_) => ChatScreen(
            conversationId: d['conversation_id']!, title: d['title'] ?? ''),
      ));
    } else if (d['type'] == 'call' && d['call_id'] != null) {
      // الدخول فقط إن كانت المكالمة ما زالت مفتوحة
      try {
        final row = await supabase
            .from('calls')
            .select('status')
            .eq('id', d['call_id']!)
            .single();
        if (row['status'] != 'open') return;
      } catch (_) {
        return;
      }
      nav.push(MaterialPageRoute(
        builder: (_) => CallScreen(
          callId: d['call_id']!,
          conversationId: d['conversation_id']!,
          provider: d['provider'] ?? 'livekit',
          video: d['is_video'] == 'true',
          title: d['title'] ?? '',
        ),
      ));
    }
  }
}
