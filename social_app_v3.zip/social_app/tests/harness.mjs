import { PGlite } from "@electric-sql/pglite";
import fs from "node:fs";

const APP = new URL("../", import.meta.url).pathname.replace(/\/$/, "");
const files = process.argv.slice(2);
const sqlFiles = files.length ? files : [
  "phase1_schema.sql", "phase2_messages.sql", "phase3_calls.sql", "phase4_push.sql",
  "phase5_security_fixes.sql", "phase6_media.sql", "phase7_features.sql", "phase8_social.sql",
];

export const db = new PGlite();

export async function boot(list = sqlFiles) {
  await db.exec(fs.readFileSync(new URL("./stub.sql", import.meta.url), "utf8"));
  for (const f of list) {
    let sql = fs.readFileSync(f.startsWith("/") ? f : `${APP}/${f}`, "utf8");
    sql = sql.replace(/create extension if not exists "pgcrypto";/i, ""); // مضمّن في Postgres الحديث
    try {
      await db.exec(sql);
    } catch (e) {
      console.error(`❌ فشل تشغيل ${f}: ${e.message}`);
      process.exit(2);
    }
    console.log(`✔ تم تشغيل ${f}`);
  }
}

// ---------- أدوات الاختبار ----------
export const U = {
  A: "11111111-1111-1111-1111-111111111111",
  B: "22222222-2222-2222-2222-222222222222",
  C: "33333333-3333-3333-3333-333333333333",
  D: "44444444-4444-4444-4444-444444444444",
  E: "55555555-5555-5555-5555-555555555555",
  F: "66666666-6666-6666-6666-666666666666",
};

export async function admin(sql, params = []) {
  await db.exec("reset role");
  return db.query(sql, params);
}

// يشغّل استعلامًا بصلاحيات مستخدم معيّن (uid=null يعني anon)
export async function as(uid, sql, params = []) {
  await db.exec("reset role");
  if (uid) {
    await db.exec("set role authenticated");
    await db.query("select set_config('request.jwt.claims', $1, false)", [
      JSON.stringify({ sub: uid, role: "authenticated" }),
    ]);
  } else {
    await db.exec("set role anon");
    await db.query("select set_config('request.jwt.claims', '', false)");
  }
  try {
    const r = await db.query(sql, params);
    return { ok: true, rows: r.rows };
  } catch (e) {
    return { ok: false, err: e.message, rows: [] };
  } finally {
    await db.exec("reset role");
  }
}

const results = [];
export function check(name, cond, detail = "") {
  results.push({ name, pass: !!cond, detail });
}
export const denied = (r) => !r.ok || r.rows.length === 0; // رُفض أو لم يؤثر على أي صف
export const allowed = (r) => r.ok && r.rows.length > 0;

export function report() {
  let fail = 0;
  for (const r of results) {
    if (!r.pass) fail++;
    console.log(`${r.pass ? "PASS" : "FAIL"}  ${r.name}${r.pass ? "" : "  ← " + r.detail}`);
  }
  console.log(`\n${results.length - fail}/${results.length} نجح، ${fail} فشل`);
  return fail;
}
