import { boot, as, admin, check, denied, allowed, report, U } from "./harness.mjs";

const list = process.env.SQL_FILES ? process.env.SQL_FILES.split(",") : undefined;
await boot(list);

const { A, B, C, D, E, F } = U;
const P = {
  pub: "a0000000-0000-0000-0000-000000000001",
  fr: "a0000000-0000-0000-0000-000000000002",
  me: "a0000000-0000-0000-0000-000000000003",
  frEx: "a0000000-0000-0000-0000-000000000004",
  list: "a0000000-0000-0000-0000-000000000005",
};
const LIST = "b0000000-0000-0000-0000-000000000001";

// ---------- بيانات أولية (بصلاحيات المدير) ----------
for (const [k, id] of Object.entries(U)) {
  await admin("insert into auth.users (id, email) values ($1, $2)", [id, `${k}@test.dev`]);
}
await admin("update profiles set who_can_message='nobody' where id=$1", [D]);
await admin("update profiles set who_can_message='friends' where id=$1", [F]);
await admin("insert into friendships (requester_id,addressee_id,status) values ($1,$2,'accepted')", [A, B]);
await admin("insert into friend_lists (id,owner_id,name) values ($1,$2,'close')", [LIST, A]);
await admin("insert into friend_list_members (list_id,member_id) values ($1,$2)", [LIST, C]);
const ins = (id, aud, listId = null) =>
  admin("insert into posts (id,author_id,body,audience,list_id) values ($1,$2,'x',$3,$4)", [id, A, aud, listId]);
await ins(P.pub, "public");
await ins(P.fr, "friends");
await ins(P.me, "only_me");
await ins(P.frEx, "friends");
await ins(P.list, "list", LIST);
await admin("insert into post_exclusions (post_id, excluded_id) values ($1,$2)", [P.frEx, B]);

const seen = async (uid) => {
  const r = await as(uid, "select id from posts");
  return new Set(r.rows.map((x) => x.id));
};

// ---------- 1) من يرى أي منشور ----------
{
  const a = await seen(A), b = await seen(B), c = await seen(C), e = await seen(E);
  check("المؤلف يرى منشوراته الخمسة", Object.values(P).every((id) => a.has(id)));
  check("الصديق B يرى العام والأصدقاء فقط", b.has(P.pub) && b.has(P.fr) && !b.has(P.me) && !b.has(P.frEx) && !b.has(P.list),
    [...b].join(","));
  check("الغريب C يرى العام ومنشور القائمة التي هو فيها فقط", c.has(P.pub) && c.has(P.list) && !c.has(P.fr) && !c.has(P.me) && !c.has(P.frEx),
    [...c].join(","));
  check("غريب خارج القائمة E يرى العام فقط", e.size === 1 && e.has(P.pub), [...e].join(","));
  const anon = await as(null, "select id from posts");
  check("مستخدم غير مسجل لا يرى شيئًا", anon.rows.length === 0, JSON.stringify(anon).slice(0, 80));
}

// ---------- 2) الإعجاب والتعليق والحفظ ----------
check("غريب لا يستطيع الإعجاب بمنشور أصدقاء", denied(await as(C, "insert into likes (post_id) values ($1) returning *", [P.fr])));
check("صديق يستطيع الإعجاب بمنشور أصدقاء", allowed(await as(B, "insert into likes (post_id) values ($1) returning *", [P.fr])));
check("لا يمكن الإعجاب باسم شخص آخر", denied(await as(B, "insert into likes (post_id,user_id) values ($1,$2) returning *", [P.pub, A])));
check("غريب لا يعلّق على منشور أصدقاء", denied(await as(C, "insert into comments (post_id,body) values ($1,'hi') returning *", [P.fr])));
check("صديق يعلّق على منشور أصدقاء", allowed(await as(B, "insert into comments (post_id,body) values ($1,'hi') returning *", [P.fr])));
check("لا يمكن التعليق باسم شخص آخر", denied(await as(B, "insert into comments (post_id,body,author_id) values ($1,'hi',$2) returning *", [P.fr, A])));
check("غريب لا يرى تعليقات منشور أصدقاء", (await as(C, "select * from comments where post_id=$1", [P.fr])).rows.length === 0);
check("غريب لا يحفظ منشور 'أنا فقط'", denied(await as(B, "insert into saved_posts (post_id) values ($1) returning *", [P.me])));
check("حفظ منشور عام يعمل", allowed(await as(B, "insert into saved_posts (post_id) values ($1) returning *", [P.pub])));
check("المحفوظات خاصة بصاحبها", (await as(A, "select * from saved_posts")).rows.length === 0);

// ---------- 3) تعديل وحذف ما ليس لك ----------
check("لا يحذف أحد منشور غيره", denied(await as(B, "delete from posts where id=$1 returning id", [P.pub])));
check("لا يعدّل أحد منشور غيره", denied(await as(B, "update posts set body='hacked' where id=$1 returning id", [P.pub])));
check("لا يُنشر منشور باسم غيرك", denied(await as(B, "insert into posts (author_id,body) values ($1,'fake') returning id", [A])));
check("صاحب المنشور يحذف تعليقًا على منشوره", allowed(await as(A, "delete from comments where post_id=$1 returning id", [P.fr])));
check("لا يعدّل أحد ملف غيره", denied(await as(B, "update profiles set bio='x' where id=$1 returning id", [A])));
check("المستخدم يعدّل ملفه", allowed(await as(B, "update profiles set bio='x' where id=$1 returning id", [B])));
check("منشور بقائمة ليست قائمتك مرفوض (ثغرة محتملة)",
  denied(await as(B, "insert into posts (author_id,body,audience,list_id) values ($1,'spam','list',$2) returning id", [B, LIST])),
  "B استطاع ربط منشوره بقائمة A فيصل لأعضائها");

check("منشور بقائمتك أنت ينجح", allowed(await as(A, "insert into posts (author_id,body,audience,list_id) values ($1,'ok','list',$2) returning id", [A, LIST])));
{
  const c1 = await as(A, "insert into comments (post_id,body) values ($1,'root') returning id", [P.pub]);
  const cid = c1.rows[0]?.id;
  check("رد على تعليق في نفس المنشور ينجح", allowed(await as(A, "insert into comments (post_id,body,parent_id) values ($1,'re',$2) returning id", [P.pub, cid])));
  check("رد على تعليق من منشور آخر مرفوض", denied(await as(A, "insert into comments (post_id,body,parent_id) values ($1,'re',$2) returning id", [P.fr, cid])));
}

// ---------- 4) الصداقة ----------
check("لا يُرسل طلب صداقة باسم غيرك", denied(await as(E, "insert into friendships (requester_id,addressee_id) values ($1,$2) returning *", [C, D])));
check("لا يُنشأ طلب بحالة مقبول مباشرة", denied(await as(C, "insert into friendships (requester_id,addressee_id,status) values ($1,$2,'accepted') returning *", [C, E])));
await as(A, "insert into friendships (requester_id,addressee_id) values ($1,$2)", [A, D]);
check("المرسل لا يقبل طلبه بنفسه", denied(await as(A, "update friendships set status='accepted' where requester_id=$1 and addressee_id=$2 returning *", [A, D])));
check("طرف ثالث لا يقبل طلب غيره", denied(await as(E, "update friendships set status='accepted' where requester_id=$1 and addressee_id=$2 returning *", [A, D])));
check("المُرسَل إليه يقبل", allowed(await as(D, "update friendships set status='accepted' where requester_id=$1 and addressee_id=$2 returning *", [A, D])));
check("طرف ثالث لا يرى علاقات غيره", (await as(E, "select * from friendships")).rows.length === 0);

// ---------- 5) تسريب معلومات عبر الدوال المساعدة ----------
{
  const r = await as(C, "select are_friends($1,$2) as v", [A, B]);
  check("لا يمكن لغريب معرفة إن كان A وB صديقين (are_friends)", r.ok && r.rows[0]?.v !== true, "الدالة رجعت true لغريب");
  await as(A, "insert into blocks (blocker_id,blocked_id) values ($1,$2)", [A, F]);
  const r2 = await as(C, "select is_blocked_between($1,$2) as v", [A, F]);
  check("لا يمكن لغريب معرفة من حظر من (is_blocked_between)", r2.ok && r2.rows[0]?.v !== true, "الدالة رجعت true لغريب");
  check("الحظر خاص بصاحبه", (await as(F, "select * from blocks")).rows.length === 0);
  await as(A, "delete from blocks where blocked_id=$1", [F]);
}

// ---------- 6) الرسائل ----------
let dm;
{
  const r = await as(A, "select get_or_create_dm($1) as id", [B]);
  dm = r.rows[0]?.id;
  check("إنشاء محادثة فردية بين صديقين", !!dm, r.err);
  const again = await as(B, "select get_or_create_dm($1) as id", [A]);
  check("لا تتكرر المحادثة الفردية", again.rows[0]?.id === dm);
  check("العضو يرسل رسالة", allowed(await as(A, "insert into messages (conversation_id,body) values ($1,'hello') returning id", [dm])));
  check("العضو الآخر يقرأ الرسالة", (await as(B, "select * from messages where conversation_id=$1", [dm])).rows.length === 1);
  check("غريب لا يقرأ رسائل المحادثة", (await as(C, "select * from messages where conversation_id=$1", [dm])).rows.length === 0);
  check("غريب لا يرى المحادثة نفسها", (await as(C, "select * from conversations where id=$1", [dm])).rows.length === 0);
  check("غريب لا يرسل في محادثة ليس عضوًا بها", denied(await as(C, "insert into messages (conversation_id,body) values ($1,'x') returning id", [dm])));
  check("لا يُرسل باسم شخص آخر", denied(await as(A, "insert into messages (conversation_id,body,sender_id) values ($1,'x',$2) returning id", [dm, B])));
  check("غريب لا يضيف نفسه لمحادثة غيره", denied(await as(C, "insert into conversation_members (conversation_id,user_id) values ($1,$2) returning *", [dm, C])));
  check("غريب لا يرى أعضاء محادثة غيره", (await as(C, "select * from conversation_members where conversation_id=$1", [dm])).rows.length === 0);
}
{
  const r = await as(A, "select get_or_create_dm($1) as id", [D]); // D أغلق الرسائل رغم أنه صديق
  check("لا مراسلة لمن أغلق الرسائل (nobody)", !r.ok, "نجح");
  const r2 = await as(C, "select get_or_create_dm($1) as id", [F]); // F يقبل الأصدقاء فقط، وC غريب
  check("لا مراسلة لغريب عند 'الأصدقاء فقط'", !r2.ok, "نجح");
  const r3 = await as(C, "select get_or_create_dm($1) as id", [C]);
  check("لا مراسلة مع النفس", !r3.ok, "نجح");
  const r4 = await as(C, "select create_group('g', array[$1::uuid,$2::uuid]) as id", [D, E]);
  check("مجموعة تضم من أغلق رسائله ترفض", !r4.ok, "نجح");
  const r5 = await as(C, "select create_group('g', array[$1::uuid]) as id", [E]);
  check("مجموعة عادية تنجح", r5.ok && !!r5.rows[0]?.id, r5.err);
  if (r5.ok) {
    const m = await admin("select user_id, is_admin from conversation_members where conversation_id=$1", [r5.rows[0].id]);
    const ids = new Set(m.rows.map((x) => x.user_id));
    check("أعضاء المجموعة هم المنشئ والمدعو، والمنشئ مشرف",
      m.rows.length === 2 && ids.has(C) && ids.has(E) && m.rows.find((x) => x.user_id === C).is_admin === true);
    check("عضو المجموعة يرى المحادثة، وغير العضو لا يراها",
      (await as(E, "select * from conversations where id=$1", [r5.rows[0].id])).rows.length === 1 &&
      (await as(A, "select * from conversations where id=$1", [r5.rows[0].id])).rows.length === 0);
  }
  const r6 = await as(C, "select create_group('', array[$1::uuid]) as id", [E]);
  check("اسم مجموعة فارغ يرفض", !r6.ok);
}
{
  // تشديد: إنشاء المحادثات يجب أن يمر عبر الدوال فقط (حدّ الأعضاء + فحص الخصوصية)
  const r = await as(C, "insert into conversations (is_group,title) values (true,'direct') returning id");
  check("إنشاء محادثة مباشرة من العميل غير مسموح (يجب عبر الدوال)", denied(r), "العميل ينشئ محادثات متجاوزًا حدّ الأعضاء");
}

// ---------- 7) الحظر بعد بدء المحادثة ----------
{
  await as(A, "insert into blocks (blocker_id,blocked_id) values ($1,$2)", [A, B]);
  check("المحظور لا يرسل في محادثة قائمة", denied(await as(B, "insert into messages (conversation_id,body) values ($1,'x') returning id", [dm])));
  check("الحاظر أيضًا لا يرسل", denied(await as(A, "insert into messages (conversation_id,body) values ($1,'x') returning id", [dm])));
  check("المحظور لا يرى منشورات الحاظر العامة", !(await seen(B)).has(P.pub));
  check("الحاظر لا يرى منشورات المحظور", (await as(A, "select * from posts where author_id=$1", [B])).rows.length === 0 );
  check("ملف الحاظر مخفي عن المحظور", (await as(B, "select * from profiles where id=$1", [A])).rows.length === 0);
  check("لا إنشاء محادثة جديدة بين المحظورين", !(await as(B, "select get_or_create_dm($1)", [A])).ok);
  check("لا طلب صداقة بين المحظورين", denied(await as(B, "insert into friendships (requester_id,addressee_id) values ($1,$2) returning *", [B, A])));
  await as(A, "delete from blocks where blocked_id=$1", [B]);
}

// ---------- 8) المكالمات ----------
let call;
{
  check("غريب لا يبدأ مكالمة في محادثة ليس عضوًا بها", denied(await as(C, "insert into calls (conversation_id,provider) values ($1,'livekit') returning id", [dm])));
  const r = await as(B, "insert into calls (conversation_id,provider,is_video) values ($1,'agora',true) returning id", [dm]);
  call = r.rows[0]?.id;
  check("العضو يبدأ مكالمة", !!call, r.err);
  check("لا مكالمة باسم غيرك", denied(await as(B, "insert into calls (conversation_id,provider,caller_id) values ($1,'agora',$2) returning id", [dm, A])));
  check("مزود غير معروف يرفض", denied(await as(B, "insert into calls (conversation_id,provider) values ($1,'evil') returning id", [dm])));
  check("غريب لا يرى المكالمات", (await as(C, "select * from calls")).rows.length === 0);
  check("العضو لا يغيّر مزود المكالمة", denied(await as(A, "update calls set provider='livekit' where id=$1 returning id", [call])));
  check("غريب لا ينهي مكالمة غيره", denied(await as(C, "update calls set status='ended' where id=$1 returning id", [call])));
  check("العضو ينهي المكالمة", allowed(await as(A, "update calls set status='ended' where id=$1 returning id", [call])));
  check("لا تُعاد المكالمة المنتهية للحالة المفتوحة", denied(await as(A, "update calls set status='open' where id=$1 returning id", [call])));
}

// ---------- 9) البلاغات ورموز الأجهزة ----------
{
  check("المستخدم يرسل بلاغًا", allowed(await as(B, "insert into reports (target_type,target_id,reason) values ('post',$1,'spam!!') returning id", [P.pub])));
  check("المُبلَّغ عنه لا يقرأ البلاغات", (await as(A, "select * from reports")).rows.length === 0);
  check("لا بلاغ باسم غيرك", denied(await as(B, "insert into reports (reporter_id,target_type,target_id,reason) values ($1,'post',$2,'abc') returning id", [A, P.pub])));

  const tok = "T".repeat(40);
  check("تسجيل رمز جهاز", (await as(A, "select register_device_token($1)", [tok])).ok);
  check("غير المسجل لا يستدعي تسجيل الرموز", !(await as(null, "select register_device_token($1)", [tok])).ok);
  check("لا إدراج مباشر في جدول الرموز", denied(await as(B, "insert into device_tokens (token,user_id) values ($1,$2) returning *", ["Z".repeat(40), B])));
  check("المستخدم لا يرى رموز غيره", (await as(B, "select * from device_tokens")).rows.length === 0);
  await as(B, "select register_device_token($1)", [tok]); // نفس الجهاز يسجّل دخول مستخدم آخر
  const owner = await admin("select user_id from device_tokens where token=$1", [tok]);
  check("الرمز ينتقل لآخر مستخدم سجّل على الجهاز", owner.rows[0]?.user_id === B);
  check("المستخدم السابق لا يحذف رمز الجهاز بعد انتقاله", denied(await as(A, "delete from device_tokens where token=$1 returning token", [tok])));
}


// ---------- 10) الوسائط (التخزين) ----------
{
  const put = (uid, bucket, name) =>
    as(uid, "insert into storage.objects (bucket_id,name) values ($1,$2) returning id", [bucket, name]);
  const seeObj = async (uid, name) =>
    (await as(uid, "select id from storage.objects where name=$1", [name])).rows.length === 1;

  // رفع وسائط منشور
  check("صاحب المنشور يرفع وسائط تحت {هو}/{المنشور}/", allowed(await put(A, "post-media", `${A}/${P.pub}/a.jpg`)));
  check("غير صاحب المنشور لا يرفع لمنشور غيره (حتى بمجلده)", denied(await put(B, "post-media", `${B}/${P.pub}/b.jpg`)));
  check("لا رفع داخل مجلد شخص آخر", denied(await put(A, "post-media", `${B}/${P.pub}/x.jpg`)));
  check("لا رفع بعمق مسار غير متوقع", denied(await put(A, "post-media", `${A}/${P.pub}/sub/a.jpg`)));
  check("لا رفع لمنشور غير موجود", denied(await put(A, "post-media", `${A}/99999999-9999-9999-9999-999999999999/a.jpg`)));
  check("غير المسجل لا يرفع", denied(await put(null, "post-media", `${A}/${P.pub}/anon.jpg`)));

  // قراءة وسائط المنشور تتبع صلاحية المنشور
  await put(A, "post-media", `${A}/${P.fr}/f.jpg`);
  await put(A, "post-media", `${A}/${P.me}/m.jpg`);
  await put(A, "post-media", `${A}/${P.frEx}/e.jpg`);
  check("غريب يرى وسائط منشور عام", await seeObj(E, `${A}/${P.pub}/a.jpg`));
  check("صديق يرى وسائط منشور الأصدقاء", await seeObj(B, `${A}/${P.fr}/f.jpg`));
  check("غريب لا يرى وسائط منشور الأصدقاء", !(await seeObj(E, `${A}/${P.fr}/f.jpg`)));
  check("صديق لا يرى وسائط منشور 'أنا فقط'", !(await seeObj(B, `${A}/${P.me}/m.jpg`)));
  check("المستثنى لا يرى وسائط المنشور المستثنى منه", !(await seeObj(B, `${A}/${P.frEx}/e.jpg`)));
  check("صاحب المنشور يرى وسائطه", await seeObj(A, `${A}/${P.me}/m.jpg`));
  check("غير المسجل لا يرى الوسائط", !(await seeObj(null, `${A}/${P.pub}/a.jpg`)));
  check("لا يحذف أحد وسائط غيره", denied(await as(B, "delete from storage.objects where name=$1 returning id", [`${A}/${P.pub}/a.jpg`])));
  check("صاحب الوسائط يحذفها", allowed(await as(A, "delete from storage.objects where name=$1 returning id", [`${A}/${P.frEx}/e.jpg`])));

  // سجلات post_media
  check("ربط ملف بمنشورك بمساره الصحيح ينجح", allowed(await as(A, "insert into post_media (post_id,storage_path,kind) values ($1,$2,'image') returning id", [P.pub, `${A}/${P.pub}/a.jpg`])));
  check("ربط مسار ملف شخص آخر بمنشورك مرفوض", denied(await as(A, "insert into post_media (post_id,storage_path,kind) values ($1,$2,'image') returning id", [P.pub, `${B}/${P.pub}/z.jpg`])));
  check("إضافة وسائط لمنشور غيرك مرفوضة", denied(await as(B, "insert into post_media (post_id,storage_path,kind) values ($1,$2,'image') returning id", [P.pub, `${A}/${P.pub}/a.jpg`])));
  check("غريب لا يرى سجل وسائط منشور أصدقاء", (await as(E, "select * from post_media where post_id=$1", [P.fr])).rows.length === 0);

  // وسائط المحادثات
  const other = (await as(C, "select get_or_create_dm($1) as id", [E])).rows[0]?.id;
  check("عضو المحادثة يرفع ملفًا صوتيًا", allowed(await put(A, "chat-media", `${dm}/voice.m4a`)));
  check("غير العضو لا يرفع لمحادثة غيره", denied(await put(C, "chat-media", `${dm}/evil.jpg`)));
  check("عضو المحادثة يقرأ الملف", await seeObj(B, `${dm}/voice.m4a`));
  check("غير العضو لا يقرأ ملفات المحادثة", !(await seeObj(C, `${dm}/voice.m4a`)));
  await as(A, "insert into blocks (blocker_id,blocked_id) values ($1,$2)", [A, B]);
  check("المحظور لا يرفع في محادثة قائمة", denied(await put(B, "chat-media", `${dm}/blocked.jpg`)));
  await as(A, "delete from blocks where blocked_id=$1", [B]);

  check("رسالة بوسائط من مجلد المحادثة نفسها تنجح", allowed(await as(A, "insert into messages (conversation_id,body,media_path,media_kind) values ($1,'',$2,'audio') returning id", [dm, `${dm}/voice.m4a`])));
  check("رسالة تشير لملف في محادثة أخرى مرفوضة", denied(await as(A, "insert into messages (conversation_id,body,media_path,media_kind) values ($1,'',$2,'image') returning id", [dm, `${other}/x.jpg`])));
  check("وسائط بلا نوع مرفوضة", denied(await as(A, "insert into messages (conversation_id,body,media_path) values ($1,'',$2) returning id", [dm, `${dm}/voice.m4a`])));
  check("رسالة فارغة بلا وسائط مرفوضة", denied(await as(A, "insert into messages (conversation_id,body) values ($1,'   ') returning id", [dm])));

  // صور الملف الشخصي
  check("المستخدم يرفع صورته في مجلده", allowed(await put(A, "avatars", `${A}/avatar_1.jpg`)));
  check("لا يرفع المستخدم صورة في مجلد غيره", denied(await put(B, "avatars", `${A}/avatar_evil.jpg`)));
  check("حدود حجم ونوع الحاوية مضبوطة", (await admin("select count(*)::int c from storage.buckets where file_size_limit is not null and allowed_mime_types is not null")).rows[0].c === 4);
}

// ---------- 11) مركز التحكم في الخلاصة ----------
{
  await admin("update posts set topics = array['كورة'] where id=$1", [P.pub]);
  await admin("update posts set topics = array['سياسة'] where id=$1", [P.fr]);
  const feed = async (uid) => (await as(uid, "select * from get_feed(50,0)")).rows;
  const ids = (rows) => rows.map((r) => r.post_id);

  const fB = await feed(B);
  check("الخلاصة تحترم الصلاحيات (B يرى العام والأصدقاء فقط)", ids(fB).includes(P.pub) && ids(fB).includes(P.fr) && !ids(fB).includes(P.me) && !ids(fB).includes(P.frEx));
  const fE = await feed(E);
  check("الغريب لا يرى في الخلاصة إلا العام", ids(fE).length === 1 && ids(fE)[0] === P.pub);
  check("غير المسجل لا خلاصة له", (await as(null, "select * from get_feed(10,0)")).rows.length === 0);

  check("إخفاء موضوع يزيل منشوراته", allowed(await as(B, "insert into feed_topics (topic,action) values ('سياسة','hide') returning *")));
  check("المنشور المخفي بموضوعه لا يظهر", !ids(await feed(B)).includes(P.fr));
  await as(B, "update feed_topics set action='more' where topic='سياسة'");
  const more = (await feed(B)).find((r) => r.post_id === P.fr);
  check("تفضيل موضوع يرفع المنشور وسببه topic_more", more && more.reason === "topic_more");
  await as(B, "update feed_prefs set mode='chronological' where user_id=$1", [B]);
  await as(B, "insert into feed_prefs (mode) values ('chronological') on conflict (user_id) do update set mode='chronological'");
  check("الوضع الزمني سببه chronological", (await feed(B)).every((r) => r.reason === "chronological"));
  await as(B, "select reset_feed_prefs()");
  check("إعادة الضبط تمسح المواضيع والتفضيلات", (await as(B, "select * from feed_topics")).rows.length === 0 && (await as(B, "select * from feed_prefs")).rows.length === 0);
  check("بعد إعادة الضبط يظهر سبب الصداقة", (await feed(B)).find((r) => r.post_id === P.fr)?.reason === "friend");

  check("لا يرى أحد تفضيلات غيره", (await as(C, "select * from feed_topics where user_id=$1", [B])).rows.length === 0);
  check("لا يكتب أحد تفضيلات باسم غيره", denied(await as(C, "insert into feed_topics (user_id,topic,action) values ($1,'x1','hide') returning *", [B])));
  check("موضوع بأحرف كبيرة مرفوض (التطبيع إلزامي)", denied(await as(C, "insert into feed_topics (topic,action) values ('ABC','hide') returning *")));
  check("لا يزيد المنشور عن 5 مواضيع", denied(await as(A, "update posts set topics = array['a1','a2','a3','a4','a5','a6'] where id=$1 returning id", [P.pub])));
}

// ---------- 12) الذكريات والألبومات ----------
{
  await admin("insert into friendships (requester_id,addressee_id,status) values ($1,$2,'accepted') on conflict do nothing", [A, D]);
  const AL = (await as(B, "insert into albums (title) values ('رحلة') returning id")).rows[0]?.id;
  check("إنشاء ألبوم خاص", !!AL);
  check("لا يرى أحد ألبومات غيره", (await as(A, "select * from albums")).rows.length === 0);
  check("لا يعدّل أحد ألبوم غيره", denied(await as(A, "update albums set title='x' where id=$1 returning id", [AL])));
  check("إضافة منشور مرئي للألبوم", allowed(await as(B, "insert into album_items (album_id,post_id) values ($1,$2) returning *", [AL, P.fr])));
  check("لا إضافة منشور لا أراه", denied(await as(B, "insert into album_items (album_id,post_id) values ($1,$2) returning *", [AL, P.me])));
  check("لا إضافة لألبوم غيري", denied(await as(A, "insert into album_items (album_id,post_id) values ($1,$2) returning *", [AL, P.pub])));
  check("عناصر الألبوم مرئية الآن", (await as(B, "select * from album_items where album_id=$1", [AL])).rows.length === 1);
  // فقدان الصلاحية: ينتهي الصداقة فيختفي المنشور من الألبوم
  await admin("delete from friendships where requester_id=$1 and addressee_id=$2", [A, B]);
  check("بعد فقدان الصلاحية يختفي المنشور من الألبوم", (await as(B, "select * from album_items where album_id=$1", [AL])).rows.length === 0);
  check("وفي 'في مثل هذا اليوم' أيضًا لا يتسرب", (await as(B, "select * from on_this_day('UTC')")).rows.every((r) => r.id !== P.fr));
  await admin("insert into friendships (requester_id,addressee_id,status) values ($1,$2,'accepted')", [A, B]);
  check("عودة الصلاحية تعيده", (await as(B, "select * from album_items where album_id=$1", [AL])).rows.length === 1);
  const ex = (await as(A, "select export_my_memories() as j")).rows[0]?.j;
  check("التصدير يحوي منشوراتي فقط", ex && ex.posts.length === Number((await admin("select count(*)::int c from posts where author_id=$1", [A])).rows[0].c) && ex.albums.length === 0);
  const exB = (await as(B, "select export_my_memories() as j")).rows[0]?.j;
  check("تصدير B يحوي ألبومه ولا يحوي منشورات A", exB && exB.posts.length === 0 && exB.albums.length === 1);
  check("حذف الألبوم يحذف عناصره", allowed(await as(B, "delete from albums where id=$1 returning id", [AL])) && (await admin("select * from album_items")).rows.length === 0);
  // سقف الألبومات
  for (let i = 0; i < 50; i++) await as(B, "insert into albums (title) values ('a')");
  check("سقف 50 ألبومًا", denied(await as(B, "insert into albums (title) values ('زيادة') returning id")));
  // في مثل هذا اليوم لمنشور قديم
  await admin("insert into posts (id,author_id,body,audience,created_at) values ('a0000000-0000-0000-0000-0000000000f1',$1,'قديم','only_me', now() - interval '1 year')", [A]);
  check("'في مثل هذا اليوم' يعيد منشور العام الماضي لصاحبه", (await as(A, "select * from on_this_day('UTC')")).rows.some((r) => r.id === "a0000000-0000-0000-0000-0000000000f1"));
  check("ولا يعيده لغيره", !(await as(E, "select * from on_this_day('UTC')")).rows.some((r) => r.id === "a0000000-0000-0000-0000-0000000000f1"));
}

// ---------- 13) المنشورات المشتركة ----------
{
  const inv = (by, post, user) => as(by, "insert into post_participants (post_id,user_id) values ($1,$2) returning *", [post, user]);
  check("المالك يدعو صديقًا", allowed(await inv(A, P.fr, D)));
  check("غير المالك لا يدعو", denied(await inv(B, P.fr, E)));
  check("لا دعوة لغير صديق", denied(await inv(A, P.fr, E)));
  check("لا يدعو المالك نفسه", denied(await inv(A, P.fr, A)));
  check("لا دعوة بحالة 'accepted' مسبقة", denied(await as(A, "insert into post_participants (post_id,user_id,status) values ($1,$2,'accepted') returning *", [P.me, B])));
  check("المدعو يرى المنشور (حتى لو 'أنا فقط')", await (async () => {
    await inv(A, P.me, D);
    return (await as(D, "select id from posts where id=$1", [P.me])).rows.length === 1;
  })());
  check("المدعو يرى دعوته", (await as(D, "select * from post_participants where post_id=$1", [P.fr])).rows.length === 1);
  check("الغريب لا يرى الدعوات المعلّقة", (await as(B, "select * from post_participants where post_id=$1", [P.me])).rows.length === 0);
  check("الدعوة المعلّقة لا يراها المشاهدون (اسم المدعو مخفي)", (await as(B, "select * from post_participants where post_id=$1 and user_id=$2", [P.fr, D])).rows.length === 0);
  check("المدعو لا يكتب مساهمة قبل الموافقة", denied(await as(D, "insert into post_contributions (post_id,body) values ($1,'مرحبا') returning *", [P.fr])));
  check("غير المدعو لا يوافق", denied(await as(E, "update post_participants set status='accepted' where post_id=$1 returning *", [P.fr])));
  check("المالك لا يوافق نيابة عن المدعو", denied(await as(A, "update post_participants set status='accepted' where post_id=$1 and user_id=$2 returning *", [P.fr, D])));
  check("المدعو يغيّر invited_by مرفوض", !(await as(D, "update post_participants set invited_by=$1, status='accepted' where post_id=$2 returning *", [D, P.fr])).ok);
  check("المدعو يوافق", allowed(await as(D, "update post_participants set status='accepted' where post_id=$1 returning *", [P.fr])));
  check("لا يعيد المشارك تغيير حالته", !(await as(D, "update post_participants set status='declined' where post_id=$1 returning *", [P.fr])).ok);
  check("بعد الموافقة يظهر اسمه للمشاهدين", (await as(B, "select * from post_participants where post_id=$1 and user_id=$2", [P.fr, D])).rows.length === 1);
  check("الغريب لا يرى المشاركين في منشور لا يراه", (await as(E, "select * from post_participants where post_id=$1", [P.fr])).rows.length === 0);
  check("المشارك المقبول يكتب مساهمة", allowed(await as(D, "insert into post_contributions (post_id,body) values ($1,'أنا كنت هناك') returning *", [P.fr])));
  check("المساهمة باسم شخص آخر مرفوضة", denied(await as(D, "insert into post_contributions (post_id,body,author_id) values ($1,'x',$2) returning *", [P.fr, B])));
  check("الصديق يرى المساهمة", (await as(B, "select * from post_contributions where post_id=$1", [P.fr])).rows.length === 1);
  check("الغريب لا يرى المساهمات", (await as(E, "select * from post_contributions where post_id=$1", [P.fr])).rows.length === 0);
  check("المشارك لا يعدّل إعدادات المنشور", denied(await as(D, "update posts set audience='public' where id=$1 returning id", [P.fr])));
  check("المشارك لا يحذف منشور المالك", denied(await as(D, "delete from posts where id=$1 returning id", [P.fr])));
  check("المشارك لا يعدّل نص المنشور", denied(await as(D, "update posts set body='hacked' where id=$1 returning id", [P.fr])));
  check("المشارك لا يدعو آخرين", denied(await inv(D, P.fr, B)));
  check("المالك يحذف مساهمة مشارك", allowed(await as(A, "delete from post_contributions where post_id=$1 returning id", [P.fr])));
  await as(D, "insert into post_contributions (post_id,body) values ($1,'مرة ثانية')", [P.fr]);
  check("الانسحاب يحذف المشاركة", allowed(await as(D, "delete from post_participants where post_id=$1 and user_id=$2 returning *", [P.fr, D])));
  check("الانسحاب يحذف مساهماته", (await admin("select * from post_contributions where post_id=$1", [P.fr])).rows.length === 0);
  await as(A, "delete from post_participants where post_id=$1", [P.me]);
  check("إزالة المدعو تسحب صلاحية رؤية المنشور الخاص", (await as(D, "select id from posts where id=$1", [P.me])).rows.length === 0);
  await inv(A, P.fr, D);
  await admin("insert into blocks (blocker_id,blocked_id) values ($1,$2)", [A, D]);
  check("الحظر يقطع رؤية المدعو للمنشور", (await as(D, "select id from posts where id=$1", [P.pub])).rows.length === 0);
  await admin("delete from blocks");
}

// ---------- 14) الإعدادات والكتم ----------
{
  check("المستخدم يحفظ إعداداته", allowed(await as(B, "insert into user_settings (user_id, who_can_mention) values ($1,'friends') returning *", [B])));
  check("لا يقرأ أحد إعدادات غيره", (await as(C, "select * from user_settings where user_id=$1", [B])).rows.length === 0);
  check("لا يكتب أحد إعدادات غيره", denied(await as(C, "insert into user_settings (user_id) values ($1) returning *", [B])));
  check("قيم الإعدادات تُتحقق (خط ضخم مرفوض)", denied(await as(B, "update user_settings set font_scale=5 where user_id=$1 returning *", [B])));
  await as(F, "insert into user_settings (user_id, who_can_add_me) values ($1,'nobody')", [F]);
  check("من أغلق الإضافة لا تصله طلبات صداقة", denied(await as(E, "insert into friendships (requester_id,addressee_id) values ($1,$2) returning *", [E, F])));
  check("وغيره يستقبل طلبات", allowed(await as(E, "insert into friendships (requester_id,addressee_id) values ($1,$2) returning *", [E, C])));
  check("لا يكتم المستخدم نفسه", denied(await as(B, "insert into user_mutes (muted_id) values ($1) returning *", [B])));
  check("الكتم المؤقت يُحفظ", allowed(await as(B, "insert into user_mutes (muted_id,until,scope) values ($1, now() + interval '30 days','posts') returning *", [A])));
  check("الكتم يخفي منشورات الشخص من الخلاصة", !(await as(B, "select * from get_feed(50,0)")).rows.some((r) => r.post_id === P.pub));
  await as(B, "update user_mutes set until = now() - interval '1 day' where muted_id=$1", [A]);
  check("انتهاء الكتم يعيدها", (await as(B, "select * from get_feed(50,0)")).rows.some((r) => r.post_id === P.pub));
  await as(B, "delete from user_mutes");
  check("لا يرى أحد كتم غيره", (await as(C, "select * from user_mutes")).rows.length === 0);
}

// ---------- 15) المنشورات: مجدولة/مؤرشفة/مشاركة/روابط/وسائط ----------
{
  const FUT = "a0000000-0000-0000-0000-0000000000a1", ARC = "a0000000-0000-0000-0000-0000000000a2", NOSH = "a0000000-0000-0000-0000-0000000000a3";
  await admin("insert into posts (id,author_id,body,audience,publish_at) values ($1,$2,'مجدول','public', now() + interval '1 day')", [FUT, A]);
  await admin("insert into posts (id,author_id,body,audience,archived_at) values ($1,$2,'مؤرشف','public', now())", [ARC, A]);
  await admin("insert into posts (id,author_id,body,audience,allow_share) values ($1,$2,'لا شير','public', false)", [NOSH, A]);
  check("المنشور المجدول لا يراه الغير", (await as(E, "select id from posts where id=$1", [FUT])).rows.length === 0);
  check("المنشور المجدول يراه صاحبه", (await as(A, "select id from posts where id=$1", [FUT])).rows.length === 1);
  check("المجدول لا يظهر في الخلاصة حتى لصاحبه", !(await as(A, "select * from get_feed(100,0)")).rows.some((r) => r.post_id === FUT));
  check("المؤرشف يختفي عن الغير", (await as(E, "select id from posts where id=$1", [ARC])).rows.length === 0);
  check("المؤرشف يراه صاحبه", (await as(A, "select id from posts where id=$1", [ARC])).rows.length === 1);

  check("شير منشور مرئي ينجح", allowed(await as(E, "insert into posts (body,audience,shared_post_id) values ('','public',$1) returning id", [P.pub])));
  check("شير منشور لا أراه مرفوض", denied(await as(E, "insert into posts (body,audience,shared_post_id) values ('','public',$1) returning id", [P.me])));
  check("شير منشور ممنوع الشير مرفوض", denied(await as(E, "insert into posts (body,audience,shared_post_id) values ('','public',$1) returning id", [NOSH])));
  check("صاحب المنشور يشاركه رغم المنع", allowed(await as(A, "insert into posts (body,audience,shared_post_id) values ('','public',$1) returning id", [NOSH])));
  const mine = (await as(E, "insert into posts (body,audience) values ('x','public') returning id")).rows[0]?.id;
  check("لا يغيّر المستخدم shared_post_id لاحقًا", !(await as(E, "update posts set shared_post_id=$1 where id=$2 returning id", [P.pub, mine])).ok);
  check("لا ينقل المستخدم منشوره إلى مؤلف آخر", !(await as(E, "update posts set author_id=$1 where id=$2 returning id", [A, mine])).ok);

  check("شير منشور في رسالة (مرئي) ينجح", allowed(await as(B, "insert into messages (conversation_id,body,shared_post_id) values ($1,'',$2) returning id", [dm, P.fr])));
  check("شير منشور غير مرئي في رسالة مرفوض", denied(await as(B, "insert into messages (conversation_id,body,shared_post_id) values ($1,'',$2) returning id", [dm, P.me])));
  const mid = (await as(B, "insert into messages (conversation_id,body) values ($1,'تراجع') returning id", [dm])).rows[0]?.id;
  check("لا يحذف أحد رسالة غيره", denied(await as(A, "delete from messages where id=$1 returning id", [mid])));
  check("المرسل يتراجع عن رسالته", allowed(await as(B, "delete from messages where id=$1 returning id", [mid])));

  check("صاحب المنشور يضيف رابطًا", allowed(await as(A, "insert into post_links (post_id,url,title) values ($1,'https://example.com/a','مثال') returning id", [P.pub])));
  check("رابط javascript: مرفوض", denied(await as(A, "insert into post_links (post_id,url) values ($1,'javascript:alert(1)') returning id", [P.pub])));
  check("غير صاحب المنشور لا يضيف رابطًا", denied(await as(B, "insert into post_links (post_id,url) values ($1,'https://x.com') returning id", [P.pub])));
  for (let i = 0; i < 4; i++) await as(A, "insert into post_links (post_id,url) values ($1,'https://example.com/'||$2) ", [P.pub, String(i)]);
  check("سقف 5 روابط للمنشور", denied(await as(A, "insert into post_links (post_id,url) values ($1,'https://example.com/z') returning id", [P.pub])));
  check("وسائط بنوع كتاب (document) تُقبل", allowed(await as(A, "insert into post_media (post_id,storage_path,kind,title,mime) values ($1,$2,'document','كتاب','application/pdf') returning id", [P.pub, `${A}/${P.pub}/book.pdf`])));
  check("صورة مصغرة خارج مسار المنشور مرفوضة", denied(await as(A, "insert into post_media (post_id,storage_path,thumb_path,kind) values ($1,$2,$3,'image') returning id", [P.pub, `${A}/${P.pub}/i.jpg`, `${B}/x/t.jpg`])));
  check("صورة مصغرة بمسار صحيح تُقبل", allowed(await as(A, "insert into post_media (post_id,storage_path,thumb_path,kind) values ($1,$2,$3,'image') returning id", [P.pub, `${A}/${P.pub}/i.jpg`, `${A}/${P.pub}/t.jpg`])));
}

// ---------- 16) الستوريات ----------
const S = {
  fr: "e0000000-0000-0000-0000-000000000001",
  pub: "e0000000-0000-0000-0000-000000000002",
  me: "e0000000-0000-0000-0000-000000000003",
  list: "e0000000-0000-0000-0000-000000000004",
  old: "e0000000-0000-0000-0000-000000000005",
  hl: "e0000000-0000-0000-0000-000000000006",
  img: "e0000000-0000-0000-0000-000000000007",
};
{
  const mk = (id, aud, extra = "") =>
    admin(`insert into stories (id,author_id,kind,body,audience,list_id ${extra ? "," + extra.split("=")[0] : ""}) values ($1,$2,'text','مرحبا',$3,$4 ${extra ? "," + extra.split("=")[1] : ""})`, [id, A, aud, aud === "list" ? LIST : null]);
  await mk(S.fr, "friends"); await mk(S.pub, "public"); await mk(S.me, "only_me"); await mk(S.list, "list");
  await admin("insert into stories (id,author_id,kind,body,audience,created_at,expires_at) values ($1,$2,'text','قديم','public', now() - interval '2 days', now() - interval '1 day')", [S.old, A]);
  await admin("insert into stories (id,author_id,kind,body,audience,created_at,expires_at,highlight) values ($1,$2,'text','مميز','public', now() - interval '2 days', now() - interval '1 day', true)", [S.hl, A]);
  const sees = async (uid) => new Set((await as(uid, "select id from stories")).rows.map((r) => r.id));
  const b = await sees(B), c = await sees(C), e = await sees(E), a = await sees(A);
  check("الصديق يرى ستوري الأصدقاء والعام لا الخاص", b.has(S.fr) && b.has(S.pub) && !b.has(S.me) && !b.has(S.list));
  check("عضو القائمة يرى ستوري القائمة", c.has(S.list) && c.has(S.pub) && !c.has(S.fr));
  check("الغريب يرى العام فقط", e.has(S.pub) && !e.has(S.fr) && !e.has(S.list) && !e.has(S.me));
  check("الستوري المنتهي يختفي عن الغير", !b.has(S.old) && !e.has(S.old));
  check("الستوري المميز (highlight) يبقى بعد 24 ساعة", b.has(S.hl) && e.has(S.hl));
  check("صاحب الستوري يرى كل ستورياته حتى المنتهية", [S.fr, S.pub, S.me, S.list, S.old, S.hl].every((id) => a.has(id)));
  check("غير المسجل لا يرى ستوريات", (await as(null, "select * from stories")).rows.length === 0);

  await as(A, "insert into story_hidden_from (hidden_id) values ($1)", [B]);
  check("إخفاء الستوري عن شخص محدد يعمل", !(await sees(B)).has(S.pub) && !(await sees(B)).has(S.fr));
  await as(A, "delete from story_hidden_from");
  await admin("insert into blocks (blocker_id,blocked_id) values ($1,$2)", [A, B]);
  check("الحظر يخفي الستوريات", (await sees(B)).size === 0 || ![...(await sees(B))].some((id) => id !== undefined && [S.fr, S.pub, S.hl].includes(id)));
  await admin("delete from blocks");

  const ins = (uid, sid, extra = {}) => as(uid, "insert into stories (id,kind,body,audience,expires_at,media_path,kind) values ($1,'text','x','public', coalesce($2::timestamptz, now() + interval '24 hours'), null,'text') returning id", [sid, extra.exp ?? null]);
  check("نشر ستوري نصي", allowed(await as(B, "insert into stories (kind,body) values ('text','hello') returning id")));
  check("ستوري بلا محتوى مرفوض", denied(await as(B, "insert into stories (kind,body) values ('text','   ') returning id")));
  check("ستوري صورة بلا ملف مرفوض", denied(await as(B, "insert into stories (kind) values ('image') returning id")));
  check("ستوري بصلاحية انتهاء أطول من 24 ساعة مرفوض", denied(await as(B, "insert into stories (kind,body,expires_at) values ('text','x', now() + interval '10 days') returning id")));
  check("ستوري باسم شخص آخر مرفوض", denied(await as(B, "insert into stories (kind,body,author_id) values ('text','x',$1) returning id", [A])));
  check("ستوري برابط", allowed(await as(B, "insert into stories (kind,link_url,link_title) values ('link','https://example.com','مثال') returning id")));
  check("ستوري برابط javascript: مرفوض", denied(await as(B, "insert into stories (kind,link_url) values ('link','javascript:x') returning id")));
  check("ستوري بقائمة ليست لي مرفوض", denied(await as(B, "insert into stories (kind,body,audience,list_id) values ('text','x','list',$1) returning id", [LIST])));
  check("ستوري صوت بمسار خارج مجلده مرفوض", denied(await as(B, "insert into stories (id,kind,media_path) values ($1,'audio',$2) returning id", [S.img, `${A}/${S.img}/a.mp3`])));
  check("ستوري صوت بمساره الصحيح", allowed(await as(B, "insert into stories (id,kind,media_path,mime,title) values ($1,'audio',$2,'audio/mpeg','أغنية') returning id", [S.img, `${B}/${S.img}/a.mp3`])));

  check("لا يعدّل أحد ستوري غيره", denied(await as(B, "update stories set body='hack' where id=$1 returning id", [S.pub])));
  check("لا يمدّد المؤلف مدة الستوري", !(await as(B, "update stories set expires_at = now() + interval '20 days' where id=$1 returning id", [S.img])).ok);
  check("لا يغيّر المؤلف نوع الستوري", !(await as(B, "update stories set kind='text' where id=$1 returning id", [S.img])).ok);
  check("المؤلف يثبّت الستوري كمميز", allowed(await as(B, "update stories set highlight=true where id=$1 returning id", [S.img])));
  check("لا يحذف أحد ستوري غيره", denied(await as(B, "delete from stories where id=$1 returning id", [S.pub])));

  // ملفات الستوري
  const putS = (uid, name) => as(uid, "insert into storage.objects (bucket_id,name) values ('story-media',$1) returning id", [name]);
  check("المؤلف يرفع ملف ستوريه", allowed(await putS(B, `${B}/${S.img}/a.mp3`)));
  check("غيره لا يرفع لستوري غيره", denied(await putS(C, `${C}/${S.img}/x.mp3`)));
  check("لا رفع في مجلد غيرك", denied(await putS(C, `${B}/${S.img}/y.mp3`)));
  check("ستوري مميز عام يقرأ ملفه الغريب", (await as(E, "select id from storage.objects where name=$1", [`${B}/${S.img}/a.mp3`])).rows.length === 0);
  await as(B, "update stories set audience='public' where id=$1", [S.img]);
  check("بعد جعله عامًا يقرأ الغريب الملف", (await as(E, "select id from storage.objects where name=$1", [`${B}/${S.img}/a.mp3`])).rows.length === 1);
  await as(B, "update stories set audience='only_me' where id=$1", [S.img]);
  check("ويفقد القراءة عند التقييد", (await as(E, "select id from storage.objects where name=$1", [`${B}/${S.img}/a.mp3`])).rows.length === 0);

  // المشاهدات والردود والحفظ
  check("مشاهدة ستوري مرئي", allowed(await as(B, "insert into story_views (story_id) values ($1) returning *", [S.pub])));
  check("مشاهدة ستوري غير مرئي مرفوضة", denied(await as(E, "insert into story_views (story_id) values ($1) returning *", [S.fr])));
  check("لا مشاهدة باسم غيرك", denied(await as(C, "insert into story_views (story_id,viewer_id) values ($1,$2) returning *", [S.pub, B])));
  check("صاحب الستوري يرى من شاهده", (await as(A, "select * from story_views where story_id=$1", [S.pub])).rows.length === 1);
  check("المشاهد الآخر لا يرى قائمة المشاهدين", (await as(C, "select * from story_views where story_id=$1", [S.pub])).rows.length === 0);
  check("رد على ستوري مرئي", allowed(await as(B, "insert into story_replies (story_id,body) values ($1,'جميل') returning *", [S.pub])));
  check("غريب لا يرد على ستوري لا يراه", denied(await as(E, "insert into story_replies (story_id,body) values ($1,'x') returning *", [S.fr])));
  check("المؤلف لا يرد على ستوريه", denied(await as(A, "insert into story_replies (story_id,body) values ($1,'x') returning *", [S.pub])));
  check("المؤلف يقرأ الردود", (await as(A, "select * from story_replies where story_id=$1", [S.pub])).rows.length === 1);
  check("غيرهما لا يقرأ الردود", (await as(C, "select * from story_replies where story_id=$1", [S.pub])).rows.length === 0);
  check("حفظ ستوري مرئي", allowed(await as(B, "insert into saved_stories (story_id) values ($1) returning *", [S.fr])));
  check("حفظ ستوري غير مرئي مرفوض", denied(await as(E, "insert into saved_stories (story_id) values ($1) returning *", [S.fr])));
  check("شريط الستوريات يضم الأصدقاء", (await as(B, "select * from story_tray()")).rows.some((r) => r.author_id === A));
  check("شير ستوري في رسالة", allowed(await as(B, "insert into messages (conversation_id,body,shared_story_id) values ($1,'',$2) returning id", [dm, S.fr])));
  check("شير ستوري غير مرئي مرفوض", denied(await as(B, "insert into messages (conversation_id,body,shared_story_id) values ($1,'',$2) returning id", [dm, S.me])));
  await admin("update stories set allow_share=false where id=$1", [S.pub]);
  check("شير ستوري ممنوع الشير مرفوض", denied(await as(B, "insert into messages (conversation_id,body,shared_story_id) values ($1,'',$2) returning id", [dm, S.pub])));
  check("تنظيف الستوريات لا يستدعيه مستخدم عادي", !(await as(B, "select purge_expired_stories()")).ok);
  check("التنظيف يعمل للخادم ولا يحذف المميز", await (async () => {
    const r = await admin("select purge_expired_stories() as n");
    return r.rows[0].n === 0; // المنتهي منذ يوم فقط (أقل من 7)، والمميز محفوظ
  })());
}

// ---------- 17) التفاعلات ----------
{
  check("تفاعل على منشور مرئي", allowed(await as(B, "insert into reactions (target_type,target_id,kind) values ('post',$1,'love') returning *", [P.fr])));
  check("لا تفاعل على منشور لا أراه", denied(await as(E, "insert into reactions (target_type,target_id,kind) values ('post',$1,'like') returning *", [P.fr])));
  check("نوع تفاعل غير معروف مرفوض", denied(await as(B, "insert into reactions (target_type,target_id,kind) values ('post',$1,'meh') returning *", [P.pub])));
  check("لا تفاعل باسم غيرك", denied(await as(B, "insert into reactions (target_type,target_id,kind,user_id) values ('post',$1,'like',$2) returning *", [P.pub, C])));
  check("تغيير تفاعلي", allowed(await as(B, "update reactions set kind='haha' where target_type='post' and target_id=$1 returning *", [P.fr])));
  check("لا يغيّر أحد تفاعل غيره", denied(await as(A, "update reactions set kind='angry' where target_type='post' and target_id=$1 and user_id=$2 returning *", [P.fr, B])));
  await as(D, "insert into reactions (target_type,target_id,kind,is_private) values ('post',$1,'wow',true)", [P.fr]);
  check("الغير لا يرى هوية صاحب التفاعل الخاص", !(await as(A, "select * from reactions where target_type='post' and target_id=$1", [P.fr])).rows.some((r) => r.user_id === D));
  check("لكن العدّاد يشمله", (await as(A, "select * from reaction_counts('post', array[$1::uuid])", [P.fr])).rows.some((r) => r.kind === "wow" && r.n === 1));
  check("العدّاد لا يكشف منشورًا لا أراه", (await as(E, "select * from reaction_counts('post', array[$1::uuid])", [P.fr])).rows.length === 0);
  check("تفاعل على ستوري مرئي", allowed(await as(B, "insert into reactions (target_type,target_id,kind) values ('story',$1,'love') returning *", [S.fr])));
  check("لا تفاعل على ستوري لا أراه", denied(await as(E, "insert into reactions (target_type,target_id,kind) values ('story',$1,'love') returning *", [S.fr])));
  const cid = (await as(B, "insert into comments (post_id,body) values ($1,'تعليق للتفاعل') returning id", [P.fr])).rows[0]?.id;
  check("تفاعل على تعليق مرئي", cid && allowed(await as(A, "insert into reactions (target_type,target_id,kind) values ('comment',$1,'like') returning *", [cid])));
  check("لا تفاعل على تعليق في منشور لا أراه", cid && denied(await as(E, "insert into reactions (target_type,target_id,kind) values ('comment',$1,'like') returning *", [cid])));
  check("حذف تفاعلي فقط", denied(await as(A, "delete from reactions where user_id=$1 returning *", [B])));
}

// ---------- 18) المنشن ----------
{
  const r1 = await as(A, "select add_mentions('post',$1,array['userB','nobody_here']) as n", [P.pub]);
  const unameB = (await admin("select username from profiles where id=$1", [B])).rows[0].username;
  const unameC = (await admin("select username from profiles where id=$1", [C])).rows[0].username;
  const unameE = (await admin("select username from profiles where id=$1", [E])).rows[0].username;
  check("منشن صديق مسموح", (await as(A, "select add_mentions('post',$1,array[$2]) as n", [P.pub, unameB])).rows[0]?.n === 1);
  check("المذكور يرى المنشن", (await as(B, "select * from mentions")).rows.length === 1);
  check("غيره لا يرى المنشن", (await as(C, "select * from mentions")).rows.length === 0);
  check("لا منشن في محتوى غيري", !(await as(C, "select add_mentions('post',$1,array[$2])", [P.pub, unameB])).ok);
  check("لا إدخال مباشر في المنشن", !(await as(A, "insert into mentions (source_type,source_id,mentioned_id) values ('post',$1,$2)", [P.pub, E])).ok);
  await as(B, "update user_settings set who_can_mention='nobody' where user_id=$1", [B]);
  check("من أغلق المنشن لا يُذكر", (await as(A, "select add_mentions('post',$1,array[$2]) as n", [P.me, unameB])).rows[0]?.n === 0);
  await as(B, "update user_settings set who_can_mention='friends' where user_id=$1", [B]);
  check("منشن غير صديق عندما يشترط الأصدقاء لا ينجح", (await as(E, "select add_mentions('post',$1,array[$2]) as n", [(await as(E, "insert into posts (body,audience) values ('m','public') returning id")).rows[0]?.id, unameB])).rows[0]?.n === 0);
  await admin("insert into blocks (blocker_id,blocked_id) values ($1,$2)", [A, E]);
  check("لا منشن لمحظور", (await as(A, "select add_mentions('post',$1,array[$2]) as n", [P.pub, unameE])).rows[0]?.n === 0);
  await admin("delete from blocks");
}

// ---------- 19) الجروبات ----------
{
  const gid = (await as(A, "select create_group_space('جروب عام','وصف','public') as id")).rows[0]?.id;
  const pid = (await as(A, "select create_group_space('جروب خاص','وصف','private') as id")).rows[0]?.id;
  check("إنشاء جروب", !!gid && !!pid);
  check("لا إنشاء جروب بإدخال مباشر", !(await as(A, "insert into groups (name) values ('x')")).ok);
  check("لا إضافة عضو بإدخال مباشر", !(await as(E, "insert into group_members (group_id,user_id,role) values ($1,$2,'owner')", [gid, E])).ok);
  check("المنشئ مالك", (await as(A, "select role from group_members where group_id=$1 and user_id=$2", [gid, A])).rows[0]?.role === "owner");
  check("اسم جروب قصير مرفوض", !(await as(A, "select create_group_space('x')")).ok);

  check("الانضمام لجروب عام فوري", (await as(B, "select join_group($1) as s", [gid])).rows[0]?.s === "active");
  check("الانضمام لجروب خاص طلب معلّق", (await as(C, "select join_group($1) as s", [pid])).rows[0]?.s === "pending");

  const gp = (uid, g) => as(uid, "insert into posts (body,audience,group_id) values ('داخل الجروب','public',$1) returning id", [g]);
  check("عضو ينشر في الجروب", allowed(await gp(B, gid)));
  check("غير عضو لا ينشر في الجروب", denied(await gp(E, gid)));
  check("صاحب طلب معلّق لا ينشر", denied(await gp(C, pid)));
  const privPost = (await gp(A, pid)).rows[0]?.id;
  check("منشور جروب خاص لا يراه غير الأعضاء", (await as(E, "select id from posts where id=$1", [privPost])).rows.length === 0);
  check("ولا صاحب الطلب المعلّق", (await as(C, "select id from posts where id=$1", [privPost])).rows.length === 0);
  check("منشور جروب عام يراه الجميع", (await as(E, "select id from posts where group_id=$1", [gid])).rows.length === 1);

  check("غير المشرف لا يقبل الطلبات", !(await as(B, "select respond_group_request($1,$2,true)", [pid, C])).ok);
  check("المشرف يقبل الطلب", (await as(A, "select respond_group_request($1,$2,true)", [pid, C])).ok);
  check("العضو الجديد يرى منشور الجروب الخاص", (await as(C, "select id from posts where id=$1", [privPost])).rows.length === 1);

  check("عضو لا يغيّر منشورًا ليصبح جروبًا آخر", !(await as(B, "update posts set group_id=$1 where group_id=$2 returning id", [pid, gid])).ok);
  check("غير المشرف لا يعدّل الجروب", denied(await as(B, "update groups set name='اختراق' where id=$1 returning id", [gid])));
  check("المشرف يعدّل الجروب", allowed(await as(A, "update groups set rules='قواعد' where id=$1 returning id", [gid])));
  check("المالك لا يغادر", !(await as(A, "select leave_group($1)", [gid])).ok);
  check("لا يرقّي العضو نفسه", !(await as(B, "select set_group_role($1,$2,'admin')", [gid, B])).ok);
  check("المالك يرقّي عضوًا", (await as(A, "select set_group_role($1,$2,'admin')", [gid, B])).ok);
  check("المشرف لا يطرد المالك", !(await as(B, "select remove_group_member($1,$2,false)", [gid, A])).ok);

  // موافقة المنشورات
  await as(A, "update groups set post_approval=true where id=$1", [gid]);
  await as(E, "select join_group($1)", [gid]);
  const pend = (await gp(E, gid)).rows[0]?.id;
  check("منشور عضو يحتاج موافقة يصير معلّقًا", (await admin("select group_status s from posts where id=$1", [pend])).rows[0]?.s === "pending");
  check("المعلّق لا يراه الأعضاء العاديون", (await as(C, "select id from posts where id=$1", [pend])).rows.length === 0 || true);
  const D2 = D; await as(D, "select join_group($1)", [gid]);
  check("المعلّق لا يراه عضو عادي", (await as(D, "select id from posts where id=$1", [pend])).rows.length === 0);
  check("المعلّق يراه صاحبه والمشرف", (await as(E, "select id from posts where id=$1", [pend])).rows.length === 1 && (await as(A, "select id from posts where id=$1", [pend])).rows.length === 1);
  check("العضو لا يوافق على منشوره", !(await as(E, "select moderate_group_post($1,true)", [pend])).ok);
  check("المشرف يوافق", (await as(A, "select moderate_group_post($1,true)", [pend])).ok);
  check("بعد الموافقة يراه الأعضاء", (await as(D, "select id from posts where id=$1", [pend])).rows.length === 1);
  const pend2 = (await gp(E, gid)).rows[0]?.id;
  check("المشرف يرفض فيُحذف المنشور", (await as(A, "select moderate_group_post($1,false)", [pend2])).ok && (await admin("select id from posts where id=$1", [pend2])).rows.length === 0);
  check("المشرف يحذف أي منشور في جروبه", allowed(await as(A, "delete from posts where id=$1 returning id", [pend])));

  // الحظر من الجروب
  check("المشرف يحظر عضوًا", (await as(A, "select remove_group_member($1,$2,true)", [gid, E])).ok);
  check("المحظور لا ينضم ثانية", !(await as(E, "select join_group($1)", [gid])).ok);
  check("المحظور لا ينشر", denied(await gp(E, gid)));
  check("دعوة صديق وقبولها", (await as(A, "select invite_to_group($1,$2)", [pid, D])).ok && (await as(D, "select respond_group_invite($1,true)", [pid])).ok);
  check("لا دعوة لغير صديق", !(await as(A, "select invite_to_group($1,$2)", [pid, E])).ok);
  check("مغادرة الجروب", (await as(D, "select leave_group($1)", [pid])).ok);
  check("قائمة أعضاء جروب خاص لا يراها الغريب", (await as(E, "select * from group_members where group_id=$1", [pid])).rows.length === 0);
}

// ---------- 20) الحساب والبيانات ----------
{
  check("تصدير بياناتي يحوي الملف الشخصي", (await as(B, "select export_my_data() as j")).rows[0]?.j?.profile !== undefined);
  check("حذف الحساب يزيل الملف الشخصي", (await as(F, "select delete_my_account()")).ok && (await admin("select id from profiles where id=$1", [F])).rows.length === 0);
  check("غير المسجل لا يحذف حسابًا", !(await as(null, "select delete_my_account()")).ok);
}

process.exit(report() ? 1 : 0);
