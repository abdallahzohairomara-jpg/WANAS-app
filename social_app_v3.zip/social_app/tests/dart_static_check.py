#!/usr/bin/env python3
"""فحص ثابت بسيط لكود Dart (بديل جزئي لـ flutter analyze عند تعذر تشغيله).
يتحقق من: مفاتيح النصوص، الاستيرادات المحلية، توازن الأقواس، ومعرّفات قاعدة البيانات
المستخدمة في الاستعلامات (جداول/أعمدة موجودة في ملفات SQL).
تشغيل: python3 tests/dart_static_check.py"""
import re, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
LIB = ROOT / "lib"
errors = []

def err(f, msg): errors.append(f"{f.relative_to(ROOT)}: {msg}")

# ---- مفاتيح النصوص ----
strings_src = (LIB / "strings.dart").read_text(encoding="utf-8")
keys = set(re.findall(r"^\s*'([a-z0-9_]+)':\s*\{", strings_src, re.M))
for k in re.findall(r"^\s*'([a-z0-9_]+)':\s*\{", strings_src, re.M):
    block = re.search(rf"'{k}':\s*\{{(.*?)\}},", strings_src, re.S)
    if block and not ("'ar'" in block.group(1) and "'en'" in block.group(1)):
        errors.append(f"strings.dart: المفتاح {k} ينقصه ar أو en")

for f in LIB.rglob("*.dart"):
    src = f.read_text(encoding="utf-8")
    for k in re.findall(r"\bt\('([a-z0-9_]+)'\)", src):
        if k not in keys: err(f, f"مفتاح نص غير موجود: {k}")

    # ---- الاستيرادات المحلية ----
    for imp in re.findall(r"^import '([^':]+\.dart)'", src, re.M):
        target = (f.parent / imp).resolve()
        if not target.exists(): err(f, f"استيراد لملف غير موجود: {imp}")
    for imp in re.findall(r"^import '(package:social_app/[^']+)'", src, re.M):
        err(f, f"استيراد بحزمة التطبيق نفسها غير مفضّل: {imp}")

    # ---- توازن الأقواس (بعد إزالة النصوص والتعليقات) ----
    s = re.sub(r"(?<!:)//.*", "", src)
    s = re.sub(r"'''.*?'''|\"\"\".*?\"\"\"", "", s, flags=re.S)
    s = re.sub(r"r?'(?:\\.|[^'\\\n])*'|r?\"(?:\\.|[^\"\\\n])*\"", "''", s)
    for a, b in ("()", "[]", "{}"):
        if s.count(a) != s.count(b): err(f, f"أقواس {a}{b} غير متوازنة ({s.count(a)} مقابل {s.count(b)})")

# ---- جداول وأعمدة قاعدة البيانات ----
sql = "\n".join(p.read_text(encoding="utf-8") for p in sorted(ROOT.glob("phase*.sql")) if "TEMPLATE" not in p.name)
tables = set(re.findall(r"create table (?:if not exists )?(\w+)", sql))
funcs = set(re.findall(r"create or replace function (\w+)", sql))
for f in LIB.rglob("*.dart"):
    src = f.read_text(encoding="utf-8")
    for t in re.findall(r"(?<!storage)\.from\('(\w+)'\)", src):
        if t not in tables: err(f, f"جدول غير موجود في SQL: {t}")
    for fn in re.findall(r"\.rpc\('(\w+)'", src):
        if fn not in funcs: err(f, f"دالة rpc غير موجودة في SQL: {fn}")

if errors:
    print("\n".join(errors)); sys.exit(1)
print(f"✔ لا مشاكل. فُحص {len(list(LIB.rglob('*.dart')))} ملف Dart، {len(keys)} مفتاح نص، {len(tables)} جدولًا.")
