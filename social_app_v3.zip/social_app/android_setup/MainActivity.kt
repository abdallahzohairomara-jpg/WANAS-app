// انسخ هذا الملف فوق android/app/src/main/kotlin/<مسار الحزمة>/MainActivity.kt
// وغيّر سطر package ليطابق applicationId الموجود في android/app/build.gradle.
// الغرض: إنشاء قناتي الإشعارات "messages" و"calls" اللتين يستخدمهما الخادم.
// قناة المكالمات بأهمية عالية ونغمة رنين ليظهر الإشعار منبثقًا ويرنّ.
package com.example.social_app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)

            val messages = NotificationChannel(
                "messages", "Messages", NotificationManager.IMPORTANCE_HIGH
            )
            nm.createNotificationChannel(messages)

            val calls = NotificationChannel(
                "calls", "Calls", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIC)
                        .build()
                )
                enableVibration(true)
            }
            nm.createNotificationChannel(calls)
        }
    }
}
